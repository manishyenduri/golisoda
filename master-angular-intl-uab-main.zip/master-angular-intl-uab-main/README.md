# SIMBA

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.3.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).


PROJECT OVERVIEW - SIMBA
========================

SimplyFI Bot Automation have majorily two roles : 

1) Maker
2) Checker

MAKER
=====
All the maker code is under app/maker folder

# STEP 1 : Document Upload(maker/docUpload)

* Maker will do the bulk trade document upload of the scanned documents and the respective trade documents will get placed in the respective cards (LC, Invoice etc)

# STEP 2 : Analyse

* All the trade documents will be analysed by the OCR and will generate respective AI and manual Reports

# STEP 2.1 : AI REPORT(maker/AIreport)

* AI report contains the details of doc type, checkpoint, status, accuracy against each rules 
Accuracy 100 - Compliant
Accuracy <100 - Discripant

* This AI report can be exported as PDF document.

* Maker will send this AI report to the checker with remarks and can reject it right away if there is any cross deviation in documents.

# STEP 2.1 : Manual REPORT(maker/manualReport)

* Manual Report will be generated manually by maker.

* Will have list of rules segregated based on trade docs. On selectig each rule will get the accuracy result of LC image and the trade document image.

* Maker can add remarks for each rule and can tell wheather it is compliant or not

* On successfully completing all the rule check manually can further send to checker for final approval or maker can reject directly if there is gross deviation.

APIs Integrated
===============
# Global Service

To store the JWT token that can be accessed in all other service modules

# Authentication (servicess/auth.service.ts)

* Login API (As there is no registration API can directly login based on user roles)

* Refresh token API should be called for each and every API as the token get expired after every 10     minutes

* Logout API to delete the token

# MAKER API (services/maker/docs.service.ts)

* Documentated inside the service component





