import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakerJourneyStartComponent } from './maker-journey-start.component';

describe('MakerJourneyStartComponent', () => {
  let component: MakerJourneyStartComponent;
  let fixture: ComponentFixture<MakerJourneyStartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakerJourneyStartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakerJourneyStartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
