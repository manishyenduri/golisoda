import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { con } from 'src/app/Admin/admin-dashboard/country2';
import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-outward-remittance',
  templateUrl: './outward-remittance.component.html',
  styleUrls: ['./outward-remittance.component.css']
})
export class OutwardRemittanceComponent implements OnInit {

 
  getId:any;
  exchangeData:any;
  rootCard:boolean;
  form15_boolean:boolean;
  inv_boolean:boolean;
  outward_boolean:boolean;
  remittance_details_boolean:boolean;
  view1Data:any;
  remittance_array:any;
  remittee_array:any;
  selectedRow:any;
  rightRuleImg:SafeResourceUrl;
  leftRuleImg:SafeResourceUrl;
  rightData:any;
  highNoData:any;
  remitter_array:any;
  verification_array:any;
  benficiary_array:any;
  outward_remittance_array:any;
  outward_remitter_array:any;
  inv_array:any;
  processingData:any;

  constructor(private _httpService:MakerService,private router:Router ,private sanitizer:DomSanitizer, private modalService:NgbModal) { }

  ngOnInit() {
    this._httpService.trackOutward(localStorage.getItem("Outward_id")).subscribe(r=>{
      this.processingData = (r);
      console.log("Swal-> ",r)
      if(this.processingData.status === "processing")
        Swal.fire("Document Status","("+localStorage.getItem('Outward_id')+") <br/> Processing . . .","info");
      // else
      // Swal.fire("",this.processingData.message,"success");
    })
    this.remittance_array=[
      {title:"Country",data:'',highlighted:'',snippet:''},
      {title:"Date",data:'',highlighted:'',snippet:''},
      {title:"Bank Name",data:'',highlighted:'',snippet:''},
      {title:"Branch Name",data:'',highlighted:'',snippet:''},
      {title:"Branch Code",data:'',highlighted:'',snippet:''},
      {title:"Currency",data:'',highlighted:'',snippet:''},
      {title:"Foreign Amount",data:'',highlighted:'',snippet:''},
      {title:"INR Amount",data:'',highlighted:'',snippet:''},
    ];
    this.remittee_array=[
      {title:"Remittee Name",data:'',highlighted:'',snippet:''},
      {title:"Remittee Address",data:'',highlighted:'',snippet:''},
      {title:"Remittee email",data:'',highlighted:'',snippet:''},
      {title:"Remittee Pan",data:'',highlighted:'',snippet:''},
      {title:"Remittee Phone No.",data:'',highlighted:'',snippet:''},
    ];
    this.remitter_array=[
      {title:"Remitter Name",data:'',highlighted:'',snippet:''},
      {title:"Remitter Address",data:'',highlighted:'',snippet:''},
      {title:"Remitter email",data:'',highlighted:'',snippet:''},
      {title:"Remitter Pan",data:'',highlighted:'',snippet:''},
      {title:"Remitter Phone No.",data:'',highlighted:'',snippet:''},
    ];
    this.verification_array=[
      {title:"Date",data:'',highlighted:'',snippet:''},
      {title:"Name",data:'',highlighted:'',snippet:''},
      {title:"Designation",data:'',highlighted:'',snippet:''},
      {title:"Place",data:'',highlighted:'',snippet:''},
    ]
    this.inv_array=[
      // {title:"Invoice No.",data:'',highlighted:''}
    ]
    this.benficiary_array=[
      {title:"Bank Name",data:'',highlighted:'',snippet:''},
      {title:"Bank Address",data:'',highlighted:'',snippet:''},
      {title:"Benficiary Acc. No.",data:'',highlighted:'',snippet:''},
      {title:"Benficiary Name",data:'',highlighted:'',snippet:''},
      {title:"Benficiary Address",data:'',highlighted:'',snippet:''},
      {title:"Swift Code",data:'',highlighted:'',snippet:''}
    ]
    this.outward_remittance_array=[
      {title:"Amount",data:'',highlighted:'',snippet:''},
      {title:"Currency",data:'',highlighted:'',snippet:''},
      {title:"Purpose Code",data:'',highlighted:'',snippet:''}
    ]
    this.outward_remitter_array=[
      {title:"Remitter Name",data:'',highlighted:'',snippet:''},
      {title:"Remitter Acc. No.",data:'',highlighted:'',snippet:''},
      {title:"Remitter Address",data:'',highlighted:'',snippet:''},
      {title:"Remitter Country",data:'',highlighted:'',snippet:''},
      {title:"Remitted Amount",data:'',highlighted:'',snippet:''}
    ]
    this.view1Data=[];
    this.rootCard=true;
    this.form15_boolean=false;
    this.remittance_details_boolean=false;
    this.inv_boolean=false;
    this.outward_boolean=false;
    this.getId = localStorage.getItem("Outward_id");
    
    this._httpService.getOutwardReportByID().subscribe(r=>{
      this.exchangeData=(r);
     })
     
  }
  back(){
    this.rootCard=true;
    this.form15_boolean=false;
    this.inv_boolean=false;
    this.outward_boolean=false;
    this.remittance_details_boolean=false;
  }
  back1(){
    this.router.navigate(['/maker/outward-remittance-list'])
  }
  navigate(string){
    console.log("This - ",this.rootCard)
    this.rootCard=!this.rootCard;
    if(string==="form15")
     { 
       this.form15_boolean=true;
       this.inv_boolean=false;
       this.outward_boolean=false;
     }
    if(string==="invoice")
      {
        this.form15_boolean=false;
        this.inv_boolean=true;
        this.outward_boolean=false;
      }
    if(string==="outward")
      {
        this.form15_boolean=false;
        this.inv_boolean=false;
        this.outward_boolean=true;
      }
  }
  
  remittance_details(){
    this.view1Data=[];
    this.remittance_details_boolean=true;
    this.remittance_array[0].data=this.exchangeData.result.extraction.form15ca.remittance_details.country;
    this.remittance_array[1].data=this.exchangeData.result.extraction.form15ca.remittance_details.date;
    this.remittance_array[2].data=this.exchangeData.result.extraction.form15ca.remittance_details.bank_name;
    this.remittance_array[4].data=this.exchangeData.result.extraction.form15ca.remittance_details.branch_code;
    this.remittance_array[3].data=this.exchangeData.result.extraction.form15ca.remittance_details.branch_name;
    this.remittance_array[5].data=this.exchangeData.result.extraction.form15ca.remittance_details.currency;
    this.remittance_array[6].data=this.exchangeData.result.extraction.form15ca.remittance_details.amt_foreign;
    this.remittance_array[7].data=this.exchangeData.result.extraction.form15ca.remittance_details.amt_inr;
   
    this.remittance_array[0].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_country; 
    this.remittance_array[1].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_date;
    this.remittance_array[2].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_bank_name;
    this.remittance_array[3].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_branch_name;
    this.remittance_array[4].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_branch_code;
    this.remittance_array[5].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_currency;
    this.remittance_array[6].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_amt_foreign;
    this.remittance_array[7].highlighted=this.exchangeData.result.extraction.form15ca.remittance_details.highlighted_amt_inr;
    
    this.remittance_array[6].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_amt_foreign;
    this.remittance_array[0].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_country; 
    this.remittance_array[1].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_date;
    this.remittance_array[2].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_bank_name;
    this.remittance_array[3].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_branch_name;
    this.remittance_array[4].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_branch_code;
    this.remittance_array[5].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_currency;
    this.remittance_array[7].snippet=this.exchangeData.result.extraction.form15ca.remittance_details.snipppet_amt_inr;
    for(var i=0;i<this.remittance_array.length;i++){
      this.view1Data.push(this.remittance_array[i]);
    }
    this.onCard(this.view1Data[0],0);
  }
  // deleteArray(){
  //   if(this.view1Data.length!=0)
  //     for(var i=0;i<this.view1Data.length;i++){
  //       delete this.view1Data[i];
  //     }
  // }
  remittee_details(){
    // this.deleteArray();
    this.view1Data=[];
    this.remittance_details_boolean=true;
    this.remittee_array[0].data=this.exchangeData.result.extraction.form15ca.remittee_details.remittee_name;
    this.remittee_array[1].data=this.exchangeData.result.extraction.form15ca.remittee_details.remittee_address;
    this.remittee_array[2].data=this.exchangeData.result.extraction.form15ca.remittee_details.remittee_email_id;
    this.remittee_array[3].data=this.exchangeData.result.extraction.form15ca.remittee_details.remittee_pan;
    this.remittee_array[4].data=this.exchangeData.result.extraction.form15ca.remittee_details.remittee_phone_no;
   
    this.remittee_array[0].highlighted=this.exchangeData.result.extraction.form15ca.remittee_details.highlighted_remittee_name; 
    this.remittee_array[1].highlighted=this.exchangeData.result.extraction.form15ca.remittee_details.highlighted_remittee_address;
    this.remittee_array[2].highlighted=this.exchangeData.result.extraction.form15ca.remittee_details.highlighted_remittee_email_id;
    this.remittee_array[3].highlighted=this.exchangeData.result.extraction.form15ca.remittee_details.highlighted_remittee_pan;
    this.remittee_array[4].highlighted=this.exchangeData.result.extraction.form15ca.remittee_details.highlighted_remittee_phone_no;
    
    this.remittee_array[0].snippet=this.exchangeData.result.extraction.form15ca.remittee_details.snipppet_remittee_name; 
    this.remittee_array[1].snippet=this.exchangeData.result.extraction.form15ca.remittee_details.snipppet_remittee_address;
    this.remittee_array[2].snippet=this.exchangeData.result.extraction.form15ca.remittee_details.snipppet_remittee_email_id;
    this.remittee_array[3].snippet=this.exchangeData.result.extraction.form15ca.remittee_details.snipppet_remittee_pan;
    this.remittee_array[4].snippet=this.exchangeData.result.extraction.form15ca.remittee_details.snipppet_remittee_phone_no;
    for(var i=0;i<this.remittee_array.length;i++){
      this.view1Data.push(this.remittee_array[i]);
    }
    this.onCard(this.view1Data[0],0);
  }
  remitter_details(){
    // this.deleteArray();
    this.view1Data=[];
    this.remittance_details_boolean=true;
    this.remitter_array[0].data=this.exchangeData.result.extraction.form15ca.remitter_details.remitter_name;
    this.remitter_array[1].data=this.exchangeData.result.extraction.form15ca.remitter_details.remitter_address;
    this.remitter_array[2].data=this.exchangeData.result.extraction.form15ca.remitter_details.remitter_email_id;
    this.remitter_array[3].data=this.exchangeData.result.extraction.form15ca.remitter_details.remitter_pan;
    this.remitter_array[4].data=this.exchangeData.result.extraction.form15ca.remitter_details.remitter_phone_no;
   
    this.remitter_array[0].highlighted=this.exchangeData.result.extraction.form15ca.remitter_details.highlighted_remitter_name; 
    this.remitter_array[1].highlighted=this.exchangeData.result.extraction.form15ca.remitter_details.highlighted_remitter_address;
    this.remitter_array[2].highlighted=this.exchangeData.result.extraction.form15ca.remitter_details.highlighted_remitter_email_id;
    this.remitter_array[3].highlighted=this.exchangeData.result.extraction.form15ca.remitter_details.highlighted_remitter_pan;
    this.remitter_array[4].highlighted=this.exchangeData.result.extraction.form15ca.remitter_details.highlighted_remitter_phone_no;
    
    this.remitter_array[0].snippet=this.exchangeData.result.extraction.form15ca.remitter_details.snipppet_remitter_name; 
    this.remitter_array[1].snippet=this.exchangeData.result.extraction.form15ca.remitter_details.snipppet_remitter_address;
    this.remitter_array[2].snippet=this.exchangeData.result.extraction.form15ca.remitter_details.snipppet_remitter_email_id;
    this.remitter_array[3].snippet=this.exchangeData.result.extraction.form15ca.remitter_details.snipppet_remitter_pan;
    this.remitter_array[4].snippet=this.exchangeData.result.extraction.form15ca.remitter_details.snipppet_remitter_phone_no;
    for(var i=0;i<this.remitter_array.length;i++){
      this.view1Data.push(this.remitter_array[i]);
    }
    this.onCard(this.view1Data[0],0);
  }
  verification_details(){
    // this.deleteArray();
    this.view1Data=[];
    this.remittance_details_boolean=true;
    this.verification_array[0].data=this.exchangeData.result.extraction.form15ca.verification_details.date;
    this.verification_array[1].data=this.exchangeData.result.extraction.form15ca.verification_details.person_name;
    this.verification_array[2].data=this.exchangeData.result.extraction.form15ca.verification_details.designation;
    this.verification_array[3].data=this.exchangeData.result.extraction.form15ca.verification_details.place;
   
    this.verification_array[0].highlighted=this.exchangeData.result.extraction.form15ca.verification_details.highlighted_date; 
    this.verification_array[1].highlighted=this.exchangeData.result.extraction.form15ca.verification_details.highlighted_person_name;
    this.verification_array[2].highlighted=this.exchangeData.result.extraction.form15ca.verification_details.highlighted_designation;
    this.verification_array[3].highlighted=this.exchangeData.result.extraction.form15ca.verification_details.highlighted_place;
   
    this.verification_array[0].snippet=this.exchangeData.result.extraction.form15ca.verification_details.snipppet_date; 
    this.verification_array[1].snippet=this.exchangeData.result.extraction.form15ca.verification_details.snipppet_person_name;
    this.verification_array[2].snippet=this.exchangeData.result.extraction.form15ca.verification_details.snipppet_designation;
    this.verification_array[3].snippet=this.exchangeData.result.extraction.form15ca.verification_details.snipppet_place;
    for(var i=0;i<this.verification_array.length;i++){
      this.view1Data.push(this.verification_array[i]);
    }
    this.onCard(this.view1Data[0],0);
  }
  invoice_no_details(){ 
    this.view1Data=[];
    this.remittance_details_boolean=true;
    for(var i=0;i<this.exchangeData.result.extraction.invoices.length;i++){
      var a= {title:"Invoice No. "+(1+i),data:'',highlighted:'',snippet:''};
      
      a.data=this.exchangeData.result.extraction.invoices[i].invoice_no; 
      a.highlighted=this.exchangeData.result.extraction.invoices[i].highlighted_invoice_no;
      a.snippet=this.exchangeData.result.extraction.invoices[i].snippet_invoice_no;
     this.view1Data.push(a);
    }
    // if(this.exchangeData.result.extraction.invoices.length>1)
    //   for(var j=0;j<this.inv_array.l)
    this.onCard(this.view1Data[0],0);

  }

  benficiary_details(){
    this.view1Data=[];
    this.remittance_details_boolean=true;
    this.benficiary_array[0].data=this.exchangeData.result.extraction.outward_remittance.benficiary_details.bank_name;
    this.benficiary_array[1].data=this.exchangeData.result.extraction.outward_remittance.benficiary_details.bank_address;
    this.benficiary_array[2].data=this.exchangeData.result.extraction.outward_remittance.benficiary_details.benficiary_acc_no;
    this.benficiary_array[3].data=this.exchangeData.result.extraction.outward_remittance.benficiary_details.benficiary_name;
    this.benficiary_array[4].data=this.exchangeData.result.extraction.outward_remittance.benficiary_details.benficiary_address;
    this.benficiary_array[5].data=this.exchangeData.result.extraction.outward_remittance.benficiary_details.swift_code;
   
    this.benficiary_array[0].highlighted=this.exchangeData.result.extraction.outward_remittance.benficiary_details.highlighted_bank_name; 
    this.benficiary_array[1].highlighted=this.exchangeData.result.extraction.outward_remittance.benficiary_details.highlighted_bank_address;
    this.benficiary_array[2].highlighted=this.exchangeData.result.extraction.outward_remittance.benficiary_details.highlighted_benficiary_acc_no;
    this.benficiary_array[3].highlighted=this.exchangeData.result.extraction.outward_remittance.benficiary_details.highlighted_benficiary_name;
    this.benficiary_array[4].highlighted=this.exchangeData.result.extraction.outward_remittance.benficiary_details.highlighted_benficiary_address;
    this.benficiary_array[5].highlighted=this.exchangeData.result.extraction.outward_remittance.benficiary_details.highlighted_swift_code;

    this.benficiary_array[0].snippet=this.exchangeData.result.extraction.outward_remittance.benficiary_details.snippet_bank_name;
    this.benficiary_array[1].snippet=this.exchangeData.result.extraction.outward_remittance.benficiary_details.snippet_bank_address;
    this.benficiary_array[2].snippet=this.exchangeData.result.extraction.outward_remittance.benficiary_details.snippet_benficiary_acc_no;
    this.benficiary_array[3].snippet=this.exchangeData.result.extraction.outward_remittance.benficiary_details.snippet_benficiary_name;
    this.benficiary_array[4].snippet=this.exchangeData.result.extraction.outward_remittance.benficiary_details.snippet_benficiary_address;
    this.benficiary_array[5].snippet=this.exchangeData.result.extraction.outward_remittance.benficiary_details.snippet_swift_code;
    for(var i=0;i<this.benficiary_array.length;i++){
      this.view1Data.push(this.benficiary_array[i]);
    }
    console.log("benficiary_array",this.benficiary_array)
    this.onCard(this.view1Data[0],0);
  }
  outward_remittance_details(){
    this.view1Data=[];
    this.remittance_details_boolean=true;
    this.outward_remittance_array[0].data=this.exchangeData.result.extraction.outward_remittance.remittance_details.amt;
    this.outward_remittance_array[1].data=this.exchangeData.result.extraction.outward_remittance.remittance_details.currency;
    this.outward_remittance_array[2].data=this.exchangeData.result.extraction.outward_remittance.remittance_details.purpose_code;
   
    this.outward_remittance_array[0].highlighted=this.exchangeData.result.extraction.outward_remittance.remittance_details.highlighted_amt; 
    this.outward_remittance_array[1].highlighted=this.exchangeData.result.extraction.outward_remittance.remittance_details.highlighted_currency;
    this.outward_remittance_array[2].highlighted=this.exchangeData.result.extraction.outward_remittance.remittance_details.highlighted_purpose_code;
   
    this.outward_remittance_array[0].snippet=this.exchangeData.result.extraction.outward_remittance.remittance_details.snippet_amt; 
    this.outward_remittance_array[1].snippet=this.exchangeData.result.extraction.outward_remittance.remittance_details.snippet_currency;
    this.outward_remittance_array[2].snippet=this.exchangeData.result.extraction.outward_remittance.remittance_details.snippet_purpose_code;
   
    for(var i=0;i<this.outward_remittance_array.length;i++){
      this.view1Data.push(this.outward_remittance_array[i]);
    }
    this.onCard(this.view1Data[0],0);
  }
  outward_remitter_details(){
    this.view1Data=[];
    this.remittance_details_boolean=true;
    this.outward_remitter_array[0].data=this.exchangeData.result.extraction.outward_remittance.remitter_details.remitter_name;
    this.outward_remitter_array[1].data=this.exchangeData.result.extraction.outward_remittance.remitter_details.remitter_acc_no;
    this.outward_remitter_array[2].data=this.exchangeData.result.extraction.outward_remittance.remitter_details.remitter_address;
    this.outward_remitter_array[3].data=this.exchangeData.result.extraction.outward_remittance.remitter_details.remitter_country;
    this.outward_remitter_array[4].data=this.exchangeData.result.extraction.outward_remittance.remitter_details.remitted_amount;
   
    this.outward_remitter_array[0].highlighted=this.exchangeData.result.extraction.outward_remittance.remitter_details.highlighted_remitter_name; 
    this.outward_remitter_array[1].highlighted=this.exchangeData.result.extraction.outward_remittance.remitter_details.highlighted_remitter_acc_no;
    this.outward_remitter_array[2].highlighted=this.exchangeData.result.extraction.outward_remittance.remitter_details.highlighted_remitter_address;
    this.outward_remitter_array[3].highlighted=this.exchangeData.result.extraction.outward_remittance.remitter_details.highlighted_remitter_country;
    this.outward_remitter_array[4].highlighted=this.exchangeData.result.extraction.outward_remittance.remitter_details.highlighted_remitted_amount;
   
    this.outward_remitter_array[0].snippet=this.exchangeData.result.extraction.outward_remittance.remitter_details.snippet_remitter_name; 
    this.outward_remitter_array[1].snippet=this.exchangeData.result.extraction.outward_remittance.remitter_details.snippet_remitter_acc_no;
    this.outward_remitter_array[2].snippet=this.exchangeData.result.extraction.outward_remittance.remitter_details.snippet_remitter_address;
    this.outward_remitter_array[3].snippet=this.exchangeData.result.extraction.outward_remittance.remitter_details.snippet_remitter_country;
    this.outward_remitter_array[4].snippet=this.exchangeData.result.extraction.outward_remittance.remitter_details.snippet_remitted_amount;
   
    for(var i=0;i<this.outward_remitter_array.length;i++){
      this.view1Data.push(this.outward_remitter_array[i]);
    }
    this.onCard(this.view1Data[0],0);
  }
  onCard(data,i){
    this.selectedRow = i;
    if(data.highlighted!='' && data.highlighted!=null)
      this.leftRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl(data.highlighted);
    else
      this.leftRuleImg=null;

    if(data.data !='')
      this.highNoData='';
    else
      this.highNoData='No document';

    if(data.snippet!='')
      this.rightRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl(data.snippet);
    else
      this.rightRuleImg=null;

    this.rightData=data.data;
  }

    
zoomin() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
}


openSnippet(content) {
  this.modalService.open(content, { size: 'lg' });
}
  
  
}
