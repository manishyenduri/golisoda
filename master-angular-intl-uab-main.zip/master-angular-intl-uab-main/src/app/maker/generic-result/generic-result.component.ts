import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { MakerService } from 'src/app/services/maker/docs.service';

@Component({
  selector: 'app-generic-result',
  templateUrl: './generic-result.component.html',
  styleUrls: ['./generic-result.component.css']
})
export class GenericResultComponent implements OnInit {
  id:any;
  rightRuleImg:SafeResourceUrl;
  leftRuleImg:SafeResourceUrl;
  exchangeData:any;

  constructor(private _httpService:MakerService, private sanitizer:DomSanitizer, private router:Router) { }

  ngOnInit() {
    this.id=localStorage.getItem('generic_id');
    this._httpService.getGenericData(this.id).subscribe(r=>{
      this.exchangeData = (r);
      console.log("Data - ",this.exchangeData);
      this.rightRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl(this.exchangeData.result.extracted_pdf_path);
      this.leftRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl(this.exchangeData.result.pdf_path);
    })
  }

  goBack(){
    this.router.navigate(['maker/genericOcr'])
  }

}
