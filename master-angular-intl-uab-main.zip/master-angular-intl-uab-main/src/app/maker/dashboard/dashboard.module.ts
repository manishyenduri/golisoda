import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DashboardComponent } from './dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ChartistModule } from 'ng-chartist';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ChartsModule } from 'ng2-charts';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
const routes: Routes = [{
    path: '',
    data: {
        title: 'Dashboard',
        // urls: [{title: 'Bills', url: '/dashboard'}]
    },
    component: DashboardComponent
}];

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        NgbModule,
        RouterModule.forChild(routes),
        ReactiveFormsModule,
        HttpModule,
        ChartistModule,
        NgxChartsModule,
        ChartsModule,
        Ng2SearchPipeModule
    ],
    declarations: [DashboardComponent],
    providers: [MakerService, AuthService]
})
export class DashboardModule { }
