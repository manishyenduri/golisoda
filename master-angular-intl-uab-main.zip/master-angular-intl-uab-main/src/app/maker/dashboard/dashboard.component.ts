import * as c3 from 'c3';
import { Component, Pipe, PipeTransform } from '@angular/core';
import * as Chartist from 'chartist';
import { ChartType, ChartEvent } from 'ng-chartist/dist/chartist.component';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import Swal from 'sweetalert2';
declare var require: any;

const data: any = require('./data.json');

export interface Chart {
  type: ChartType;
  data: Chartist.IChartistData;
  options?: any;
  responsiveOptions?: any;
  events?: ChartEvent;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
}) 


export class DashboardComponent {

  docsInfoData: any;
  centralExchange:any;
  centralQueueData:any;
  listOfDocs: any;
  tokenInfo: any;
  requestResponse: any;
  trans_hist:any;
  dashResponse:any;
  searchItem:any;
  // Barchart
  barChart1: Chart = {
    type: 'Bar',
    data: data['Bar'],
    options: {
      seriesBarDistance: 15,
      axisX: {
        showGrid: false,
        offset: 70
      },
      axisY: {
        showGrid: true,
        offset: 50
      }
    },
    responsiveOptions: [
      [
        'screen and (min-width: 640px)',
        {
          axisX: {
            labelInterpolationFnc: function(
              value: number,
              index: number
            ): string {
              return index % 1 === 0 ? `${value}` : null;
            }
          }
        }
      ]
    ]
  };

  // Line chart
  lineChart1: Chart = {
    type: 'Line',
    data: data['LineWithArea'],
    options: {
      low: 0,
      showArea: true,
      fullWidth: false
    }
  };
  // Line chart 2
  lineChart2: Chart = {
    type: 'Line',
    data: data['Line'],
    options: {
      low: 0,
      showArea: true,
      fullWidth: true
    }
  };
  // Line chart 2
  lineChart3: Chart = {
    type: 'Line',
    data: data['Line2'],
    options: {
      low: 0,
      showArea: true,
      fullWidth: true
    }
  };
  // Scatter chart
  scatterChart1: Chart = {
    type: 'Line',
    data: data['Scatter'],
    options: {
      showLine: false,
      axisX: {
        labelInterpolationFnc: function(value: number, index: number): string {
          return index % 13 === 0 ? `W${value}` : null;
        }
      }
    },
    responsiveOptions: [
      [
        'screen and (min-width: 640px)',
        {
          axisX: {
            labelInterpolationFnc: function(
              value: number,
              index: number
            ): string {
              return index % 4 === 0 ? `W${value}` : null;
            }
          }
        }
      ]
    ]
  };
  // Pie chart
  pieChart1: Chart = {
    type: 'Pie',
    data: data['Pie'],
    options: {
      donut: true,
      donutWidth: 50,
      startAngle: 270,
      total: 200,
      showLabel: false
    }
  };
  donuteChart1: Chart = {
    type: 'Pie',
    data: data['Pie'],
    options: {
      donut: true,
      showLabel: false
    }
    // events: {
    //   draw(data: any): boolean {
    //     return data;
    //   }
    // }
  };
  // Bi Poller chart
  bipollarChart1: Chart = {
    type: 'Bar',
    data: data['Bi-PolarBar'],
    options: {
      high: 10,
      low: -10,
      axisX: {
        labelInterpolationFnc: function(value: number, index: number): number {
          return index % 2 === 0 ? value : null;
        }
      }
    }
  };
  dataValue: any =[];


// ngAfterViewInit() {
//   (<any>$('#ravenue')).sparkline([6, 10, 9, 11, 9, 10, 12], {
//     type: 'bar',
//     height: '55',
//     barWidth: '4',
//     width: '100%',
//     resize: true,
//     barSpacing: '8',
//     barColor: '#16baf0'
//   });

//   const chart = c3.generate({
//     bindto: '#foo',
//     data: {
//       columns: [['data', 91.4]],
//       type: 'gauge'
//     },
//     gauge: {
//       label: {
//         format: function (value, ratio) {
//           return value;
//         },
//         show: false
//       },
//       min: 0,
//       max: 100,
//       units: ' %',
//       width: 15
//     },
//     legend: {
//       hide: true
//     },
//     size: {
//       height: 80
//     },
//     color: {
//       pattern: ['#24d2b5']
//     }
//   });


//   (<any>$('.bandwidth')).sparkline(
//     [4, 5, 0, 10, 9, 12, 4, 9, 4, 5, 3, 10, 9, 12, 10, 9, 12, 4, 9],
//     {
//       type: 'bar',
//       width: '100%',
//       height: '70',
//       barWidth: '2',
//       resize: true,
//       barSpacing: '6',
//       barColor: 'rgba(255, 255, 255, 0.3)'
//     }
//   );
//   (<any>$('.spark-count')).sparkline(
//     [4, 5, 0, 10, 9, 12, 4, 9, 4, 5, 3, 10, 9, 12, 10, 9, 12, 4, 9],
//     {
//       type: 'line',
//       width: '100%',
//       height: '70',
//       barWidth: '2',
//       resize: true,
//       fillColor: 'transparent',
//       lineColor: 'rgba(255, 255, 255, 0.6)'
//     }
//   );

//   }
  constructor(private _httpService: MakerService,private authservice: AuthService,
    private router: Router, private toastr: ToastrService) { }

ngOnInit() {
    this._httpService.centralQueueData().subscribe(data=>{
      this.centralExchange=(data);
      this.centralQueueData=this.centralExchange.data;
      console.log('eeeeee - ',data)
    })
    this._httpService.transactionHhistory().subscribe(data=>{
      //console.log("ngOnInit ::: ")
      this.trans_hist= (data);
      this.dataValue =this.trans_hist.data.reverse();
    })

    this._httpService.dashboardAPI().subscribe(res => {
      this.dashResponse =(res);
    })
}
ngAfterViewInit() {
  const chart = c3.generate({
    bindto: '#visitor',
    data: {
      columns: [['Invoice', 40], ['Bill of Exchange', 20], ['Bill of Lading', 30],  ['Airway Bill', 35],
      ['Certificate of origin', 25],  ['Packing List', 10]],

      type: 'donut'
    },
    donut: {
      label: {
        show: false
      },
      title: 'Trade Documents',
      width: 25
    },

    legend: {
      hide: true
      // or hide: 'data1'
      // or hide: ['data1', 'data2']
    },
    color: {
      pattern: ['#D7C5FE','#bfedfa','#ffffb2', '#B5F6D9', '#ffaa8b', '#ffd0e4']
    }
  });
}
// documents() {
//   this._httpService.listDocs().subscribe(
//       data => {
//           this.docsInfoData = (data);
//           const dataVal = this.docsInfoData.data;
//           console.log(dataVal.length);
//               console.log('dataVal', dataVal);
//               this.listOfDocs = dataVal;
//               console.log( this.listOfDocs);
//           } ,
//       error => {
//           console.log(error);
//           this.handleError(error);
//         },
//       () => console.log('created employee', this.docsInfoData));
// }  

handleError(error) {
  console.log('error', error.responseStatus);
  console.log('status code', error.msg);
  if (error.responseStatus === 401) {
      this.authservice.refresh().subscribe(
          data => {
              this.tokenInfo = (data);
              const dataVal = this.tokenInfo;
              if(this.tokenInfo.responseStatus === 200) {
                  localStorage.setItem('access_token', this.tokenInfo.access_token);
                 // this.documents();
              }
              } ,
          error => {
              console.log(error);
              this.handleError(error);
            },
          () => console.log('created employee', this.tokenInfo));
  } 
  if (error.responseStatus === 400) {
     console.log('error', error.message);
     //this.toastr.error( "", error.message);
  }   
}


pickUpPage(id){
  Swal.fire('Central Queue Document','Proceeding With : '+id,'info')
  .then(()=>{
    this._httpService.pickUpTransaction(id).subscribe(r=>{
      this.router.navigate(['maker/manual-reports-list']);
    })
  })
}
// routing to simba page wit id
aiPage(Id){
  console.log(Id)
  localStorage.setItem('id',Id);
  this.router.navigate(['maker/ai-reports'])

}

}


