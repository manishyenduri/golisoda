import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakerConsistentComponent } from './maker-consistent.component';

describe('MakerConsistentComponent', () => {
  let component: MakerConsistentComponent;
  let fixture: ComponentFixture<MakerConsistentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakerConsistentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakerConsistentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
