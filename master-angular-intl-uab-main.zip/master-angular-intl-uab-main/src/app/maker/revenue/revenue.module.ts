import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RevenueComponent } from './revenue.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
import { NgxSpinnerModule } from 'ngx-spinner';
const routes: Routes = [{
    path: '',
    data: {
        title: '',
        // urls: [{title: 'Bills', url: '/dashboard'}]
    },
    component: RevenueComponent
}];

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        NgbModule,
        RouterModule.forChild(routes),
        ReactiveFormsModule,
        HttpModule,
        NgxSpinnerModule
    ],
    declarations: [RevenueComponent],
    providers: [MakerService, AuthService]
})
export class RevenueModule { }
