import { Component } from '@angular/core';

@Component({
  selector: 'app-revenue-layout',
  templateUrl: './revenue.component.html',
  styleUrls: ['./revenue.component.scss']
})
export class RevenueComponent {}
