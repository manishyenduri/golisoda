import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NounReportComponent } from './noun-report.component';

describe('NounReportComponent', () => {
  let component: NounReportComponent;
  let fixture: ComponentFixture<NounReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NounReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NounReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
