import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-noun-report',
  templateUrl: './noun-report.component.html',
  styleUrls: ['./noun-report.component.css']
})
export class NounReportComponent implements OnInit {

  getId:any;
  exchangeData:any;
  switchViewBoolean:boolean;
  exchangeCardData:any;
  cardRules:boolean;
  view1Data:any;
  leftRuleImg:SafeResourceUrl;
  rightRuleImg:SafeResourceUrl;  
  rightData:any;
  openAll:boolean;
  css_count:any=0;
  openSearchEnable:boolean;
  urlPDF:any;
  urlView2High:any;
  selectedRow: any;

  highNoData:any;
  remitBoolean:boolean;

  JSON_data=[
    {remitterData:[], len:3,checkpoints:0},
    {bankDetails:[], len:2,checkpoints:0},
    {benficiaryDetails:[], len:0,checkpoints:0},
    {billerDetails:[], len:0,checkpoints:0},
    {sellerDetails:[], len:0,checkpoints:0},
    {portDetails:[],len:0,checkpoints:0}
  ]
  // remitterData:any;
  // bankDetails:any;
  // benficiaryDetails:any;
  // billerDetails:any;
  // sellerDetails:any;
  
  remitters_name_Snip:SafeResourceUrl;
  remitters_address_Snip:SafeResourceUrl;
  remitters_name:any;
  remitters_add:any;

  templeng:any;
  constructor(private _httpService:MakerService,private router:Router ,private sanitizer:DomSanitizer, private modalService:NgbModal) { }

  ngOnInit() {
    this.remitBoolean=false;
    this.openAll=false;
    this.openSearchEnable=false;
    this.cardRules=false;
    this.switchViewBoolean=true;
    this.getId=localStorage.getItem('Noun_id');
    this._httpService.getNounReportByID().subscribe(r=>{
      this.exchangeData=(r);
      
      if(this.exchangeData.result.status==="processing"){
        Swal.fire("Document "+this.getId,'Processing','info').then(()=>{
          this.router.navigate(['maker/noun-list'])
        })
      }
      this.urlPDF=this.sanitizer.bypassSecurityTrustResourceUrl(this.exchangeData.result.pdf_path);
      this.rightRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl(this.exchangeData.result.pdf_path);

      if(this.exchangeData.result.extraction.remitter_details.remitter_name_snippet_img===''){this.exchangeData.result.extraction.remitter_details.remitter_name_snippet_img=null}
      if(this.exchangeData.result.extraction.remitter_details.remitter_address_snippet_img===''){this.exchangeData.result.extraction.remitter_details.remitter_address_snippet_img=null}
      if(this.exchangeData.result.extraction.remitter_details.remitted_amount_snippet_img===''){this.exchangeData.result.extraction.remitter_details.remitted_amount_snippet_img=null}

      if(this.exchangeData.result.extraction.remitter_details.remitter_name===''){this.exchangeData.result.extraction.remitter_details.remitter_name="No data"}
      if(this.exchangeData.result.extraction.remitter_details.remitter_address===''){this.exchangeData.result.extraction.remitter_details.remitter_address="No data"}
      if(this.exchangeData.result.extraction.remitter_details.remitted_amount===''){this.exchangeData.result.extraction.remitter_details.remitted_amount="No data"}

      
      if(this.exchangeData.result.extraction.benficiary_details.benficiary_name_snippet_img===''){this.exchangeData.result.extraction.benficiary_details.benficiary_name_snippet_img=null}
      if(this.exchangeData.result.extraction.benficiary_details.benficiary_address_snippet_img===''){this.exchangeData.result.extraction.benficiary_details.benficiary_address_snippet_img=null}
      if(this.exchangeData.result.extraction.benficiary_details.bank_name_snippet_img===''){this.exchangeData.result.extraction.benficiary_details.bank_name_snippet_img=null}
      if(this.exchangeData.result.extraction.benficiary_details.bank_address_snippet_img===''){this.exchangeData.result.extraction.benficiary_details.bank_address_snippet_img=null}
      
      if(this.exchangeData.result.extraction.benficiary_details.benficiary_name===''){this.exchangeData.result.extraction.benficiary_details.benficiary_name="No data"}
      if(this.exchangeData.result.extraction.benficiary_details.benficiary_address===''){this.exchangeData.result.extraction.benficiary_details.benficiary_address="No data"}
      if(this.exchangeData.result.extraction.benficiary_details.bank_name===''){this.exchangeData.result.extraction.benficiary_details.bank_name="No data"}
      if(this.exchangeData.result.extraction.benficiary_details.bank_address===''){this.exchangeData.result.extraction.benficiary_details.bank_address="No data"}
     
      if(this.exchangeData.result.extraction.biller_details.biller_details_snippet_img===''){this.exchangeData.result.extraction.biller_details.biller_details_snippet_img=null}
      if(this.exchangeData.result.extraction.biller_details.biller_details_snippet_img===''){this.exchangeData.result.extraction.biller_details.biller_details_snippet_img=null}

      if(this.exchangeData.result.extraction.biller_details.biller_address===''){this.exchangeData.result.extraction.biller_details.biller_address="No data"}
      if(this.exchangeData.result.extraction.biller_details.biller_name===''){this.exchangeData.result.extraction.biller_details.biller_name="No data"}

      if(this.exchangeData.result.extraction.seller_details.seller_details_snippet_img===''){this.exchangeData.result.extraction.seller_details.seller_details_snippet_img=null}
      if(this.exchangeData.result.extraction.seller_details.seller_details_snippet_img===''){this.exchangeData.result.extraction.seller_details.seller_details_snippet_img=null}
     
      if(this.exchangeData.result.extraction.seller_details.seller_address===''){this.exchangeData.result.extraction.seller_details.seller_address="No data"}
      if(this.exchangeData.result.extraction.seller_details.seller_name===''){this.exchangeData.result.extraction.seller_details.seller_name="No data"}
     

      this.JSON_data[0].remitterData = [{title:'Remitter Name',data: this.exchangeData.result.extraction.remitter_details.remitter_name, snip_url:this.exchangeData.result.extraction.remitter_details.remitter_name_snippet_img, highlight_Url:this.exchangeData.result.extraction.remitter_details.remitter_name_highlighted_img},
      {title:'Remitter Address',data: this.exchangeData.result.extraction.remitter_details.remitter_address, snip_url:this.exchangeData.result.extraction.remitter_details.remitter_address_snippet_img, highlight_Url:this.exchangeData.result.extraction.remitter_details.remitter_address_highlighted_img},
      {title:'Remitter Amount',data: this.exchangeData.result.extraction.remitter_details.remitted_amount, snip_url:this.exchangeData.result.extraction.remitter_details.remitted_amount_snippet_img, highlight_Url:this.exchangeData.result.extraction.remitter_details.remitted_amount_highlighted_img},
    ];


    this.JSON_data[2].benficiaryDetails = [{title:'Benficiary Name',data: this.exchangeData.result.extraction.benficiary_details.benficiary_name, snip_url:this.exchangeData.result.extraction.benficiary_details.benficiary_name_snippet_img, highlight_Url:this.exchangeData.result.extraction.benficiary_details.benficiary_name_highlighted_img},
    {title:'Benficiary Address',data: this.exchangeData.result.extraction.benficiary_details.benficiary_address, snip_url:this.exchangeData.result.extraction.benficiary_details.benficiary_address_snippet_img, highlight_Url:this.exchangeData.result.extraction.benficiary_details.benficiary_address_highlighted_img},
    {title:'Bank Name',data: this.exchangeData.result.extraction.benficiary_details.bank_name, snip_url:this.exchangeData.result.extraction.benficiary_details.bank_name_snippet_img, highlight_Url:this.exchangeData.result.extraction.benficiary_details.bank_name_highlighted_img},
    {title:'Bank Address',data: this.exchangeData.result.extraction.benficiary_details.bank_address, snip_url:this.exchangeData.result.extraction.benficiary_details.bank_address_snippet_img, highlight_Url:this.exchangeData.result.extraction.benficiary_details.bank_address_highlighted_img},
    // {title:'Bank Name',data: this.exchangeData.result.extraction.benficiary_details.remitted_amount, snip_url:this.exchangeData.result.extraction.benficiary_details.remitted_amount_snippet_img, highlight_Url:this.exchangeData.result.extraction.benficiary_details.remitted_amount_highlighted_img},
  ];

  this.JSON_data[3].billerDetails=[{title:'Biller Address',data: this.exchangeData.result.extraction.biller_details.biller_address, snip_url:this.exchangeData.result.extraction.biller_details.biller_details_snippet_img, highlight_Url:this.exchangeData.result.extraction.biller_details.biller_details_highlighted_img},
  {title:'Biller Name',data: this.exchangeData.result.extraction.biller_details.biller_name, snip_url:this.exchangeData.result.extraction.biller_details.biller_details_snippet_img, highlight_Url:this.exchangeData.result.extraction.biller_details.biller_details_highlighted_img},
  // {title:'Bank Name',data: this.exchangeData.result.extraction.benficiary_details.bank_name, snip_url:'', highlight_Url:''},
  // {title:'Bank Address',data: this.exchangeData.result.extraction.benficiary_details.bank_address, snip_url:'', highlight_Url:''},
  // {title:'Bank Name',data: this.exchangeData.result.extraction.benficiary_details.remitted_amount, snip_url:this.exchangeData.result.extraction.benficiary_details.remitted_amount_snippet_img, highlight_Url:this.exchangeData.result.extraction.benficiary_details.remitted_amount_highlighted_img},
];

  this.JSON_data[4].sellerDetails=[{title:'Seller Address',data: this.exchangeData.result.extraction.seller_details.seller_address, snip_url:this.exchangeData.result.extraction.seller_details.seller_details_snippet_img, highlight_Url:this.exchangeData.result.extraction.seller_details.seller_details_highlighted_img},
      {title:'Seller Name',data: this.exchangeData.result.extraction.seller_details.seller_name, snip_url:this.exchangeData.result.extraction.seller_details.seller_details_snippet_img, highlight_Url:this.exchangeData.result.extraction.seller_details.seller_details_highlighted_img},
    ];
  if(this.exchangeData.result.extraction.bank_details.bank_details!='')
    {
      this.JSON_data[1].bankDetails = [{title:'Bank Detils',data: this.exchangeData.result.extraction.bank_details.bank_details, snip_url:this.exchangeData.result.extraction.bank_details.bank_details_snippet_img, highlight_Url:this.exchangeData.result.extraction.bank_details.bank_details_highlighted_img},
      ];
    }else{this.JSON_data[1].bankDetails =[{title:'Bank Detils',data:'No data', snip_url:null, highlight_Url:null}]}
  
    if(this.exchangeData.result.extraction.port_details.port_details!='')
    {
      this.JSON_data[5].portDetails = [{title:'Port Detils',data: this.exchangeData.result.extraction.port_details.port_details, snip_url:this.exchangeData.result.extraction.port_details.port_details_snippet_img, highlight_Url:this.exchangeData.result.extraction.port_details.port_details_highlighted_img},
      ];
    }else{this.JSON_data[5].portDetails =[{title:'Port Detils',data:'No data', snip_url:null, highlight_Url:null}]}
  
      // this.templeng=this.JSON_data[0].remitterData;
      // console.log("DDD - ",this.templeng);
      // this.calcLength(this.JSON_data[0].remitterData);
      // this.JSON_data[0].len=this.JSON_data[0].remitterData.length;
      
      // this.JSON_data[1].bankDetails = this.exchangeData.result.extraction.bank_details;
      // this.JSON_data[2].benficiaryDetails = this.exchangeData.result.extraction.benficiary_details;
      // this.JSON_data[3].billerDetails = this.exchangeData.result.extraction.biller_details;
      // this.JSON_data[4].sellerDetails = this.exchangeData.result.extraction.seller_details;

      this.remitters_name_Snip=this.sanitizer.bypassSecurityTrustResourceUrl(this.exchangeData.result.extraction.remitter_details.remitter_name_snippet_img);
      this.remitters_name=this.exchangeData.result.extraction.remitter_details.remitter_name;
      this.remitters_add=this.exchangeData.result.extraction.remitter_details.remitter_address;
      this.remitters_address_Snip=this.sanitizer.bypassSecurityTrustResourceUrl(this.exchangeData.result.extraction.remitter_details.remitter_address_snippet_img);
      
      if(this.exchangeData.result.extraction.remitter_details.checkpoints != '')
      this.JSON_data[0].checkpoints= this.exchangeData.result.extraction.remitter_details.checkpoints;
      if(this.exchangeData.result.extraction.bank_details.checkpoints != '')
          this.JSON_data[1].checkpoints= this.exchangeData.result.extraction.bank_details.checkpoints;
      if(this.exchangeData.result.extraction.benficiary_details.checkpoints != '')
          this.JSON_data[2].checkpoints= this.exchangeData.result.extraction.benficiary_details.checkpoints;
      if(this.exchangeData.result.extraction.biller_details.checkpoints != '')
          this.JSON_data[3].checkpoints= this.exchangeData.result.extraction.biller_details.checkpoints;
      if(this.exchangeData.result.extraction.seller_details.checkpoints != '')
          this.JSON_data[4].checkpoints= this.exchangeData.result.extraction.seller_details.checkpoints;
      if(this.exchangeData.result.extraction.port_details.checkpoints != '')
          this.JSON_data[5].checkpoints= this.exchangeData.result.extraction.port_details.checkpoints;
      
    })
   
  }

  calcLength(data){
    for(var i=0;i<data.length;i++){
      console.log("data - ",data[i])
    }
  }

  changeView(){
    this.switchViewBoolean=!this.switchViewBoolean;
    console.log('Change-view : ', this.switchViewBoolean)
  }

  getDetails(data){
    this.cardRules=true;
    this.view1Data=data;
    this.onCard(data[0],0);
  }

  onCard(data,i){
    this.selectedRow = i;
    if(data.highlight_Url!='' && data.highlight_Url!=null)
      this.leftRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl(data.highlight_Url);
    else
      this.leftRuleImg=null;

    if(data.data !='No data')
      this.highNoData='';
    else
      this.highNoData='No document';
    

    if(data.snip_url!=null)
      this.rightRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl(data.snip_url);
    else
      this.rightRuleImg=null;

    this.rightData=data.data;
  }
  
zoomin() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
}

openSnippet(content) {
  this.modalService.open(content, { size: 'lg' });
}


openAllFunc(a){    
  this.css_count=1;
  this.openSearch();
  this.openAll=!this.openAll;
}

openSearch(){
  if(this.css_count===0)
  {
    this.openSearchEnable=true;
    // document.getElementById('search').style.opacity = '1';
    this.css_count++;
  }else{
    this.openSearchEnable=false;
    // document.getElementById('search').style.opacity = '0';
    this.css_count--;

  }
}

viewAOF(content){
  this.modalService.open( content, { size: 'lg' });
  this.openSearchEnable=false;
}
opendRemit(){
  this.remitBoolean=!this.remitBoolean;
}
openViewHighlight(content,highData){
  this.modalService.open( content, { size: 'lg' });
  this.urlView2High=this.sanitizer.bypassSecurityTrustResourceUrl(highData);
}
copyAOF(data){
  data.decision=data.data;
}
}
