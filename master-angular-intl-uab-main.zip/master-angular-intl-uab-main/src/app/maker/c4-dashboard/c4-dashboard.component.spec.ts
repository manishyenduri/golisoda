import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { C4DashboardComponent } from './c4-dashboard.component';

describe('C4DashboardComponent', () => {
  let component: C4DashboardComponent;
  let fixture: ComponentFixture<C4DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ C4DashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(C4DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
