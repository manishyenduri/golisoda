import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-noun-lists',
  templateUrl: './noun-lists.component.html',
  styleUrls: ['./noun-lists.component.css']
})
export class NounListsComponent implements OnInit {

  exchangeData:any;
  fileToUpload:any;
  id_res:any;
  uploadResponse:any;
  access:any;

  constructor(private router:Router, private _httpService:MakerService,  private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.access=false;
    // return;
    // this._httpService.getNounList().subscribe(r=>{
    //   this.exchangeData=(r);
    //   console.log("exss ",this.exchangeData)
    //   this.exchangeData.reverse();
    // },err=>{
    //   console.log("Error -> ",err.error.message)
    // })
  }

  uploadDocument(event){
    this.fileToUpload=event.target.files[0];
    this.spinner.show();
    setTimeout(()=>{
      this.spinner.hide();},240000)
    this._httpService.generateNounID2().subscribe(r=>{
      console.log("Response - ",r);
      this.id_res=(r);
      this._httpService.uploadNoun(this.fileToUpload,this.id_res.request_id).subscribe(r=>{
        this.uploadResponse = (r);
        this.spinner.hide();
        console.log("Upload Response - ",this.uploadResponse);
        Swal.fire(this.uploadResponse.message,
          this.id_res.request_id+'<br/>'+'Document '+ this.uploadResponse.status,
          'success');
          this._httpService.getNounList().subscribe(r=>{
            this.exchangeData=(r);
            console.log("exss ",this.exchangeData)
            this.exchangeData.reverse();
          },err=>{
            console.log("Error -> ",err.error.message)
          })
      })
    },err=>{
        this.spinner.hide();
    })
  }
  openNouns(id){
    localStorage.setItem('Noun_id',id);
    this.router.navigate(['/maker/noun-report'])
  }

}
