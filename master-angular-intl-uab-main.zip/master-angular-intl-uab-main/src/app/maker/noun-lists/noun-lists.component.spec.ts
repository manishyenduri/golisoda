import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NounListsComponent } from './noun-lists.component';

describe('NounListsComponent', () => {
  let component: NounListsComponent;
  let fixture: ComponentFixture<NounListsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NounListsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NounListsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
