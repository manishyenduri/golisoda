import { Component, OnInit } from '@angular/core';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { DomSanitizer } from '@angular/platform-browser';
import {
  NgbModal,
  ModalDismissReasons,
  NgbActiveModal
} from '@ng-bootstrap/ng-bootstrap';
import { Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/timer';
@Component({
  selector: 'app-rectify-doc',
  templateUrl: './rectify-doc.component.html',
  styleUrls: ['./rectify-doc.component.css']
})
export class RectifyDocComponent implements OnInit {
  lcDoc: any;
  invDoc: any;
  boeDoc: any;
  awbDoc: any;
  bolDoc: any;
  docs: any;
  docUploadSatus: any;
  analyzeSatus: any;
  onProcess = false;
  reqs_id: any= null;
  res: any = "";
  localRes:any;
//variables holding card values
cardFileName: any=[];
cardData:any;
cardUrl:any;
cardInv: any;
cardBoe: any;
cardBol: any;
cardIns: any;
cardLoc: any;
cardCoo: any;
cardAwb: any;
//----------------------
  
  fileToUpload: File = null;
  fileId:any=null;
  // uploadBtn:boolean = true;
  // analyzeBtn:boolean = false;
  tcode:any;

  request_id: any;
  tokenInfo: any;
  beforeUpload:boolean = true;
  afterUpload:boolean = false;
  closeResult: string;
  showloader: boolean;
  timer: any;
  subscription: any;

  exchangeReponse:any;
  
    constructor(private router: Router,private _httpService: MakerService, private modalService: NgbModal,
      private authservice: AuthService, private spinner: NgxSpinnerService, private toastr: ToastrService,private sanitizer: DomSanitizer) { 
        this.docs = {lcFile: '', invFile: '',boeFile: '',awbFile: '',bolFile: ''}
    }
    ngOnInit() {
    }
  
    loc(event: any) {
      if (event.target.files.length > 0) {
          this.lcDoc = event.target.files[0].name;
          this.docs.lcFile = event.target.files[0];
        } 
       this.setTimer();
    }
    invoice(event: any) {
      if (event.target.files.length > 0) {
          this.invDoc = event.target.files[0].name;
          this.docs.invFile = event.target.files[0];
        } 
    }
    boe(event: any) {
      if (event.target.files.length > 0) {
          this.boeDoc = event.target.files[0].name;
          this.docs.boeFile = event.target.files[0];
        } 
    }
    awb(event: any) {
      if (event.target.files.length > 0) {
          this.awbDoc = event.target.files[0].name;
          this.docs.awbFile = event.target.files[0];
        } 
    }
    bol(event: any) {
      if (event.target.files.length > 0) {
          this.bolDoc = event.target.files[0].name;
          this.docs.bolFile = event.target.files[0];
        } 
    }
    uploadDocs() {
      var id='XASD877655';
        this.spinner.show();
        console.log('upload docs', this.docs);
        this._httpService.upload(this.docs,id).subscribe(
          data => {
              this.docUploadSatus = (data);
              this.request_id = this.docUploadSatus.request_id;
              if((this.docUploadSatus.responseStatus === 200) && (this.docUploadSatus.request_id != null)) {
                this._httpService.analyze(this.request_id).subscribe(
                  data => {
                      this.analyzeSatus = (data);
                      this.request_id = this.docUploadSatus.request_id;
                      if(this.analyzeSatus.responseStatus === 200) {
                        this.spinner.hide();
                        this.router.navigate(['/maker/documents']);
                      }
                      } ,
                  error => {
                      console.log(error);
                      // this.handleError(error);
                    },
                  () => console.log('created employee', this.analyzeSatus)
                );
              }
              } ,
          error => {
              this.spinner.hide();
              console.log(error);
              this.handleError(error);
            },
          () => console.log('created employee', this.docUploadSatus)
        );
    }
  
    public setTimer(){
      // set showloader to true to show loading div on view
      this.spinner.show();
  
      this.timer        = Observable.timer(5000); // 5000 millisecond means 5 seconds
      this.subscription = this.timer.subscribe(() => {
          // set showloader to false to hide loading div from view after 5 seconds
          this.spinner.hide();
          this.afterUpload = true;
          this.beforeUpload = false;
          console.log(this.tcode); //Testing Purpose. Remove it once API is integrated.
      });
    }
  
    onAnalyze() {

      this.spinner.show();
  
      this.timer        = Observable.timer(500); // 5000 millisecond means 5 seconds
      this.subscription = this.timer.subscribe(() => {
          // set showloader to false to hide loading div from view after 5 seconds
          this.spinner.hide();
          Swal.fire({
            title: '<strong>Document check completed</strong>',
            type: 'success',
            showCloseButton: true,
            showCancelButton: true,
            focusConfirm: false,
            confirmButtonText: 'Generate SIMBA Report',
            cancelButtonText: 'Manual Scrutiny',
          }).then((result) => {
            if (result.value) {
               Swal.fire({
                title: 'SIMBA Report Generated!',
                text: "Do you want to view the report?",
                type: 'success',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
              }).then((result) => {
                if (result.value) {
                  this.router.navigate(['./maker/ai-reports']);
                  window.scroll(0,0);
                }
              })
            } else {
              this.router.navigate(['./maker/manual-reports']);
              window.scroll(0,0);
            }
          })
      });
    }

    onAnalyze2() {
  
      this.spinner.show();
  
      this.timer        = Observable.timer(5000); // 5000 millisecond means 5 seconds
      this.subscription = this.timer.subscribe(() => {
          // set showloader to false to hide loading div from view after 5 seconds
          this.spinner.hide();
          Swal.fire({
            title: '<strong>Document check completed</strong>',
            type: 'success',
            showCloseButton: true,
            showCancelButton: true,
            focusConfirm: false,
            confirmButtonText: 'Generate AI Report',
            cancelButtonText: 'Generate Manual Report',
          }).then((result) => {
            if (result.value) {
               Swal.fire({
                title: 'AI Report Generated!',
                text: "Do you want to view the report?",
                type: 'success',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
              }).then((result) => {
                if (result.value) {
                  this.router.navigate(['./maker/AIreport']);
                  window.scroll(0,0);
                }
              })
            } else {
              this.router.navigate(['./maker/ManualReport']);
              window.scroll(0,0);
            }
          })
      });
    }
  
    viewLC(image1) {
      this.modalService.open(image1, { size: 'lg', backdrop: 'static' }).result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
    }
    viewInvoice(image2) {
      this.modalService.open(image2, { size: 'lg', backdrop: 'static' }).result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
    }
  
    viewBOE(image3) {
      this.modalService.open(image3, { size: 'lg', backdrop: 'static' }).result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
    }
    private getDismissReason(reason: any): string {
      if (reason === ModalDismissReasons.ESC) {
        return 'by pressing ESC';
      } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
        return 'by clicking on a backdrop';
      } else {
        return `with: ${reason}`;
      }
    }
    handleError(error) {
      console.log('error', error.responseStatus);
      console.log('status code', error.msg);
      if (error.responseStatus === 401) {
          this.authservice.refresh().subscribe(
              data => {
                  this.tokenInfo = (data);
                  const dataVal = this.tokenInfo;
                  if(this.tokenInfo.responseStatus === 200) {
                      localStorage.setItem('access_token', this.tokenInfo.access_token);
                      this.router.navigate(['/maker/upload']);
                  }
                  } ,
              error => {
                  console.log(error);
                  this.handleError(error);
                },
              () => console.log('created employee', this.tokenInfo));
      } 
      if (error.responseStatus === 400) {
          console.log('error', error.message);
          this.toastr.error( "", error.message);
       }   
    }

    uploadFile(event:any) {

       this.spinner.show();
        this.fileToUpload=event.target.files[0];
        console.log("tcode",this.tcode);
        console.log("this.fileToUpload",this.fileToUpload)
       this._httpService.rectifiedDocUpload(this.fileToUpload,this.tcode).subscribe(
         data =>{
           this.exchangeReponse = (data);
           console.log("sss",this.exchangeReponse);
           this.spinner.hide();
           this.reqs_id=this.exchangeReponse.request_id;
          //localStorage.setItem('id',this.tcode); //Temporary 
           Swal.fire({
            title: "Document uploaded",
            html: data.message + '<br/>'+ 'Transaction_Id : ' + this.exchangeReponse.request_id,
            confirmButtonText:'Process',
          }).then(()=>{
            this.onProcess=true;
            this._httpService.processRectified(this.exchangeReponse.request_id).subscribe(r=>
              {
              // this.exchangeReponse = (r);
              console.log(r)
              const dataId =r;//res.job_id
              console.log(data)
               this.res =dataId
               console.log("FCA66PJMOCFCA66PJMOCFCA66PJMOC",r);
              })
              this.setTimer2();
              Swal.fire({
                
                title: "Document Upload",
                html: 'Processing Rectified Uploaded Documents' ,
                confirmButtonText:'Process',
              }).then(()=>{
                
              this._httpService.processedDocs(this.reqs_id).subscribe(rev_data=>{
                this.localRes=(rev_data);
                // this.setTimer();
                console.log("###################:",this.localRes)
                // if(this.localRes.responseStatus === 200)
                {
                 this.onProcess=false;
                  let i; 
                  for(i = 0 ; i < this.localRes.data.length;i++){
                    this.cardInv = this.localRes.data[i].url
                   this.cardFileName[i]= this.transform(this.cardInv);
                  }
                  
                //  console.log(this.cardFileName[0]);
               
                  this.cardData = this.localRes.data;
                  console.log("this.cardData*****************************",this.cardData)
                 // this.cardUrl = rev_data.data[1].url;
                  this.cardUrl = this.transform(this.localRes.data[0].url);
                  Swal.fire({
                    title: "Document Processed",
                    confirmButtonText:'View'
                  }).then(()=>{
                  //  this.setTimer();
                    // this.spinner.show();
                    this._httpService.processedDocs(this.reqs_id).subscribe(rev_data=>{
                    // if(this.localRes.responseStatus === 200)
                    // this.spinner.hide();
                    {
                     this.onProcess=false;
                      let i; 
                      for(i = 0 ; i < this.localRes.data.length;i++){
                        this.cardInv = this.localRes.data[i].url
                       this.cardFileName[i]= this.transform(this.cardInv);
                      }
                      
                    //  console.log(this.cardFileName[0]);
                   
                      this.cardData = this.localRes.data;
                     // this.cardUrl = rev_data.data[1].url;
                      this.cardUrl = this.transform(this.localRes.data[0].url);
                    }
                    // this.setTimer();
                  })
                })}
              })
              // this.setTimer();
            })
            });


          }); 
 
    }

    public setTimer2(){
      // set showloader to true to show loading div on view
      this.spinner.show();
  
      this.timer        = Observable.timer(180000); // 5000 millisecond means 5 seconds
      this.subscription = this.timer.subscribe(() => {
          // set showloader to false to hide loading div from view after 5 seconds
          this.spinner.hide();
          this.afterUpload = true;
      });
    }
  
    transform(url)
    {
      return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }

  }
  
