import { Component, OnInit } from '@angular/core';
import {ViewChild, ElementRef, AfterViewInit} from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { MakerService } from 'src/app/services/maker/docs.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
declare var $:JQueryStatic;

@Component({
  selector: 'app-maker-summery',
  templateUrl: './maker-summery.component.html',
  styleUrls: ['./maker-summery.component.css']
})
export class MakerSummeryComponent implements OnInit {
  
  exchangeResponse:any;
  lcImg:any;
  lcData:any;
  supportImg:any;
  supportData:any;
  supportTitle:any;
  summaryResponse:any;
  makerComment:any;
  checkerComment:any;
  commentData:any;
  articleResponse:any;
  article_Msg:any;
  commentData2:any;
  modalData:any;
  exchangeAlert:any;
  openView1:boolean;
  classOpenView:any;
  docView1:any;
  openView2:boolean;
  classOpenView2:any;
  docView2:any;

modalTitle:any;

  constructor(private _httpService:MakerService,private sanitizer:DomSanitizer , private toastr:ToastrService,private router: Router, private modalService: NgbModal) { }

  ngOnInit() {
    this.openView1=false;
    this.openView2=false;
    this.classOpenView="classView1false";
     document.getElementById("defaultOpen1").click();
    //  summary api call
    this._httpService.makerSummarry(localStorage.getItem('id')).subscribe(data=>
      {
        this.exchangeResponse = (data);
        this.summaryResponse = this.exchangeResponse.data;
        console.log("datadatadatadatadatadata :::",this.summaryResponse)
      })
      // var str = "Yeah_so_many_underscores here";
      // var newStr = str.replace(/_/g, " ");
      
      this._httpService.overallMakerComment(localStorage.getItem('id')).subscribe(r=>{
        console.log("Comment:",(r));
        this.commentData = (r);
       // console.log("Comment:",temp.data.makerComments);
        //this.makerComment = temp;
      })
  }

  openCity(evt, cityName) {
    if(cityName=="Invoice"){
      document.getElementById("defaultOpen1").style.background  = "#a90000";
      document.getElementById("defaultOpen1").style.color  = "#ffff";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
       }
    if(cityName=="Exchange"){
      document.getElementById("defaultOpen2").style.background  = "#a90000";
      document.getElementById("defaultOpen2").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
       }
    if(cityName=="Lading"){
      document.getElementById("defaultOpen3").style.background  = "#a90000";
      document.getElementById("defaultOpen3").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
       }
    if(cityName=="Certificate"){
      document.getElementById("defaultOpen4").style.background  = "#a90000";
      document.getElementById("defaultOpen4").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
      }
    if(cityName=="Insurance"){
      document.getElementById("defaultOpen5").style.background  = "#a90000";
      document.getElementById("defaultOpen5").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
      }
    if(cityName=="S_W_Bill"){
      document.getElementById("defaultOpen6").style.background  = "#a90000";
      document.getElementById("defaultOpen6").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
      }
    if(cityName=="C_Inv"){
      document.getElementById("defaultOpen7").style.background  = "#a90000";
      document.getElementById("defaultOpen7").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
      }
    if(cityName=="S_O"){
      document.getElementById("defaultOpen8").style.background  = "#a90000";
      document.getElementById("defaultOpen8").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
     }
    if(cityName=="B_C"){
      document.getElementById("defaultOpen9").style.background  = "#a90000";
      document.getElementById("defaultOpen9").style.color  = "#fff";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen5").style.color  = "";
      document.getElementById("defaultOpen10").style.background  = "";
      document.getElementById("defaultOpen10").style.color  = "";
     
    }

    if(cityName==="P_L"){
      document.getElementById("defaultOpen10").style.background  = "#a90000";
      document.getElementById("defaultOpen10").style.color  = "#fff";
      document.getElementById("defaultOpen9").style.background  = "";
      document.getElementById("defaultOpen9").style.color  = "";
      document.getElementById("defaultOpen1").style.background  = "";
      document.getElementById("defaultOpen2").style.background  = "";
      document.getElementById("defaultOpen3").style.background  = "";
      document.getElementById("defaultOpen4").style.background  = "";
      document.getElementById("defaultOpen6").style.background  = "";
      document.getElementById("defaultOpen8").style.background  = "";
      document.getElementById("defaultOpen7").style.background  = "";
      document.getElementById("defaultOpen7").style.color  = "";
      document.getElementById("defaultOpen8").style.color  = "";
      document.getElementById("defaultOpen6").style.color  = "";
      document.getElementById("defaultOpen1").style.color  = "";
      document.getElementById("defaultOpen2").style.color  = "";
      document.getElementById("defaultOpen3").style.color  = "";
      document.getElementById("defaultOpen4").style.color  = "";
      document.getElementById("defaultOpen5").style.background  = "";
      document.getElementById("defaultOpen5").style.color  = "";
    }
    
    var i, tabcontent, tablinks ;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";

    }
 
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace("active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += "active";

}

ClickMe(a_name) {
  console.log(a_name)
  const article_Id = a_name
  this._httpService.getArticleId(article_Id).subscribe(
    res => {
      this.articleResponse = (res)
      this.article_Msg = this.articleResponse.data;
      console.log('Msg view', this.article_Msg);
      Swal.fire({
        title: article_Id,
        text: this.articleResponse.data,
        // imageUrl: 'https://unsplash.it/400/200',
        imageWidth: 400,
        imageHeight: 200,
        imageAlt: 'Custom image',
      })
    },
    error => {
      console.log(error)
    },
    () => console.log('created Article'));

  //Alert(this.article_Msg);

}



openXl(content,data,title){
  this.openView1=false;
  this.openView2=false;
  console.log('Imgs - ',data)
  this.modalData=data;
  this.modalTitle=data.ruleName;
  this.commentData2="";
  this.supportTitle=title;
  this.lcImg=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi+data.sentence[0].cropped_image);
  this.lcData=data.sentence[0].word_set;
  this.supportImg=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi+data.sentence[1].cropped_image);
  this.supportData=data.sentence[1].word_set;
  this.modalService.open(content, {size:'lg'});
}

updateComment(data){
  console.log("modalData -> ",this.modalData)
  this._httpService.manualNoteToChecker(this.commentData2,localStorage.getItem('id'),this.modalData.ruleId,data).subscribe(r=>{
    console.log("R -> -> ",r)
    this.exchangeAlert=(r);
    if(this.exchangeAlert.code === 200)
    {  this.toastr.success("Checkpoint Updated");
      this._httpService.makerSummarry(localStorage.getItem('id')).subscribe(data=>
        {
          this.exchangeResponse = (data);
          this.summaryResponse = this.exchangeResponse.data;
          console.log("datadatadatadatadatadata :::",this.summaryResponse)
        });
    }else{
      this.toastr.error("Error Occured",this.exchangeAlert.message);
    }
  });
  
  this.modalService.dismissAll();
}
openView(){
  this.openView1=!this.openView1;
  if(this.openView1)
    this.classOpenView="classView1";
  else
    this.classOpenView="classView1false"

  this.docView1=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi+this.modalData.sentence[0].annotated_image_full)
}
openView2Func(){
  
  this.openView2=!this.openView2;
  if(this.openView2)
    this.classOpenView2="classView1";
  else
    this.classOpenView2="classView1false";

  this.docView2=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi+this.modalData.sentence[1].annotated_image_full)
}
saveLC(){
  let data={
    "name": this.modalData.ruleName,
    "value": this.lcData
  }
  console.log("dtata - ",data)
  this._httpService.processLCUpdate(localStorage.getItem('id'),data).subscribe(r=>{
    console.log("r-- ",r)
    this.toastr.success('Updated!');
    this._httpService.makerSummarry(localStorage.getItem('id')).subscribe(data=>
      {
        this.exchangeResponse = (data);
        this.summaryResponse = this.exchangeResponse.data;
        console.log("datadatadatadatadatadata :::",this.summaryResponse)
      })
  })
}
saveDoc(){
  let data={
    "_id": this.modalData.ruleId,
    "value": this.supportData
  }
  console.log("dtata - ",data)
  this._httpService.processDocUpdate(localStorage.getItem('id'),data).subscribe(r=>{
    console.log("r-- ",r)
    this.toastr.success('Updated!');
    this._httpService.makerSummarry(localStorage.getItem('id')).subscribe(data=>
      {
        this.exchangeResponse = (data);
        this.summaryResponse = this.exchangeResponse.data;
        console.log("datadatadatadatadatadata :::",this.summaryResponse)
      })
  })
}

 
zoomin() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
}
// 
zoomin_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
} 
backTo(){
  this.router.navigate(['maker/maker-compliant'])
}
  
}
