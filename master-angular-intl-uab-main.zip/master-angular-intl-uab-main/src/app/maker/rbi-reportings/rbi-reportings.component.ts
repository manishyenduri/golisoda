import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rbi-reportings',
  templateUrl: './rbi-reportings.component.html',
  styleUrls: ['./rbi-reportings.component.css']
})
export class RbiReportingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
