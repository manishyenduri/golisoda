
import { Component, Input, OnInit } from '@angular/core';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
// import '';
import {
  NgbModal,
  ModalDismissReasons,
  NgbActiveModal
} from '@ng-bootstrap/ng-bootstrap';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import Swal from 'sweetalert2';
import { manualSendtocheckerModalComponent } from '../manualReport/sendtochecker-modal/sendtochecker-modal.component';
import { from, empty } from 'rxjs';
import { freemem } from 'os';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';
// import $ from "jquery";
declare var $:JQueryStatic;

@Component({
  selector: 'app-maker-compliant',
  templateUrl: './maker-compliant.component.html',
  styleUrls: ['./maker-compliant.component.css']
})
export class MakerCompliantComponent implements OnInit {

  rulesData: any;
  ruleItems: any;
  listOfRules: any;
  tokenInfo: any;
  request_id: any;
  listOfSegregatedRules: any;
  requestResponse: any;
  accuracy: any;
  leftRuleImg: SafeResourceUrl;
  rightRuleImg: SafeResourceUrl;
  leftImage: any;
  rightImage: any;
  rule_id: any;
  swb:any;
  ruleExists: boolean = false;
  leftTitle=[]; //any;
  rightTitle=[];//: any;
  rule: any;
  firstRuleId: any;
  FirstruleExists: boolean = false;
  nextRule: boolean = false;
  dropdown: boolean = false;
  cardRules: boolean = false;
  public counter: number = 1;
  public currentItem: any;
  rule_name: any;
  selectedRow: any;
  closeResult: string;
  boe: any;
  bol: any;
  dataValue: any = [];
  insurance: any;
  com:any;
  coo: any;
  awb: any;
  soo:any;
  ben:any;
  pl:any;
  ofacVariable:any;
  ofacMessage:any;
  ofacStatus:any;
  rightTopic:any;

  img_arry_inv:any;
  img_arry_boe:any;
  img_arry_awb:any;
  img_arry_coo:any;
  lc_arry_coo:any;
  lc_arry_boe:any;
  lc_arry_awb:any;
  img_arry_ins:any;
  lc_arry_ins:any;

  right_hand_img_set:any;
  left_hand_img_set:any;
  lc_img_inv:any;
  support_snippet:any;

  //By Pratik
  ofac_stat:any;
  CompliantRemarks:any;
  statusSent:any="";
  CompNoteResponse:any;
  modalRef: any;
  exchangeHSN:any;
  HSNBoolean:boolean;

  imgLCsnippet:any;

  lcEdit:boolean;
  lcVar:any;
  docID:any;
  docEdit:boolean;

  constructor(private toastr:ToastrService,private _httpService: MakerService,private authservice: AuthService, private modalService: NgbModal,
    private spinner: NgxSpinnerService,  private router: Router,public sanitizer: DomSanitizer) { 
  }
ngOnInit() {
  this.lcEdit=false;
  this.docEdit=false;
  this.rightTopic="";
  this.rules();
  this.HSNBoolean=false;
  this.ofacVariable="";
  this.ofacMessage="Pending";
  this.ofacStatus="Pending";
  this.request_id = localStorage.getItem('id');
  this.img_arry_inv=['../../../assets/img-doc/invoice/invoice_1_annotated_full.png','../../../assets/img-doc/invoice/invoice_2_annotated_full.png', '../../../assets/img-doc/invoice/invoice_3_annotated_full.png', '../../../assets/img-doc/invoice/invoice_4_annotated_full.png'];
  this.lc_img_inv=['../../../assets/img-doc/Letter_Of_Credit/invoice_1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/invoice_2_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/invoice_3_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/invoice_4_annotated_full.png'];
  
  this.img_arry_boe=['../../../assets/img-doc/bill_of_exchange/boe_1_annotated_full.png','../../../assets/img-doc/bill_of_exchange/1.png'];
  this.lc_arry_boe=['../../../assets/img-doc/Letter_Of_Credit/boe_1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/boe_1_annotated_full.png'];

  this.img_arry_awb=['../../../assets/img-doc/airway_bill/awb_1_annotated_full.png','../../../assets/img-doc/airway_bill/awb_3_annotated_full.png'];
  this.lc_arry_awb=['../../../assets/img-doc/Letter_Of_Credit/awb_1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/awb_3_annotated_full.png'];

  this.img_arry_ins=['../../../assets/img-doc/insurance/ins1_annotated_full.png','../../../assets/img-doc/insurance/ins2_annotated_full.png','../../../assets/img-doc/insurance/1.png','../../../assets/img-doc/insurance/1.png'];
  this.lc_arry_ins=['../../../assets/img-doc/Letter_Of_Credit/ins1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/ins2_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/ins3_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/ins4_annotated_full.png'];

  this.img_arry_coo=['../../../assets/img-doc/certificate_of_origin/coo1_annotated_full.png','../../../assets/img-doc/certificate_of_origin/coo2_annotated_full.png','../../../assets/img-doc/certificate_of_origin/coo3_annotated_full.png','../../../assets/img-doc/certificate_of_origin/coo4_annotated_full.png'];
  this.lc_arry_coo=['../../../assets/img-doc/Letter_Of_Credit/coo1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/coo2_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/coo3_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/coo4_annotated_full.png'];
  this.right_hand_img_set=[];
  // invoice_1_annotated_full

this._httpService.getHSN_data().subscribe(r=>{
  
  this.exchangeHSN=(r);
  console.log("Data - ",this.exchangeHSN.data[0].hsn_code)
})


}
  
editLC(){
  this.lcEdit=!this.lcEdit;
}
editDoc(){
  this.docEdit=!this.docEdit;
}
saveLC(){
  let data={
    "name": this.lcVar,
    "value": this.leftTitle
  }
  console.log("dtata - ",data)
  this._httpService.processLCUpdate(localStorage.getItem('id'),data).subscribe(r=>{
    console.log("r-- ",r)
    this.toastr.success('Updated!');
  })
  this.editLC();
}
saveDoc(){
  let data={
    "_id": this.docID,
    "value": this.rightTitle
  }
  console.log("dtata - ",data)
  this._httpService.processDocUpdate(localStorage.getItem('id'),data).subscribe(r=>{
    console.log("r-- ",r)
    this.toastr.success('Updated!');
  })
  this.editDoc();
}

rules() {
  this._httpService.getRequestById().subscribe(
      data => {
        console.log("Check Data",data);
          this.rulesData = (data);
          const dataVal = this.rulesData.data;
          this.dataValue = data
          this.ruleItems = this.rulesData.data;
          console.log(dataVal.length);
          console.log('dataVal', dataVal);
          this.listOfRules = dataVal.inv.length;
          this.boe = dataVal.boe.length;
          this.bol =dataVal.bol.length;
          this.awb = dataVal.awb.length;
          this.coo = dataVal.coo.length;
          this.insurance =dataVal.ins.length; 
          this.swb=dataVal.swb.length;
          this.soo=dataVal.soo.length;
          this.ben=dataVal.ben.length;
          this.pl=dataVal.pl.length;
          if(dataVal.com===undefined)
            this.com=0;
          else
            this.com=dataVal.com.length;
          
          console.log( this.listOfRules);
        } ,
        error => {
            console.log(error);
            this.handleError(error);
          },
        () => console.log('created employee', this.rulesData));

  // this._httpService.ofac_status().subscribe(r=>{
  //   this.ofac_stat=(r);
  //   console.log("OFAC Status - ",this.ofac_stat);
  // })
} 
comply(remarks: any)  {
  this.modalService.open(remarks, { size: 'lg', backdrop: 'static' }).result.then(
    result => {
      this.closeResult = `Closed with: ${result}`;
    },
    reason => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    }
  );
}
reject(descrepantremarks: any)  {
  this.modalService.open(descrepantremarks, { size: 'lg', backdrop: 'static' }).result.then(
    result => {
      this.closeResult = `Closed with: ${result}`;
    },
    reason => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    }
  );
}
private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}
exchangeOfac:any;
proceedOfac(){
  this._httpService.ofacVerification(localStorage.getItem('id'),this.ofacVariable).subscribe(r=>{
    console.log('xsdsdssxx ',r)
    this.exchangeOfac=(r);
    this.ofacMessage=this.exchangeOfac.data.message;
    this.ofacStatus=this.exchangeOfac.data.status;
    console.log('OFAC 1 -- ',this.ofacMessage, this.ofacStatus)
  })
}


openOfacFunc(content, data){
  this.modalService.open(content, { size: 'lg', backdrop: 'static' }).result.then(
    result => {
      this.closeResult = `Closed with: ${result}`;
    },
    reason => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    }
  );

  this.ofacVariable=data;
}
//  Swal.fire(
  // 'OFAC',this.ofac_stat.data.ofac_trade.ofac_explain,'info'
  // )
//Working Function On onInit
firstRuleDetails(firstRuleId: any) {
  this.FirstruleExists = true;
  this.nextRule = false;
  console.log('first rule', firstRuleId);
  const request_id = this.request_id;
  this.rule_id = firstRuleId;
  this._httpService.getRuleById(request_id,this.rule_id).subscribe(
      data => {
          this.requestResponse = (data);
          // if(this.requestResponse.responseStatus === 200) 
          {
              this.ruleExists = false;
              this.nextRule = false;
              // this.remarksBtn = true;
              // this.statusBtn = false;
              // this.noremarksBtn = true;
          const dataVal = this.requestResponse.data;
          console.log("Dataval -> ",this.requestResponse)
          for (const item of dataVal) {
                this.accuracy = item.accuracy;
                console.log('accuracy', this.accuracy);
                const image = item.sentence;
                console.log('left', image[0].annotated_image_full);
                console.log('right', image[1].annotated_image_full);
                this.leftTitle = image[0].word_set;
                //var a = image[0].word_set;
                //console.log("toArray",a.toArray())
                this.rightTitle = image[1].word_set;
                console.log("ssssssssssssssssssssssssssssssss",image[0].word_set,  image[1].word_set)
//Working Higlight 
                console.log("Cross Display:::::",item.sentence[0].missing_words_1)
                var mapWithLeft = item.sentence[0].missing_words_1;
                var mapWithRight = item.sentence[1].missing_words_2;
                var leftCoordinates =  item.sentence[0].missing_indices1;
                var rightCoordinates = item.sentence[1].missing_indices2;
                this.MissingWord(this.leftTitle,this.rightTitle,mapWithLeft,mapWithRight,leftCoordinates, rightCoordinates);               
                //this.Highlight(this.leftTitle,this.rightTitle);
               
//End
              //  'http://139.59.3.158:8990' 
              //  'http://139.59.3.158:8990'
                this.leftImage =   environment.imageEndPointApi + image[0].annotated_image_full;
                this.rightImage =  environment.imageEndPointApi + image[1].annotated_image_full;
                this.imgLCsnippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[0].cropped_image);
                this.leftRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.leftImage);
                this.rightRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.rightImage);//this.right_hand_img_set[0]);//this.rightImage);
                this.support_snippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[1].cropped_image);
                // this.imgLCsnippet=environment.imageEndPointApi + image[0].cropped_image;
              }
          }
          } ,
      error => {
          console.log(error);
          // this.handleError(error);
        },
      () => console.log('created employee', this.requestResponse)
    );
}


clearOfac(){
  this.ofacMessage="Pending";
  this.ofacStatus="Pending";
}
getInvoice() {
  this.rightTopic="Invoice";
 console.log('on invoice', this.dataValue.data.inv);
 console.log("his.dataValue.data.invhis.dataValue.data.inv",this.dataValue.data.inv)
 this.listOfSegregatedRules = this.dataValue.data.inv;
 this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
 this.firstRuleDetails(this.firstRuleId);
 this.dropdown = true;
 this.counter = 1;
 this.cardRules = true;
 this.HSNBoolean = false;
//  this.left_hand_img_set=this.lc_img_inv;
//  this.right_hand_img_set=this.img_arry_inv;
}
makerHSN(){
 this.cardRules = false;
  this.HSNBoolean = true;
}

getBOE() {
  this.rightTopic="Bill Of Exchange";
  console.log('on BOE', this.dataValue.data.boe);
  this.listOfSegregatedRules = this.dataValue.data.boe;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
  this.left_hand_img_set=this.lc_arry_boe;
  this.right_hand_img_set=this.img_arry_boe;

}

getTRD() {
  console.log('on bol', this.dataValue.data.bol);
  this.listOfSegregatedRules = this.dataValue.data.bol;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
 this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
}
getAwl() {
  this.rightTopic="Air Way Bill";
  console.log('on air way bill', this.dataValue.data.awb);
  this.listOfSegregatedRules = this.dataValue.data.awb;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
  
 this.left_hand_img_set=this.lc_arry_awb;
 this.right_hand_img_set=this.img_arry_awb;
  
 }
 getCo() {
  this.rightTopic="Certificate Of Origin";
  console.log('on invoice', this.dataValue.data.coo);
  this.listOfSegregatedRules = this.dataValue.data.coo;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
  
 this.left_hand_img_set=this.lc_arry_coo;
 this.right_hand_img_set=this.img_arry_coo;
 }
 getInsurance() {
  this.rightTopic="Insurance";
  console.log('on invoice', this.dataValue.data.ins);
  this.listOfSegregatedRules = this.dataValue.data.ins;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
  this.left_hand_img_set=this.lc_arry_ins;
  this.right_hand_img_set=this.img_arry_ins;
 }
 getswb() {
  this.rightTopic="Sea Way Bill";
  console.log('on invoice', this.dataValue.data.swb);
  this.listOfSegregatedRules = this.dataValue.data.swb;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
 }
 getCom() {
  this.rightTopic="Commercial Invoice";
  console.log('on invoice', this.dataValue.data.com);
  this.listOfSegregatedRules = this.dataValue.data.com;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
 }
 getsoo(){
  this.rightTopic="Statement of Origin";
    console.log('on invoice', this.dataValue.data.soo);
  this.listOfSegregatedRules = this.dataValue.data.soo;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
 }
 getben(){
  this.rightTopic="Benificiary Certificate";
  console.log('on invoice', this.dataValue.data.ben);
  this.listOfSegregatedRules = this.dataValue.data.ben;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
 }
 getPl(){
  this.rightTopic="Packing List";
  console.log('on invoice', this.dataValue.data.pl);
  this.listOfSegregatedRules = this.dataValue.data.pl;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean = false;
 }
onView(ruleId: any) {
  this.spinner.show();
  console.log(ruleId.target.value);
  const request_id = this.request_id;
  this.rule_id = ruleId.target.value;
  this._httpService.getRuleById(request_id,this.rule_id).subscribe(
      data => {
          this.requestResponse = (data);
          //if(this.requestResponse.responseStatus === 200) 
          {
              this.spinner.hide();
              this.ruleExists = true;
          const dataVal = this.requestResponse.data;
          for (const item of dataVal) {
                this.accuracy = item.accuracy;
                console.log('accuracy', this.accuracy);
                const image = item.sentence;
                console.log('left', image[0].annotated_image_full);
                console.log('right', image[1].annotated_image_full);
                this.leftTitle = image[0].word_set;
                console.log("leftTitleleftTitleleftTitle",this.leftTitle)
                this.rightTitle = image[1].word_set;
                // 'http://139.59.3.158:8990'
                this.leftImage = environment.imageEndPointApi + image[0].annotated_image_full;
                this.rightImage =  environment.imageEndPointApi + image[1].annotated_image_full;
                this.leftRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.leftImage);
                this.rightRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.right_hand_img_set[0]);
                this.imgLCsnippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[0].cropped_image);
                this.support_snippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[1].cropped_image);
              }
          }
          } ,
      error => {
          console.log(error);
          this.handleError(error);
        },
      () => console.log('created employee', this.requestResponse)
    );
}

goToNext() {
  console.log('on next rule');
  this.ruleItems = this.listOfSegregatedRules;
  console.log(this.ruleItems, this.ruleItems.length);
  if (this.counter > this.ruleItems.length) {
   this.counter = this.ruleItems.length;
   this.router.navigate(['/maker/documents']);
  } else {
   console.log('counter', this.counter);
   this.currentItem = this.ruleItems[this.counter];
   console.log('this.currentItem', this.currentItem);
   console.log('rule', this.currentItem.rule_id);
   this.counter++;
   const request_id = this.request_id;
   this.rule_id = this.currentItem.rule_id;
   this.rule_name = this.currentItem.name;
   this._httpService.getRuleById(request_id,this.rule_id).subscribe(
       data => {
           this.requestResponse = (data);
           //if(this.requestResponse.responseStatus === 200) 
           {
               this.spinner.hide();
               this.FirstruleExists = false;
               this.ruleExists = false;
               this.nextRule = true;
           const dataVal = this.requestResponse.data;
           for (const item of dataVal) {
                 this.accuracy = item.accuracy;
                 console.log('accuracy', this.accuracy);
                 const image = item.sentence;
                 console.log('left', image[0].annotated_image_full);
                 console.log('right', image[1].annotated_image_full);
                 this.leftTitle = image[0].word_set;
                 this.rightTitle = image[1].word_set;
                 this.leftImage = /*'http://139.59.3.158:8990'*/environment.imageEndPointApi + image[0].annotated_image_full;
                 this.rightImage = /*'http://139.59.3.158:8990'*/environment.imageEndPointApi + image[1].annotated_image_full;
                 this.leftRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.leftImage);
                 this.rightRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.right_hand_img_set[0]);
                 this.imgLCsnippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[0].cropped_image);
                 this.support_snippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[1].cropped_image);
               }
           }
           } ,
       error => {
           console.log(error);
           // this.handleError(error);
         },
       () => console.log('created employee', this.requestResponse)
     );
  }
}

scroll(el: HTMLElement) {
el.scrollIntoView();
}

onCard(selectedItem: any,i: any) {
  console.log('onCard',selectedItem);
  this.lcVar=selectedItem.description;
  this.selectedRow = i;
  this.spinner.show();
   console.log(selectedItem.rule_id);
   const request_id = this.request_id;
   this.rule_id = selectedItem.rule_id;
   this.docID=this.rule_id;
   // var index = this.allRules.indexOf(this.rule_id);
   // console.log('index', index);
   // this.counter = index + 1;
   this._httpService.getRuleById(request_id,this.rule_id).subscribe(
       data => {
        
 
 
           this.requestResponse = (data);
           //if(this.requestResponse.responseStatus === 200) 
           {
               this.spinner.hide();
               this.ruleExists = true;
           const dataVal = this.requestResponse.data;
           for (const item of dataVal) {
                 this.accuracy = item.accuracy;
                 console.log('accuracy', this.accuracy);
                 const image = item.sentence;
                 console.log('left', image[0].annotated_image_full);
                 console.log('right', image[1].annotated_image_full);
                 this.leftTitle = image[0].word_set;
                 this.rightTitle = image[1].word_set;
                 
                 var mapWithLeft = item.sentence[0].missing_words_1;
                 var mapWithRight = item.sentence[1].missing_words_2;
                 
                 var leftCoordinates =  item.sentence[0].missing_indices1;
                 var rightCoordinates = item.sentence[1].missing_indices2;
                 this.MissingWord(this.leftTitle,this.rightTitle,mapWithLeft,mapWithRight,leftCoordinates,rightCoordinates);  
                 //this.Highlight(this.leftTitle,this.rightTitle);
                 this.leftImage = /*'http://139.59.3.158:8990'*/ environment.imageEndPointApi+ image[0].annotated_image_full;
                 this.rightImage = /*'http://139.59.3.158:8990'*/ environment.imageEndPointApi+ image[1].annotated_image_full;
                 this.leftRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.leftImage);
                 this.rightRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.rightImage);
                 this.imgLCsnippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[0].cropped_image);
                 this.support_snippet=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + image[1].cropped_image);
               }
           }
           var newElem = this.leftTitle
           var oldElem = this.rightTitle
           } ,
       error => {
           console.log(error);
           // this.handleError(error);
         },
       () => console.log('created employee', this.requestResponse)
     );
 }
handleError(error) {
  console.log('error', error.responseStatus);
  console.log('status code', error.msg);
  if (error.responseStatus === 401) {
      this.authservice.refresh().subscribe(
          data => {
              this.tokenInfo = (data);
              const dataVal = this.tokenInfo;
              //if(this.tokenInfo.responseStatus === 200)
               {
                  localStorage.setItem('access_token', this.tokenInfo.access_token);
                  this.rules();
              }
              } ,
          error => {
              console.log(error);
              this.handleError(error);
            },
          () => console.log('created employee', this.tokenInfo));
  }   
}

backTo() {
  this.router.navigate(['maker/4c-dashboard'])
}
makerSummery(){
  this.router.navigate(['maker/maker-summery'])
}

  noteToChecker()
  {
    
    //console.log(this.CompliantRemarks)
    //console.log("localStorage.getItem('id')",localStorage.getItem('id'),this.CompliantRemarks,localStorage.getItem('id'),this.rule_id, this.statusSent)
    this._httpService.manualNoteToChecker(this.CompliantRemarks,localStorage.getItem('id'),this.rule_id, this.statusSent)
    .subscribe(res=>{
      this.CompNoteResponse = (res);
      if(this.CompNoteResponse.code === 200)
      {
        
        //document.getElementById('compliantRemark').style.display = 'none';
        Swal.fire(
          'Successful',
          'Updated!',
          'success'
        )
      }
        else
        if(this.CompNoteResponse.code === 500)
          Swal.fire(
            'Oops!',
            'Internal Server Error',
            'error'
          )
      }
    );

    this.clearVariables();
 // console.log("33333333333333333333333333333",this.rule_id)
  }

  sendtochecker($event){
    this.modalRef = this.modalService.open(manualSendtocheckerModalComponent);
  }

  // 
zoomin() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
}
// 
zoomin_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
} 
  clearVariables(){
    this.CompliantRemarks="";
    this.statusSent="";
  }


  MissingWord(left,right,leftLimit,rightLimit,leftCoordinates, rightCoordinates){

      //Manipulation Variables
      var trimmedLeftString =[];
      var trimmedRightString=[];
      //Spliting string into characters
      var leftString = left.split('');
      var rightString = right.split('');
      console.log("leftLimit",leftLimit)
      console.log("leftLimit",rightLimit)
      //Trimming Empty cell from the last of the array
     if(leftString[leftString.length-1] === '' || leftString[leftString.length - 1] === ' ' || leftString[leftString.length - 1] === undefined)
     {
      for(var i=0;i<leftString.length - 1;i++){
        trimmedLeftString[i] = leftString[i];
      }
     }else{
      trimmedLeftString=leftString;
     }
     if(rightString[rightString.length-1] === '' || rightString[rightString.length - 1] === ' ' || rightString[rightString.length - 1] === undefined)
     {
      for(var i=0;i<rightString.length - 1;i++){
        trimmedRightString[i] = rightString[i];
      }
     }else{
      trimmedRightString=rightString;
     }

     console.log("trimmedLeftString ::::", trimmedLeftString);
     console.log("trimmedRightString :::",trimmedRightString);
     console.log("DATATDAADARAD",leftCoordinates, rightCoordinates)
     
     var text='';
     if(leftCoordinates.length>0){
      for(var i=0;i<trimmedLeftString.length;i++){
        var j=0;
        var found=0;
        while(j<leftCoordinates.length){
          if(leftCoordinates[j]===i){
            text += "<span style='background-color:#F2C2B9'>"+trimmedLeftString[i]+"</span>";
            found=1;
            break;
          }
          j++;
        }
        if(found != 1){
          text += trimmedLeftString[i];
        }
      }
     }else{
       for(var i=0;i<trimmedLeftString.length;i++){
         text += trimmedLeftString[i];
       }
     }
      
     $('#new').html(text);


     var text='';
     if(rightCoordinates.length>0){
      for(var i=0;i<trimmedRightString.length;i++){
        var j=0;
        var found=0;
        while(j<rightCoordinates.length){
          if(rightCoordinates[j]===i){
            text += "<span style='background-color:#F2C2B9'>"+trimmedRightString[i]+"</span>";
            found=1;
            break;
          }
          j++;
        }
        if(found != 1){
          text += trimmedRightString[i];
        }
      }
     }else{
       for(var i=0;i<trimmedRightString.length;i++){
         text += trimmedRightString[i];
       }
     }
      
     $('#old').html(text);
     
     
  }
  navigator(data){
    this.router.navigate([data]);
  }

}
