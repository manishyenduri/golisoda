import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakerCompliantComponent } from './maker-compliant.component';

describe('MakerCompliantComponent', () => {
  let component: MakerCompliantComponent;
  let fixture: ComponentFixture<MakerCompliantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakerCompliantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakerCompliantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
