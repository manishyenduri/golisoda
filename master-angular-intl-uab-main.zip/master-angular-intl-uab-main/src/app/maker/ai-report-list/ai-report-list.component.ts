import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MakerService } from 'src/app/services/maker/docs.service';
import { loadavg } from 'os';

@Component({
  selector: 'app-ai-report-list',
  templateUrl: './ai-report-list.component.html',
  styleUrls: ['./ai-report-list.component.css']
})
export class AiReportListComponent implements OnInit {
response:any;
variable:any;
compliantResponse=[];
discrepantResponse=[];
makerPendingResponse=[];
checkerPendingResponse=[];
pendingForBoth=[];
  constructor(private _httpService:MakerService,
    private router: Router) { 
   }

  ngOnInit() {
      this._httpService.cardSimbaReport().subscribe(res =>{
        this.response = (res);
        this.response.data.sort(this.custom_sort);
        this.variable = this.response.data.reverse();
        console.log("----------------------------",res)

        var j=0;
        var k=0;
        var m=0;
        var n=0;
        var z=0;
        for(var i=0;i<this.response.data.length;i++){
         
          if(this.response.data[i].transactionStatus === 'compliant')
          {
            this.compliantResponse[j]=this.response.data[i];
            j++;
          }
          else
          if(this.response.data[i].transactionStatus === 'discrepent')
          {
            this.discrepantResponse[k]=this.response.data[i];
            k++;
          }
          else
          if(this.response.data[i].transactionStatus === 'In Progress With Checker')
          {
            this.checkerPendingResponse[m]=this.response.data[i];
            m++;
          }
          else
          if(this.response.data[i].transactionStatus === 'In Progress With Maker')
          {
            this.makerPendingResponse[n]=this.response.data[i];
            n++;
          }
          else
          if(this.response.data[i].transactionStatus === 'pending')
          {
            this.pendingForBoth[z]=this.response.data[i];
            z++;
          }
        
         
        }
    //    console.log("TESTESTESTTEST :::: ",this.makerPendingResponse )
         // For loop to separate data cards
      // var j=0;
      // var k=0;
      // var m=0;
      // for(var i=0;i<this.response.data.length;i++){

      //   //console.log(this.response.data[i])
      //   if(this.response.data[i].transactionStatus === 'compliant')
      //   {
      //     this.compliantResponse[j] = this.response.data[i];
      //     j++;
      //   console.log("compliantResponsecompliantResponsecompliantResponse",this.compliantResponse[j])
      //   }
      //   else
      //   if(this.response.data[i].transactionStatus === 'discrepent')
      //   {  
      //     this.discrepantResponse[k] = this.response.data[i];
      //     k++;
      //   }
      //   else
      //   if(this.response.data[i].transactionStatus === 'In Progress With Checker')
      //   {
      //     this.pendingResponse[m] = this.response.data[i];
      //     m++;
      //   }
      // }
    
      });
  }
  routeToAIReport(id:any) {
    // console.log(id)
    localStorage.setItem('id',id);
    this.router.navigate(['maker/ai-reports'])
 }

//Logic for separating data into clusters 
custom_sort(a,b){
  return new Date(a.createdDate).getUTCDate() - new Date(b.createdDate).getUTCDate();
}

}
