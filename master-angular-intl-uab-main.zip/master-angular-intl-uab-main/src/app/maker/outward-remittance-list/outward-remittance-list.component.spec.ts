import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardRemittanceListComponent } from './outward-remittance-list.component';

describe('OutwardRemittanceListComponent', () => {
  let component: OutwardRemittanceListComponent;
  let fixture: ComponentFixture<OutwardRemittanceListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutwardRemittanceListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutwardRemittanceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
