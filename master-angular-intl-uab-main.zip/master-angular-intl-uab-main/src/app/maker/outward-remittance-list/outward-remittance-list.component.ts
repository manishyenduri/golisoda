import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';
import 'rxjs/add/observable/interval';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-outward-remittance-list',
  templateUrl: './outward-remittance-list.component.html',
  styleUrls: ['./outward-remittance-list.component.css']
})
export class OutwardRemittanceListComponent implements OnInit {
  exchangeData:any;
  fileToUpload:any;
  id_res:any;
  uploadResponse:any;
  access:boolean;
  sub:any;
  errorData:any;
  successData:any;
  processingData:any;
  constructor(private router:Router, private _httpService:MakerService,  private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.access=false;
    // if(localStorage.getItem('encpUser')!="M0001" && localStorage.getItem('encpUser')!="M0004")
    // {
    //   this.access=true;
    // }

    // if(localStorage.getItem('encpUser')!="M0001" && localStorage.getItem('encpUser')!="M0004")
    

    // this._httpService.getOutwardList().subscribe(r=>{
    //   this.exchangeData=(r);
    //   this.exchangeData.reverse();
    //   this.errorDataArray();
    // },err=>{
    //   console.log("Error -> ",err.error.message)
    // })

    // this.sub = Observable.interval(20000)
    // .subscribe(() => { 
    //   this._httpService.getOutwardList().subscribe(r=>{
    //     this.exchangeData=(r);
    //     this.exchangeData.reverse();
    //     this.errorDataArray();
    //   },err=>{
    //     console.log("Error -> ",err.error.message)
    //   })
    //  });
     
    // this.errorDataArray();
  }

  errorDataArray(){
    this.errorData=[];
    this.successData=[];
    for(var i=0;i<this.exchangeData.length;i++){
      if(this.exchangeData[i].status === 'error')
      {this.errorData.push(this.exchangeData[i]);
      console.log("this.exchangeData[i] - ",this.exchangeData)}
      else
      {
        this.successData.push(this.exchangeData[i]);
      }
      // if(this.exchangeData[i].status === '')
    }
    // console.log("this.errorData -",this.errorData)
  }

  uploadDocument(event){
    this.fileToUpload=event.target.files[0];
    this.spinner.show();
    setTimeout(()=>{
      this.spinner.hide();},600000)
    this._httpService.generateOutwardID().subscribe(r=>{
      console.log("Response - ",r);
      this.id_res=(r);
      this._httpService.uploadOutward(this.fileToUpload,this.id_res.request_id).subscribe(r=>{
        this.uploadResponse = (r);
        this.spinner.hide();
        console.log("Upload Response - ",this.uploadResponse);
        if(this.uploadResponse.message!=null)
        Swal.fire(this.uploadResponse.message,
          this.uploadResponse.request_id, //+'<br/>'+'Document '+ this.uploadResponse.status,
          'success');
        else
        Swal.fire("Document Process Status",
          "Failed", //+'<br/>'+'Document '+ this.uploadResponse.status,
          'error');
          this._httpService.getOutwardList().subscribe(r=>{
            this.exchangeData=(r);
            console.log("exss ",this.exchangeData)
            this.exchangeData.reverse();
            this.errorDataArray();
          },err=>{
            console.log("Error -> ",err.error.message)
          })
      })
    },err=>{
        this.spinner.hide();
    })
  }
  openNouns(id){
    localStorage.setItem('Outward_id',id);
    this.router.navigate(['/maker/outward-remittance-report'])
  }

  ngOnDestroy(){
    // if(localStorage.getItem('encpUser')==="M0001" || localStorage.getItem('encpUser')==="M0004")
    // this.sub.unsubscribe();
  }
}
