import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AIreportComponent } from './aireport.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
// import { SendtocheckerModalComponent } from './sendtochecker-modal/sendtochecker-modal.component';
const routes: Routes = [{
    path: '',
    data: {
        title: '',
        // urls: [{title: 'Bills', url: '/dashboard'}]
    },
    component: AIreportComponent
}];

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        NgbModule,
        RouterModule.forChild(routes),
        ReactiveFormsModule,
        HttpModule,
        NgxSpinnerModule,
        Ng2SearchPipeModule
    ],
    declarations: [AIreportComponent,],
    providers: [MakerService, AuthService],
    // entryComponents: [SendtocheckerModalComponent]
})
export class AIreportModule { }
