import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendtocheckerModalComponent } from './sendtochecker-modal.component';

describe('SendtocheckerModalComponent', () => {
  let component: SendtocheckerModalComponent;
  let fixture: ComponentFixture<SendtocheckerModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendtocheckerModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendtocheckerModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
