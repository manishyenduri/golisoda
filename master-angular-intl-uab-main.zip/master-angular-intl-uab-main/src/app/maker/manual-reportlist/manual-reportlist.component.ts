import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MakerService } from 'src/app/services/maker/docs.service';
import { forceManyBody } from 'd3';

@Component({
  selector: 'app-manual-reportlist',
  templateUrl: './manual-reportlist.component.html',
  styleUrls: ['./manual-reportlist.component.css']
})
export class ManualReportlistComponent implements OnInit {
  array=[];
  response:any;
  variable:any;
  compliantResponse=[];
  discrepantResponse=[];
  makerPendingResponse=[];
  checkerPendingResponse=[];
  pendingForBoth=[];
  exchangeArray=[];
  arra = [{id: "1", date: "Mar 11 2012 10:00:00 AM"}, 
  {id: "2", date: "Mar 11 2012 08:00:00 AM"}];
  reverseData=[];
  nCount:number=0;
  
  constructor(private _httpService:MakerService,
    private router: Router) { 
   }

  ngOnInit() {
    console.log('Date------------>',this.arra.length,this.arra.sort((a,b)=>{
      return new Date(a.date).getUTCMinutes() - new Date(b.date).getUTCMinutes(); 
    }))

    this._httpService.cardSimbaReport().subscribe(res =>{
      this.response = (res);
      this.variable = this.response.data.reverse();
      this.variable.sort(this.custom_sort);
      
      console.log("----------------------------",this.response.data.length);
     // console.log("hkjkjkjhvhgy",this.variable[3].createdDate)

      // for(var i=0; i<this.response.data.length;i++)
      //   this.array[i]= this.variable[i];
     // for(var i=0; i<this.response.data.length;i++)
     // this.array.sort((a,b)=> {return new Date(a.createdDate) - new Date(b.createdDate) })
      
     
//16th feb, 2020 ----- 15964 ₹
      var j=0;
      var k=0;
      var m=0;
      var n=0;
      this.nCount=0;
      var z=0;
      for(var i=0;i<this.response.data.length;i++){
       
        if(this.response.data[i].transactionStatus === 'compliant')
        {
          this.compliantResponse[j]=this.variable[i];//this.response.data[i];
          j++;
        }
        else
        if(this.response.data[i].transactionStatus === 'discrepent')
        {
          this.discrepantResponse[k]=this.variable[i];//this.response.data[i];
          k++;
        }
        else
        if(this.response.data[i].transactionStatus === 'In Progress With Checker')
        {
          this.checkerPendingResponse[m]=this.variable[i];//this.response.data[i];
          m++;
        }
        else
        if(this.response.data[i].transactionStatus === 'In Progress With Maker')
        {
          this.makerPendingResponse[n]=this.variable[i];//this.response.data[i];
          // for(var a=;a<n;a++)
          //   this.exchangeArray[a+1]=this.response.data[i];
          n++;
          console.log(this.makerPendingResponse[n])
        }
        else
        if(this.response.data[i].transactionStatus === 'pending')
        {
          this.pendingForBoth[z]=this.variable[i];//this.response.data[i];
          z++;
        }
      }
      this.nCount=n;
      this.makerPendingResponse.reverse();
      this.checkerPendingResponse.reverse();

    //  // console.log("makerPendingResponse",this.makerPendingResponse.length)
    //  var j=0;
    // for(var i=this.makerPendingResponse.length;i>=1;i++){
    //     this.reverseData[j]= this.makerPendingResponse[i];
    // }
    // console.log("sdsdsdsdsdaaaaaaaaaaaaa",this.reverseData)
    
    })

    
   
    //   //Sorting according to date
    //   var makerLength = this.makerPendingResponse.length;
    //   var reverse=[];
    //   var j=0;
    //   for(var i=makerLength; i>=0;i++){
    //     reverse[j]=this.makerPendingResponse[i];
    //     j++;
    //   }
    //  for(var i=0; i<makerLength;i++)
    //   {
    //     this.makerPendingResponse[i]=reverse[i];
    //   }
    //this.exchangeArray=this.makerPendingResponse;//.sort(this.custom_sort);
    
    console.log("this.exchangeArray",this.nCount, this.makerPendingResponse);
    
  }
  routeToManualReport(id:any) {
    
    localStorage.setItem('id',id);
    // this.router.navigate(['maker/manual-reports'])
    // this.router.navigate(['/maker/document/report'])
    // this.router.navigate(['maker/process-initiate'])
    this.router.navigate(['maker/4c-dashboard'])
 }

 custom_sort(a,b){
   return new Date(a.createdDate).getUTCDate() - new Date(b.createdDate).getUTCDate();
 }

}
