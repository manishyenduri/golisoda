import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { manualSendtocheckerModalComponent } from './sendtochecker-modal.component';

describe('SendtocheckerModalComponent', () => {
  let component: manualSendtocheckerModalComponent;
  let fixture: ComponentFixture<manualSendtocheckerModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ manualSendtocheckerModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(manualSendtocheckerModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
