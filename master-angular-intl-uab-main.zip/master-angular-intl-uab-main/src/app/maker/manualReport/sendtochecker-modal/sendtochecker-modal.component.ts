import { Component, OnInit } from '@angular/core';
import { NgbModal, NgbDropdown, NgbDropdownItem } from '@ng-bootstrap/ng-bootstrap';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sendtochecker-modal',
  templateUrl: './sendtochecker-modal.component.html',
  styleUrls: ['./sendtochecker-modal.component.css']
})
export class manualSendtocheckerModalComponent implements OnInit {
checkerList:any;
  checkerId:any="";
  comments: any="";
  requestId:any;
  response:any;
  trans_status:any="";
  temp: any;


  constructor(private _httpService: MakerService,private modalService: NgbModal,private activeModalService: NgbActiveModal) { }

  ngOnInit() {
    this._httpService.checkerList().subscribe(res=>{
      this.temp=(res);// console.log("resresresresresresresresresresresres",res)
     this.checkerList=this.temp.data;
     })
  }
  dismissModal() {
    this.activeModalService.close();
  }
  sendChecker(){
  
   console.log(this.checkerId);
   this.requestId = localStorage.getItem('id');
   console.log(this.requestId);
   console.log(this.comments)
   console.log(this.trans_status)

    this._httpService.sendToChecker(this.checkerId, this.comments, this.requestId, this.trans_status)
    .subscribe(r=>
      {
       // var res = (r)
       this.response = (r);
        console.log("PassedToChecker : ",this.response.code)
        if(this.response.code === 200)
        {
          this.dismissModal();
          Swal.fire(
            'Successful',
            'Sent to Checker',
            'success'
          )
        }
        else
        if(this.response.code === 500)
        {
          Swal.fire(
            'Sorry!',
            'Sending Failed, Internal Server Error!',
            'error'
          )
        }
       // if(r)
      });
    
  }
   
   
}
