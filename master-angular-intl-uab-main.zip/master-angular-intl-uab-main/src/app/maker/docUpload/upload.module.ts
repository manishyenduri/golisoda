import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UploadComponent } from './upload.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
// import { RectifyDocComponent } from '../../maker/rectify-doc/rectify-doc.component';
import { NgxSpinnerModule } from 'ngx-spinner';
const routes: Routes = [{
    path: '',
    data: {
        title: 'Documents Upload',
        // urls: [{title: 'Bills', url: '/dashboard'}]
    },
    component: UploadComponent
}];

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        NgbModule,
        RouterModule.forChild(routes),
        ReactiveFormsModule,
        HttpModule,
        NgxSpinnerModule
    ],
    declarations: [UploadComponent],
    providers: [MakerService, AuthService]
})
export class DocsUploadModule { }
