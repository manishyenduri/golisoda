import { Component, OnInit } from '@angular/core';
import { MakerService } from '../../services/maker/docs.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
//using domsanitizer for making the url correct
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
//--------
import {
  NgbModal,
  ModalDismissReasons,
  NgbActiveModal
} from '@ng-bootstrap/ng-bootstrap';
import { Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/timer';
@Pipe({
  name: 'safe'
})
@Component({
  selector: 'app-doc-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit, PipeTransform {

localRes:any;

reqs_id: any= null;
lcDoc: any;
invDoc: any;
boeDoc: any;
awbDoc: any;
bolDoc: any;
docs: any;
docUploadSatus: any;
analyzeSatus: any;
// uploadBtn:boolean = true;
// analyzeBtn:boolean = false;
request_id: any;
tokenInfo: any;
fileToUpload: File = null;

onProcess = false;

//variables holding card values
cardFileName: any=[];
cardData:any;
cardUrl:any;
cardInv: any;
cardBoe: any;
cardBol: any;
cardIns: any;
cardLoc: any;
cardCoo: any;
cardAwb: any;
//----------------------

afterUpload:boolean = false;
closeResult: string;
showloader: boolean;
timer: any;
subscription: any;
  res: any = "";

  constructor(private router: Router,private _httpService: MakerService, private modalService: NgbModal,
    private authservice: AuthService, private spinner: NgxSpinnerService, private toastr: ToastrService, private sanitizer: DomSanitizer) { 
      this.docs = {lcFile: '', invFile: '',boeFile: '',awbFile: '',bolFile: ''}
  }
  ngOnInit() {
  }

  exchangeID:any;
  uploadFile(event:any) {
    // this._httpService.generateNounID().subscribe(r=>{
      // Swal.fire()
      // this.exchangeID=(r)
      // console.log("Get-ID : ",this.exchangeID.request_id)
      this.spinner.show();
     this.fileToUpload=event.target.files[0];
   // const fileToUploadName = event.target.files[0].name;
   
      this._httpService.upload(this.fileToUpload/*,fileToUploadName*/,"dd").subscribe(
      data => {
        //console.log(data.message);
        this.reqs_id=data.request_id;
        // console.log("this.reqs_id ::: ",this.reqs_id)
        // console.log("ssssssssssssssssssssssssssssssssstatus: ",data.status);
        if(data.status=== true && this.reqs_id!=null){
          this.spinner.hide();
        }

        //console.log("2nd status: ",data.status);
        Swal.fire({
          title: "Document uploaded",
          html: data.message + '<br/>'+ 'Transaction_Id : ' + data.request_id,
          confirmButtonText:'Process',
        }).then(async ()=>{

         this.onProcess=true;
           this._httpService.analyze(this.reqs_id).subscribe( res => {
           console.log(res)
           const dataId =res;//res.job_id
           console.log(data)
            this.res =dataId
            })
          //    console.log(res.message);
          this.setTimer();
          await this.delay(5000)
          Swal.fire({
            title: "Document Upload",
            html: 'Processing Uploaded Documents' ,
            confirmButtonText:'OK',
          }).then(()=>{
            
          this._httpService.processedDocs(this.reqs_id).subscribe(rev_data=>{
            this.localRes=rev_data;
            // this.setTimer();
            console.log(this.localRes)
            // if(this.localRes.responseStatus === 200)
            {
             this.onProcess=false;
              let i; 
              for(i = 0 ; i < this.localRes.data.length;i++){
                this.cardInv = this.localRes.data[i].url
               this.cardFileName[i]= this.transform(this.cardInv);
              }
              
            //  console.log(this.cardFileName[0]);
           
              this.cardData = this.localRes.data;
             // this.cardUrl = rev_data.data[1].url;
              this.cardUrl = this.transform(this.localRes.data[0].url);
              Swal.fire({
                title: "Document Processed",
                confirmButtonText:'View'
              }).then(()=>{
              //  this.setTimer();
                // this.spinner.show();
                this._httpService.processedDocs(this.reqs_id).subscribe(rev_data=>{
                // if(this.localRes.responseStatus === 200)
                // this.spinner.hide();
                {
                 this.onProcess=false;
                  let i; 
                  for(i = 0 ; i < this.localRes.data.length;i++){
                    this.cardInv = this.localRes.data[i].url
                   this.cardFileName[i]= this.transform(this.cardInv);
                  }
                  
                //  console.log(this.cardFileName[0]);
               
                  this.cardData = this.localRes.data;
                 // this.cardUrl = rev_data.data[1].url;
                  this.cardUrl = this.transform(this.localRes.data[0].url);
                }
                // this.setTimer();
              })
            })}
          })
          // this.setTimer();
        })
        }
        )


      },
      error => {
       console.log(error)
        }//,
        //() => console.log()
    );
        // req_id=r.request_id;
    // },err=>{
    //   console.log("Error -> ",err.error.message)
    // })
    
     //this.setTimer();
  }

  //Function to bypass to make the url safe in html <embed>
  transform(url)
  {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  invoice(event: any) {
    if (event.target.files.length > 0) {
        this.invDoc = event.target.files[0].name;
        this.docs.invFile = event.target.files[0];
      } 
      var subfields
  }
  boe(event: any) {
    if (event.target.files.length > 0) {
        this.boeDoc = event.target.files[0].name;
        this.docs.boeFile = event.target.files[0];
      } 
  }
  awb(event: any) {
    if (event.target.files.length > 0) {
        this.awbDoc = event.target.files[0].name;
        this.docs.awbFile = event.target.files[0];
      } 
  }
  bol(event: any) {
    if (event.target.files.length > 0) {
        this.bolDoc = event.target.files[0].name;
        this.docs.bolFile = event.target.files[0];
      } 
  }

 delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
}
  uploadDocs() {
      this.spinner.show();
      console.log('upload docs', this.docs);
      this._httpService.upload(this.docs,this.exchangeID.request_id).subscribe(
        data => {
            this.docUploadSatus = (data);
            this.request_id = this.docUploadSatus.request_id;
            if((this.docUploadSatus.responseStatus === 200) && (this.docUploadSatus.request_id != null)) {
              this._httpService.analyze(this.request_id).subscribe(
                data => {
                    this.analyzeSatus = (data);
                    this.request_id = this.docUploadSatus.request_id;
                    if(this.analyzeSatus.responseStatus === 200) {
                      this.spinner.hide();
                      this.router.navigate(['/maker/documents']);
                    }
                    } , 
                error => {
                    console.log(error);
                    // this.handleError(error);
                  },
                () => console.log('created employee', this.analyzeSatus)
              );
            }
            } ,
        error => {
            this.spinner.hide();
            console.log(error);
            this.handleError(error);
          },
        () => console.log('created employee', this.docUploadSatus)
      );
  }

  public setTimer(){
    // set showloader to true to show loading div on view
    this.spinner.show();

    this.timer        = Observable.timer(5000); // 5000 millisecond means 5 seconds
    this.subscription = this.timer.subscribe(() => {
        // set showloader to false to hide loading div from view after 5 seconds
        this.spinner.hide();
        this.afterUpload = true;
    });
  }
  public set3Timer(){
    // set showloader to true to show loading div on view
    this.spinner.show();

    this.timer        = Observable.timer(180000); // 5000 millisecond means 5 seconds
    this.subscription = this.timer.subscribe(() => {
        // set showloader to false to hide loading div from view after 5 seconds
        this.spinner.hide();
        this.afterUpload = true;
    });
  }


  onAnalyze() {

    this.spinner.show();

    this.timer        = Observable.timer(500); // 5000 millisecond means 5 seconds
    this.subscription = this.timer.subscribe(() => {
        // set showloader to false to hide loading div from view after 5 seconds
        this.spinner.hide();
        Swal.fire({
          title: '<strong>Document check completed</strong>',
          type: 'success',
          showCloseButton: true,
          showCancelButton: true,
          focusConfirm: false,
          confirmButtonText: 'Generate SIMBA Report',
          cancelButtonText: 'Manual Scrutiny',
        }).then((result) => {
          if (result.value) {
             Swal.fire({
              title: 'SIMBA Report Generated!',
              text: "Do you want to view the report?",
              type: 'success',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes'
            }).then((result) => {
              if (result.value) {
                this.router.navigate(['./maker/ai-reports']);
                window.scroll(0,0);
              }
            })
          } else {
            this.router.navigate(['./maker/manual-reports']);
            window.scroll(0,0);
          }
        })
    });
  }

  viewLC(image1) {
    this.modalService.open(image1, { size: 'lg', backdrop: 'static' }).result.then(
      result => {
        this.closeResult = `Closed with: ${result}`;
      },
      reason => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  }
  viewInvoice(image2) {
    this.modalService.open(image2, { size: 'lg', backdrop: 'static' }).result.then(
      result => {
        this.closeResult = `Closed with: ${result}`;
      },
      reason => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  }

  viewBOE(image3) {
    this.modalService.open(image3, { size: 'lg', backdrop: 'static' }).result.then(
      result => {
        this.closeResult = `Closed with: ${result}`;
      },
      reason => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  handleError(error) {
    console.log('error', error.responseStatus);
    console.log('status code', error.msg);
    if (error.responseStatus === 401) {
        this.authservice.refresh().subscribe(
            data => {
                this.tokenInfo = (data);
                const dataVal = this.tokenInfo;
                console.log(dataVal,'dataVal')
                if(this.tokenInfo.responseStatus === 200) {
                    localStorage.setItem('access_token', this.tokenInfo.access_token);
                    this.router.navigate(['/maker/upload']);
                }
                } ,
            error => {
                console.log(error);
                this.handleError(error);
              },
            () => console.log('created employee', this.tokenInfo));
    } 
    if (error.responseStatus === 400) {
        console.log('error', error.message);
        this.toastr.error( "", error.message);
     }
  }
}
