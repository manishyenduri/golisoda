import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakerDocumentChartsComponent } from './maker-document-charts.component';

describe('MakerDocumentChartsComponent', () => {
  let component: MakerDocumentChartsComponent;
  let fixture: ComponentFixture<MakerDocumentChartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakerDocumentChartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakerDocumentChartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
