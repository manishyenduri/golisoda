import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenericOcrComponent } from './generic-ocr.component';

describe('GenericOcrComponent', () => {
  let component: GenericOcrComponent;
  let fixture: ComponentFixture<GenericOcrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenericOcrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericOcrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
