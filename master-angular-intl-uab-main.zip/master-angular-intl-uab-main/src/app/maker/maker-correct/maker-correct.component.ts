import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { MakerService } from 'src/app/services/maker/docs.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-maker-correct',
  templateUrl: './maker-correct.component.html',
  styleUrls: ['./maker-correct.component.css']
})
export class MakerCorrectComponent implements OnInit {

  screenedCount:any;
  classifiedCount:any;
  unClassifiedCount:any;
  exchangeData:any;
  classificationData:any;
  DocList:any;

  constructor(private _httpService:MakerService, private router:Router, private sanitize:DomSanitizer) { }

  ngOnInit() {
    this.screenedCount=0;
    this.classifiedCount=0;
    this.unClassifiedCount=0;
    this.DocList=[];

    this._httpService.classificationMaker(localStorage.getItem('id')).subscribe(r=>{
      console.log("Rt- > ",r)
      this.exchangeData=(r);
      this.screenedCount=this.exchangeData.data.classification_data.screned_documents_count;
      this.classifiedCount=this.exchangeData.data.classification_data.classifed_docs;
      this.unClassifiedCount=this.exchangeData.data.classification_data.un_classified_docs;
      this.classificationData=this.exchangeData.data.classification_data.data;
      
      for(var i=0;i<this.classificationData.length;i++){
        this.classificationData[i].url=this.sanitize.bypassSecurityTrustResourceUrl(environment.imageEndPointApi+this.classificationData[i].url);
        this.classificationData[i].type=this.DocType(this.classificationData[i].name_of_document);
     }

     var j=0;
     var tempName=[];
     for (var i=0;i<this.classificationData.length;i++){
       if(tempName.length!=0){
         var counter=0;
         for(var k=0;k<tempName.length;k++){
           if(tempName[k]===this.classificationData[i].type){
             counter++;
           }
         }
         if(counter===0){  
           tempName.push(this.classificationData[i].type);
           this.DocList[j]=this.classificationData[i];
           j++;
         }
       }else{
         tempName.push(this.classificationData[i].type);
         this.DocList[j]=this.classificationData[i];
         j++;
        //  this.CheckPointArray.push({name:this.classificationData[i].type,count:1})
       }
     }
     console.log("this.classificationData ",this.DocList)
   
    })
  }
  
  DocType(filterData){
    if(filterData.slice(0,2).toLowerCase()==='lc'){
      return 'Letter of Credit';
    }else
    if(filterData.slice(0,3).toLowerCase()==='inv'){
      return 'Invoice';
    }else
    if(filterData.slice(0,11).toLowerCase()==='bill_of_exc')
    {
      return 'Bill of Exchange';
    }
    if(filterData.slice(0,3).toLowerCase()==='com')
    {
      return 'Commercial Invoice';
    }
    if(filterData.slice(0,3).toLowerCase()==='air')
    {
      return 'Air Way Bill';
    }
    if(filterData.slice(0,11).toLowerCase()==='bill_of_lad'){
      return 'Bill of Lading';
    }
    if(filterData.slice(0,3).toLowerCase()==='cer'){
      return 'Certificate of Origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ins'){
      return 'Insurance';
    }
    if(filterData.slice(0,5).toLowerCase()==='state'){
      return 'Statement of Origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ben' ){
      return 'Beneficiary';
    }
    if(filterData.slice(0,3)==='swb'){
      return 'Sea Way Bill';
    }else
    if(filterData.slice(0,4)==='pack'){
      return 'Packing List';
    }else
    if(filterData.slice(0,6)==='others'){
      return 'Others';
    }
    else{
      return filterData;
    }
   
  }



  navigator(data){
    this.router.navigate([data]);
  }
}
