import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakerCorrectComponent } from './maker-correct.component';

describe('MakerCorrectComponent', () => {
  let component: MakerCorrectComponent;
  let fixture: ComponentFixture<MakerCorrectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakerCorrectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakerCorrectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
