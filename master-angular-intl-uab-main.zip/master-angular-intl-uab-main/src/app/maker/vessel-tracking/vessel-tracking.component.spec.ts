import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VesselTrackingComponent } from './vessel-tracking.component';

describe('VesselTrackingComponent', () => {
  let component: VesselTrackingComponent;
  let fixture: ComponentFixture<VesselTrackingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VesselTrackingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VesselTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
