import { Component, OnInit } from '@angular/core';
import { MakerService } from 'src/app/services/maker/docs.service';

@Component({
  selector: 'app-vessel-tracking',
  templateUrl: './vessel-tracking.component.html',
  styleUrls: ['./vessel-tracking.component.css']
})
export class VesselTrackingComponent implements OnInit {

  constructor(private _httpservice:MakerService) { }

  ngOnInit() {
    this._httpservice.getVesselTracking().subscribe((r)=>{
      console.log("Vessel ::  ",r)
    })
  }

}
