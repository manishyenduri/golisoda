import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakerClassificationComponent } from './maker-classification.component';

describe('MakerClassificationComponent', () => {
  let component: MakerClassificationComponent;
  let fixture: ComponentFixture<MakerClassificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakerClassificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakerClassificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
