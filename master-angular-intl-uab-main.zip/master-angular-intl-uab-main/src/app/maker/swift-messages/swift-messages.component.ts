import { Component, OnInit } from '@angular/core';
import { MakerService } from 'src/app/services/maker/docs.service';

@Component({
  selector: 'app-swift-messages',
  templateUrl: './swift-messages.component.html',
  styleUrls: ['./swift-messages.component.css']
})
export class SwiftMessagesComponent implements OnInit {

  exchangeData:any;
  arrayData:any;
  constructor(private _httpService:MakerService) { }

  ngOnInit() {
    this._httpService.swift_msg().subscribe(r=>{
      console.log("Swift_masg ", r)
      this.exchangeData=(r);
      this.arrayData=this.exchangeData.data;
    })
  } 

}
