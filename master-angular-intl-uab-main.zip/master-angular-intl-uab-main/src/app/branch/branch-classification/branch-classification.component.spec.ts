import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchClassificationComponent } from './branch-classification.component';

describe('BranchClassificationComponent', () => {
  let component: BranchClassificationComponent;
  let fixture: ComponentFixture<BranchClassificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchClassificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchClassificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
