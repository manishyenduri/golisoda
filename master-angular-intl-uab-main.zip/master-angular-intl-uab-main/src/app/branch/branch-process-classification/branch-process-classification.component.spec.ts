import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchProcessClassificationComponent } from './branch-process-classification.component';

describe('BranchProcessClassificationComponent', () => {
  let component: BranchProcessClassificationComponent;
  let fixture: ComponentFixture<BranchProcessClassificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchProcessClassificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchProcessClassificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
