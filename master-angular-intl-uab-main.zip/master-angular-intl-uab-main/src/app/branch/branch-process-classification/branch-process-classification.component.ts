import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BranchService } from 'src/app/services/branch/docs.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-branch-process-classification',
  templateUrl: './branch-process-classification.component.html',
  styleUrls: ['./branch-process-classification.component.css']
})
export class BranchProcessClassificationComponent implements OnInit {

  classified_count:any;
  unclassified_count:any;
  screned_count:any;
  exchangeData:any;
  id:any;
  classificationData:any;
  arrayOfData:any;
  rotateAngle:any;
  
  judgementImg:any;
  judgementClass:any;
  judegementIndx:number;

  trackCount:any
  judgementID:any;
  decisionBtn:any;
  allDecisionCompleted:boolean;
  constructor(private _httpService:BranchService, private modalService: NgbModal,private sanitizer:DomSanitizer, private router:Router) { }

  ngOnInit() {
    this.allDecisionCompleted=false;
    this.classified_count=0;
    this.unclassified_count=0;
    this.screned_count=0;
    this.arrayOfData=[];
    this.judgementImg=undefined;
    this.judgementClass=undefined;
    this.trackCount=0;
    this.judgementID='None';
    this.decisionBtn='';
    this.rotateAngle=0; 

    this.id=localStorage.getItem('bank_id_classifier');
    this._httpService.getClassificationImages(this.id).subscribe(r=>{
      this.exchangeData=(r);
      this.classified_count=this.exchangeData.data.classification_data.classifed_docs;
      this.unclassified_count=this.exchangeData.data.classification_data.un_classified_docs;
      this.screned_count=this.exchangeData.data.classification_data.screned_documents_count;
      this.classificationData=this.exchangeData.data.classification_data.data;
      for(var i=0;i<this.classificationData.length;i++){
  
        var hold;
        if(this.classificationData[i].type==='')
          hold=this.DocType(this.classificationData[i].name_of_document)
        else
          hold=this.classificationData[i].type;

        var a={
          id:this.classificationData[i].name_of_document,
          index:i,
          name:hold,
          classified:this.classificationData[i].classified,
          url:this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + this.classificationData[i].url),
          decision_response:'',
          decision_class:'',
          urlSave:this.classificationData[i].url,
          rotation:this.classificationData[i].rotation_angle
        }
        this.arrayOfData.push(a);
      }
      console.log("99- ",this.arrayOfData)
      this.moveJudegement(this.arrayOfData[0]);

    });
  }

  DocType(filterData){
    if(filterData.slice(0,2).toLowerCase()==='lc'){
      return 'letter_of_credit';
    }else
    if(filterData.slice(0,3).toLowerCase()==='inv'){
      return 'invoice';
    }else
    if(filterData.slice(0,11).toLowerCase()==='bill_of_exc')
    {
      return 'bill_of_exchange';
    }
    if(filterData.slice(0,3).toLowerCase()==='com')
    {
      return 'invoice';
    }
    if(filterData.slice(0,3).toLowerCase()==='air')
    {
      return 'air_way_bill';
    }
    if(filterData.slice(0,11).toLowerCase()==='bill_of_lad'){
      return 'bill_of_lading';
    }
    if(filterData.slice(0,3).toLowerCase()==='cer'){
      return 'certificate_of_origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ins'){
      return 'insurance';
    }
    if(filterData.slice(0,5).toLowerCase()==='state'){
      return 'statement_of_origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ben' ){
      return 'beneficiary_confirmation';
    }
    if(filterData.slice(0,3)==='swb'){
      return 'sea_waybill';
    }else
    if(filterData.slice(0,4)==='pack'){
      return 'packing_list';
    }else
    if(filterData.slice(0,6)==='others'){
      return 'others';
    }
    else{
      return filterData;
    }
   
  }

  moveJudegement(data){
    console.log("data---> ",data)
    this.judgementImg=data.url;
    this.judgementClass=data.name;
    this.judgementID=data.id;
    this.judegementIndx=data.index;
    this.rotateAngle = data.rotation;
  }
  next(){
    if(this.trackCount!=this.arrayOfData.length-1)
    {
      // this.arrayOfData[this.trackCount].rotation = this.rotateAngle;

      this.trackCount=this.trackCount+1;
      this.rotateAngle = this.arrayOfData[this.trackCount].rotation;
      this.judegementIndx=this.trackCount;
      this.judgementImg=this.arrayOfData[this.trackCount].url;
    this.judgementClass=this.arrayOfData[this.trackCount].name;
    this.judgementID=this.arrayOfData[this.trackCount].id;
    this.decisionBtn=this.arrayOfData[this.trackCount].decision_response;
    this.rotateImgFunc();
    }
  }

  prev(){
    if(this.trackCount!=0)
    {
      // this.arrayOfData[this.trackCount].rotation = this.rotateAngle;

      this.trackCount=this.trackCount-1;
      this.rotateAngle = this.arrayOfData[this.trackCount].rotation;
      this.judegementIndx=this.trackCount;
      this.judgementImg=this.arrayOfData[this.trackCount].url;
    this.judgementClass=this.arrayOfData[this.trackCount].name;
    this.judgementID=this.arrayOfData[this.trackCount].id;
    this.decisionBtn=this.arrayOfData[this.trackCount].decision_response;
    // this.rotateAngle = this.arrayOfData[this.trackCount].rotation;
    this.rotateImgFunc();
  }
  }
  zoomin() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth + 100) + "px"; 
    GFG.style.height = (currHeight + 100) + "px"; 
  } 
  
   zoomout() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth - 100) + "px"; 
    GFG.style.height = (currHeight - 100) + "px"; 
  }
  
  selectClass(data){
    this.judgementClass=this.arrayOfData[this.trackCount].name=data;
  }
  saveDecision(data){
    if(data==='Accept')
      this.decisionBtn=this.arrayOfData[this.trackCount].decision_response=false;
    else
      this.decisionBtn=this.arrayOfData[this.trackCount].decision_response=true;

    var c=0;
    for(var i=0;i<this.arrayOfData.length;i++){
      if(this.arrayOfData[i].decision_response===false || this.arrayOfData[i].decision_response===true){
        c++;
        console.log("I - ",c,i)
      }
    }
    console.log('C -> ',c)
    if(c===this.arrayOfData.length){
      this.allDecisionCompleted=true;
    }
    console.log('this.arrayOfData - ',this.arrayOfData)
  }

  checkClass(data){
    var count=0;
    for(var i=0;i<data.length;i++){
      if(data[i].name!='others'){
        count++;
      }
    }
    return count;
  }
  submit(){
    console.log('D -> ',this.arrayOfData);

    var cnt=this.checkClass(this.arrayOfData);
    var data={
        classifed_docs:cnt,
        screned_documents_count:this.screned_count,
        un_classified_docs:this.screned_count-cnt,
        data:[]
      }
    
    for(var i=0;i<this.arrayOfData.length;i++){

      var temp={
        classified:this.arrayOfData[i].classified,
        name_of_document: this.arrayOfData[i].id,
        type: this.arrayOfData[i].name,
        updated: this.arrayOfData[i].decision_response,
        url:this.arrayOfData[i].urlSave,
        rotation_angle:this.arrayOfData[i].rotation
      }
      // temp.classified=this.arrayOfData[i].classified;
      // temp.name_of_document=this.arrayOfData[i].id;
      // temp.updated=this.arrayOfData[i].decision_response;
      // temp.url=this.arrayOfData[i].urlSave;
      // temp.type=this.arrayOfData[i].name;

      data.data.push(temp);
    }
    console.log('Decision - ',this.arrayOfData, data)
  
    this._httpService.classifiedAPI(data,localStorage.getItem('bank_id_classifier')).subscribe(r=>{
      Swal.fire(
        'Classification Record',
        'Updated',
        'success'
      )
      console.log("rt-> ",r);
    })
  }

openXl(content) {
  this.modalService.open(content, { size: 'lg' });
}
rotateAnti(){
  this.rotateAngle=this.rotateAngle-45;
  if(this.rotateAngle<-360){
    this.rotateAngle=0;
  }
  this.rotateImgFunc()
 
}
rotateClock(){
  this.rotateAngle=this.rotateAngle+45;
  if(this.rotateAngle>360){
    this.rotateAngle=0;
  }
  this.rotateImgFunc()
}

rotateImgFunc(){
  document.getElementById("preview").style.transform = `rotate(${this.rotateAngle}deg)`
  this.arrayOfData[this.judegementIndx].rotation = this.rotateAngle;
  console.log(this.arrayOfData);
}

}
