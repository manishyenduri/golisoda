import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BranchService } from 'src/app/services/branch/docs.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-branch-remittance',
  templateUrl: './branch-remittance.component.html',
  styleUrls: ['./branch-remittance.component.css']
})
export class BranchRemittanceComponent implements OnInit {

  exchangeData:any;
  id:any;
  showData:any;
  modalTitle:any;
  judgementImg:any;
  constructor(private _httpService:BranchService, private modalService:NgbModal ,private Sanitizer:DomSanitizer) { }

  ngOnInit() {
    this.id=localStorage.getItem("bank_id_classifier");
    this._httpService.getRemittanceByID(this.id).subscribe((r)=>{
      this.exchangeData = (r);
      console.log("this.exchangeData -- ",this.exchangeData);
      this.showData = this.exchangeData.data.remmitance_advance_form_data;
      for(var i=0;i<this.showData.length;i++){
        this.showData[i].snippet_image=this.Sanitizer.bypassSecurityTrustResourceUrl(environment.a1EndPointImage + this.showData[i].snippet_image)
        this.showData[i].orginal_image=this.Sanitizer.bypassSecurityTrustResourceUrl(environment.a1EndPointImage + this.showData[i].orginal_image)
        this.showData[i].highlight_image=this.Sanitizer.bypassSecurityTrustResourceUrl(environment.a1EndPointImage + this.showData[i].highlight_image)
      }
      console.log("this.showData-- ",this.showData);
    },
    err=>{

    })
  }

  
openXl(content,data) {
  this.modalTitle=data.title;
  this.judgementImg=data.highlight_image;
  this.modalService.open(content, { size: 'lg' });
}

//src="${'http://159.89.169.25:8502'+val.snippet_image}"
}
