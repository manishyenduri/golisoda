import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchRemittanceComponent } from './branch-remittance.component';

describe('BranchRemittanceComponent', () => {
  let component: BranchRemittanceComponent;
  let fixture: ComponentFixture<BranchRemittanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchRemittanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchRemittanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
