import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankerTransactionsComponent } from './banker-transactions.component';

describe('BankerTransactionsComponent', () => {
  let component: BankerTransactionsComponent;
  let fixture: ComponentFixture<BankerTransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankerTransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankerTransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
