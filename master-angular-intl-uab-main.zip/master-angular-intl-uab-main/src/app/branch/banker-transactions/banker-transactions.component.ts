import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banker-transactions',
  templateUrl: './banker-transactions.component.html',
  styleUrls: ['./banker-transactions.component.css']
})
export class BankerTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
