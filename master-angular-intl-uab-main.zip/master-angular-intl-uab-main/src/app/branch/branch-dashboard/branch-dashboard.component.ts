import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable } from 'rxjs';
import { BranchService } from 'src/app/services/branch/docs.service';
import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';
import 'rxjs/add/observable/interval';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-branch-dashboard',
  templateUrl: './branch-dashboard.component.html',
  styleUrls: ['./branch-dashboard.component.css']
})
export class BranchDashboardComponent implements OnInit {
  
  exchangeData:any;
  showTableData:any;
  processExchange:any;
  exchangeData2:any;
  id:any;
  Observ:any;
  Observ2:any;
  file:any;
  intialPage:any;
  digitalValidator:any;
  exchangeDigitalData:any;
  DocList:any;
  classified:any
  unclassified:any;
  screened:any;
  digiTracker:any;
  checkSubscribe:any;
  booleanA1:boolean;
  booleanTrade:boolean;
  exchangeA1Response:any;
  exchangeGetA1Response:any;
  exchangeGetA1List:any;

  constructor(private _httpService:BranchService, private modalService:NgbModal,private toast:ToastrService,private router:Router, private spinner:NgxSpinnerService, private sanitizer:DomSanitizer){

  }
  ngOnInit(){
    this.booleanTrade=true;
    this.booleanA1=false;
    this.checkSubscribe=0;
    this.classified=0;
    this.unclassified=0;
    this.screened=0;
    this.digiTracker=undefined;
    this.DocList=[];
    this.digitalValidator=[];
    document.getElementById("pbar").style.width="0%";
    this.intialPage=0;
    this._httpService.getTransactionHistory(0,5).subscribe(r=>{
      this.exchangeData=(r);
      this.showTableData=this.exchangeData.data;
    })
    
    this.trackerAPI();
    this.getIDs();
  }

  getIDs(){
    this._httpService.getRemittanceIDs().subscribe((r)=>{
      this.exchangeGetA1List=(r);
      this.exchangeGetA1List = this.exchangeGetA1List.data;
      this.exchangeGetA1List.reverse();
      console.log('Tran -- ',this.exchangeGetA1List);
    })
  }
  trackerAPI(){
    this.Observ = Observable.interval(10000)
    .subscribe(() => { 
      // if(localStorage.getItem('digiID')!='')
        this.fetch(localStorage.getItem('digiID'));

      this._httpService.getTransactionHistory(0,5).subscribe(r=>{
        this.exchangeData=(r);
        this.showTableData=this.exchangeData.data;
      },err=>{
        console.log("Error -> ",err.error.message)
      })
     });
  }
  updateFile(e){
    this.file= e.target.files[0];
    document.getElementById("pbar").style.width="100%";
  }

  uploadTrade(){
    if(this.file===undefined)
    {
      this.toast.warning('Please Select a file to upload!')
      return;
    }
    this.spinner.show();
    this._httpService.upload(this.file).subscribe(r=>{
      this.processExchange=(r);
      this.id=this.processExchange.request_id;
      localStorage.setItem('digiID',this.id);
    this.spinner.hide();
    this.file=undefined;
      Swal.fire({
        title: "Document uploaded",
        html: this.processExchange.message + '<br/>'+ 'Transaction_Id : ' + this.processExchange.request_id +'<br/>'+'Wait Time : '+this.processExchange.wait_time+'Sec',
        confirmButtonText:'Process',
      }).then(async ()=>{
        await this.processFile(this.id)
      })
    },(e)=>{
      this.spinner.hide();
      Swal.fire('Document Upload', 'Some error occured!','info')
      console.log("Er-> ",e)
    })
  }
  uploadA1(){
    this.spinner.show();
    this._httpService.uploadRemittance(this.file).subscribe(r=>{
      this.spinner.hide();
      this.exchangeA1Response = (r);
      if(this.exchangeA1Response.code != 200)
      Swal.fire("Document Upload",this.exchangeA1Response.message,'info');
      else
      {
        Swal.fire("Document Upload",this.exchangeA1Response.request_id +" - "+ this.exchangeA1Response.message,'success');
        this.getIDs();
      }
      console.log(r)
    },err=>{
      this.spinner.hide();
    })
  }
  processFile(id){
    this.spinner.show();
    this._httpService.analyze(id).subscribe(r=>{
    this.spinner.hide();
      Swal.fire({
        title: "Document Upload",
        html: 'Processing Uploaded Documents' ,
        confirmButtonText:'OK',
      }).then(()=>{
        document.getElementById("pbar").style.width="0%";
        this.digiTracker=undefined;
        this.Observ2=Observable.interval(6000)
        .subscribe(()=>{
          this.checkSubscribe=1;
          fetch(localStorage.getItem('digiID'));
        })
      })
      console.log(r);
    })
  }
  prev(){
    if(this.intialPage===0)
     {
       this.trackerAPI();
       return;
     }
    else
      {
        this.intialPage=this.intialPage-5;
        this._httpService.getTransactionHistory(this.intialPage,5).subscribe(r=>{
          this.exchangeData=(r);
          this.showTableData=this.exchangeData.data;
        })
      }
    
  }
  next(){
    this.Observ.unsubscribe();
    this.intialPage=this.intialPage+5;
    this._httpService.getTransactionHistory(this.intialPage,5).subscribe(r=>{
      this.exchangeData=(r);
      this.showTableData=this.exchangeData.data;
    })
  }
  navigator(link, id){
    localStorage.setItem("bank_id_classifier",id);
    this.router.navigate([link])
  }
  openXl(content,id){
    this._httpService.getClassificationImages(id).subscribe(r=>{
      this.exchangeDigitalData = (r);
      this.digitalValidator=this.exchangeDigitalData.data.classification_data.data;
      this.classified=this.exchangeDigitalData.data.classification_data.classifed_docs;
      this.unclassified=this.exchangeDigitalData.data.classification_data.un_classified_docs;
      this.screened=this.exchangeDigitalData.data.classification_data.screned_documents_count;
      for(var i=0;i<this.digitalValidator.length;i++){
        this.digitalValidator[i].url=this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi+this.digitalValidator[i].url);
        this.digitalValidator[i].type=this.DocType(this.digitalValidator[i].name_of_document);
     }

      var j=0;
      var tempName=[];
      for (var i=0;i<this.digitalValidator.length;i++){
        if(tempName.length!=0){
          var counter=0;
          for(var k=0;k<tempName.length;k++){
            if(tempName[k]===this.digitalValidator[i].type){
              counter++;
            }
          }
          if(counter===0){  
            tempName.push(this.digitalValidator[i].type);
            this.DocList[j]=this.digitalValidator[i];
            j++;
          }
        }else{
          tempName.push(this.digitalValidator[i].type);
          this.DocList[j]=this.digitalValidator[i];
          j++;
          // this.CheckPointArray.push({name:this.digitalValidator[i].type,count:1})
        }
      }
      console.log("Data - ",this.DocList)
      this.modalService.open(content, {size:'lg'});
    })
  }

  fetch(id){
    if(id==='')
    return;
    console.log("Working- ",id)
      this._httpService.getClassificationImages(id).subscribe(r=>{
        this.exchangeDigitalData = (r);
        this.digiTracker=this.exchangeDigitalData.data.classification_data.data;
        if(this.digiTracker!=undefined){
          localStorage.setItem('digiID','')
          this.Observ2.unsubscribe();
        }
        console.log("d- ",this.digiTracker)
      })
  }
  
  DocType(filterData){
    if(filterData.slice(0,2).toLowerCase()==='lc'){
      return 'Letter of Credit';
    }else
    if(filterData.slice(0,3).toLowerCase()==='inv'){
      return 'Invoice';
    }else
    if(filterData.slice(0,11).toLowerCase()==='bill_of_exc')
    {
      return 'Bill of Exchange';
    }
    if(filterData.slice(0,3).toLowerCase()==='com')
    {
      return 'Commercial Invoice';
    }
    if(filterData.slice(0,3).toLowerCase()==='air')
    {
      return 'Air Way Bill';
    }
    if(filterData.slice(0,11).toLowerCase()==='bill_of_lad'){
      return 'Bill of Lading';
    }
    if(filterData.slice(0,3).toLowerCase()==='cer'){
      return 'Certificate of Origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ins'){
      return 'Insurance';
    }
    if(filterData.slice(0,5).toLowerCase()==='state'){
      return 'Statement of Origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ben' ){
      return 'Beneficiary';
    }
    if(filterData.slice(0,3)==='swb'){
      return 'Sea Way Bill';
    }else
    if(filterData.slice(0,4)==='pack'){
      return 'Packing List';
    }else
    if(filterData.slice(0,6)==='others'){
      return 'Others';
    }
    else{
      return filterData;
    }
   
  }
  switchToA1(){
    this.booleanA1=true;
    this.booleanTrade=false;
  }
  switchToTrade(){
    this.booleanA1=false;
    this.booleanTrade=true;
  }
  routeToRemiitance(){

    // this.router.navigate(['banker/remittance'])
  }

  ngOnDestroy(){
   this.Observ.unsubscribe();

   if(this.checkSubscribe===1)
      this.Observ2.unsubscribe();
  }


  // fileToUpload:any;
  // reqs_id:any;
// showATPCheck:boolean;
  
// localRes:any;

// reqs_id: any= null;
// lcDoc: any;
// invDoc: any;
// boeDoc: any;
// awbDoc: any;
// bolDoc: any;
// docs: any;
// docUploadSatus: any;
// analyzeSatus: any;
// // uploadBtn:boolean = true;
// // analyzeBtn:boolean = false;
// request_id: any;
// tokenInfo: any;
// fileToUpload: File = null;

// onProcess = false;


// //variables holding card values
// cardFileName: any=[];
// cardData:any;
// cardUrl:any;
// cardInv: any;
// cardBoe: any;
// cardBol: any;
// cardIns: any;
// cardLoc: any;
// cardCoo: any;
// cardAwb: any;
// //----------------------

// afterUpload:boolean = false;
// closeResult: string;
// showloader: boolean;
// timer: any;
// subscription: any;
//   res: any = "";

//   constructor(private _httpService:MakerService, private spinner: NgxSpinnerService, private sanitizer:DomSanitizer) { }

//   ngOnInit() {
//     this.showATPCheck=false;
//   }
  
//   upload(e){
//     this.fileToUpload=e.target.files[0];
//     this.spinner.show();
//     this._httpService.upload(this.fileToUpload,'dd').subscribe((r)=>{
//       let data=(r);
//       this.reqs_id=data.request_id;
//       if(data.status=== true && this.reqs_id!=null){
//         this.spinner.hide();
//       }
//       localStorage.setItem('yyy',data.request_id);
//       Swal.fire({
//         title: "Document uploaded",
//         html: data.message + '<br/>'+ 'Transaction_Id : ' + data.request_id,
//         confirmButtonText:'Process',
//       }).then(async ()=>{

//         this.onProcess=true;
//           this._httpService.analyze(this.reqs_id).subscribe( res => {
//           console.log(res)
//           const dataId =res;//res.job_id
//           console.log(data)
//            this.res =dataId
//            })
//          //    console.log(res.message);
//         //  this.setTimer();
//         //  await this.delay(5000)
//          Swal.fire({
//            title: "Document Upload",
//            html: 'Processing Uploaded Documents' ,
//            confirmButtonText:'OK',
//          }).then(()=>{
//            this.showATPCheck=true;
//          this._httpService.processedDocs(this.reqs_id).subscribe(rev_data=>{
//            this.localRes=rev_data;
//            // this.setTimer();
//            console.log(this.localRes)
//            // if(this.localRes.responseStatus === 200)
//            {
//             this.onProcess=false;
//              let i; 
//              for(i = 0 ; i < this.localRes.data.length;i++){
//                this.cardInv = this.localRes.data[i].url
//               this.cardFileName[i]= this.transform(this.cardInv);
//              }
             
//            //  console.log(this.cardFileName[0]);
          
//              this.cardData = this.localRes.data;
//             // this.cardUrl = rev_data.data[1].url;
//              this.cardUrl = this.transform(this.localRes.data[0].url);
//              Swal.fire({
//                title: "Document Processed",
//                confirmButtonText:'View'
//              }).then(()=>{
//              //  this.setTimer();
//                // this.spinner.show();
//                this._httpService.processedDocs(this.reqs_id).subscribe(rev_data=>{
//                // if(this.localRes.responseStatus === 200)
//                // this.spinner.hide();
//                {
//                 this.onProcess=false;
//                  let i; 
//                  for(i = 0 ; i < this.localRes.data.length;i++){
//                    this.cardInv = this.localRes.data[i].url
//                   this.cardFileName[i]= this.transform(this.cardInv);
//                  }
                 
//                //  console.log(this.cardFileName[0]);
              
//                  this.cardData = this.localRes.data;
//                 // this.cardUrl = rev_data.data[1].url;
//                  this.cardUrl = this.transform(this.localRes.data[0].url);
//                }
//                // this.setTimer();
//              })
//            })}
//          })
//          // this.setTimer();
//        })
//        }
//        )
//     })
//     // const files = e.ta
//   }
//   delay(ms: number) {
//     return new Promise( resolve => setTimeout(resolve, ms) );
// }

//   transform(url)
//   {
//     return this.sanitizer.bypassSecurityTrustResourceUrl(url);
//   }
//   public setTimer(){
//     // set showloader to true to show loading div on view
//     this.spinner.show();

//     this.timer        = Observable.timer(5000); // 5000 millisecond means 5 seconds
//     this.subscription = this.timer.subscribe(() => {
//         // set showloader to false to hide loading div from view after 5 seconds
//         this.spinner.hide();
//         this.afterUpload = true;
//     });
//  
digitalvalidato2(id){
  this._httpService.getRemittanceByID(id).subscribe(r=>{
    this.exchangeData2=(r);
    console.log("exchangeData2- ",this.exchangeData2)
  })
}
openXL2(content){
  this.modalService.open(content, {size:'lg'});
}
}
