import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { AuthService } from '../services/auth.service';
import {con} from './country2';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  country:any=con;
  loginForm: FormGroup;
  userData: any;
  submitted = false;
  erroMsg: string;
  loading: boolean;
  resetloading: boolean;
  recoverform = false;
  forgotPswd: any;
  role: any;

  exchangeData:any;
  body={
    first_name:'',
    last_name:'',
    email:'',
    password:'',
    org_name:'',
    country:'',
    city:'',
    role:''
  }
  
  req_fname:boolean;
  req_lname:boolean;
  req_role:boolean;
  req_email:boolean;
  req_org:boolean;
  req_city:boolean;
  req_country:boolean;
  req_pswd:boolean;

  constructor(private fb:FormBuilder, private router:Router, private authService:AuthService) { 
    this.loginForm = fb.group({
      'user_firstname': [null, Validators.required],
      'user_lastname':[null,Validators.required],
      'password': [null, Validators.required],
     });
  }
  

  ngOnInit() {
    this.req_fname=false;
    this.req_lname=false;
    this.req_role=false;
    this.req_email=false;
    this.req_org=false;
    this.req_city=false;
    this.req_country=false;
    this.req_pswd=false;
  }

  createAccount(){
    console.log("Create Account ==> ", this.body)
    var counter=0;
    if(this.body.first_name === '' || this.body.first_name ===undefined || this.body.first_name ===null){
      counter=1;this.req_fname=true;}else{this.req_fname=false;}
    if(this.body.last_name === '' || this.body.last_name ===undefined || this.body.last_name ===null){
      counter=1;this.req_lname=true;}else{this.req_lname=false;}
    if(this.body.email === '' || this.body.email ===undefined || this.body.email ===null){
      counter=1;this.req_email=true;}else{this.req_email=false;}
    if(this.body.org_name === '' || this.body.org_name ===undefined || this.body.org_name ===null){
      counter=1;this.req_org=true;}else{this.req_org=false;}
    if(this.body.country === '' || this.body.country === undefined || this.body.country === null){
      counter=1;this.req_country=true;}else{this.req_country=false;}
    if(this.body.city === '' || this.body.city=== undefined || this.body.city === null){
      counter=1;this.req_city=true;}else{this.req_city=false;}
    if(this.body.role === '' || this.body.role === undefined || this.body.role === null){
      counter=1;this.req_role=true;}else{this.req_role=false;}
    if(this.body.password === '' || this.body.password === undefined || this.body.password === null){
      counter=1;this.req_pswd = true;}else{this.req_pswd=false;}

    if(counter===1){
      return;
    }

    this.authService.createAccount(this.body).subscribe(r=>{
      console.log("CreateAccount New ==> ", r)
      this.exchangeData = (r);
      if(this.exchangeData.code === 200)
        {
          Swal.fire(
            'SIMBA',
          this.exchangeData.message,
          // "User ID: "+this.exchangeData.items[0].userId,
          'success')
        }
      else{
        Swal.fire(
        'Account Creation',
        'Failed',
        'error')
      }
    })
  }
  
  loginUser(formdata: any) {
    this.submitted = true;
    if ((formdata.firstname !== null) && (formdata.lastname !== null) && (formdata.email !== null) && (formdata.org !== null) && (formdata.country !== null) && (formdata.city !== null) &&  (formdata.password !== null)) {
      this.loading = true;
    }

    this.authService.login(formdata).subscribe (
        data => {
         this.userData = (data);
         const dataVal = this.userData.items;
         for (const item of dataVal) {
          for (const role of item.roles) {
            this.role = item.roles;
          }
          if ((this.userData.responseStatus === 200) &&
          (this.role === 'admin')) {
            localStorage.setItem('access_token', data.items[0].access_token);
            localStorage.setItem('refresh_token', data.items[0].refresh_token);
            this.router.navigate(['/admin/dashboard']);
          }  
          if ((this.userData.responseStatus === 200) &&
          (this.role === 'maker')) {
            localStorage.setItem('access_token', data.items[0].access_token);
            localStorage.setItem('refresh_token', data.items[0].refresh_token);
            this.router.navigate(['/maker/dashboard']);
          }
          if ((this.userData.responseStatus === 200) &&
          (this.role === 'checker')) {
            localStorage.setItem('access_token', data.items[0].access_token);
            localStorage.setItem('refresh_token', data.items[0].refresh_token);
            this.router.navigate(['/checker/checker-dashboard']);
          }
          
          
         }
        } ,
         error => {
          if (error.responseStatus === 400) {
            this.loading = false;
            this.erroMsg = error.error;
          } else if (error.responseStatus === 500) {
            this.loading = false;
            this.erroMsg = error.error;
          }
         },
         () => console.log('user logged in')
    );

        }
}
