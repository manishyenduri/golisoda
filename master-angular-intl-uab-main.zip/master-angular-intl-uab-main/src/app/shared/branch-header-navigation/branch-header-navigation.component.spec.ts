import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchHeaderNavigationComponent } from './branch-header-navigation.component';

describe('BranchHeaderNavigationComponent', () => {
  let component: BranchHeaderNavigationComponent;
  let fixture: ComponentFixture<BranchHeaderNavigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchHeaderNavigationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchHeaderNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
