import { RouteInfo } from './admin-metadata';

export const ROUTES: RouteInfo[] = [
  {
    path: '/admin/dashboard',
    title: 'Dashboard',
    icon: 'icon-Car-Wheel',
    id:'D',
    icon_id:'D_icon',
    class: '',
    ddclass: '',
   // extralink: false,
    submenu: [
    ]
  },
  {
    path: '/admin/addMaker',
    title: 'Users',
    icon: 'icon-File-HorizontalText',
    id:'U',
    icon_id:'U_icon',
    class: '',
    ddclass: '',
    //extralink: false,
    submenu: [
    ]
  },
  {
    path: '/admin/customRules',
    title: 'Custom Rules',
    icon: 'icon-File-HorizontalText',
    id:'U',
    icon_id:'U_icon',
    class: '',
    ddclass: '',
    //extralink: false,
    submenu: [
    ]
  }
  // {
  //   path: '/maker/ManualReport',
  //   title: 'Manual Scrutiny',
  //   icon: 'icon-File-HorizontalText',
  //   class: 'has-arrow',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  // {
  //   path: '/maker/TransactionReport',
  //   title: 'Transaction Reports',
  //   icon: 'icon-File-HorizontalText',
  //   class: 'has-arrow',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  
];
