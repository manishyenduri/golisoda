import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { ROUTES } from './admin-menu';


@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrls: ['./admin-sidebar.component.scss']
})
export class AdminSidebarComponent implements OnInit {
  showMenu = '';
  showSubMenu = '';
  public sidebarnavItems: any[];
  // this is for the open close
  addExpandClass(element: any) {
    if (element === this.showMenu) {
      this.showMenu = '0';
    } else {
      this.showMenu = element;
    }
  }
  addActiveClass(element: any) {
    if (element === this.showSubMenu) {
      this.showSubMenu = '0';
    } else {
      this.showSubMenu = element;
    }
  }
  constructor(
    private modalService: NgbModal,
     private router: Router,
     private route: ActivatedRoute
  ) {}


  ngOnInit() {
     this.sidebarnavItems = ROUTES.filter(sidebarnavItem => sidebarnavItem);
  }

  tabCssFuntion(event, title){
    if(title === 'Dashboard'){
      //Style Background: Blue
      document.getElementById('D').style.background = "#3B89F4";
      document.getElementById('U').style.background = "";

      //Style Text color: White
      document.getElementById('D_icon').style.color = "#fff";
      document.getElementById('U_icon').style.color = "";

      //Style icon color: White
      document.getElementById('D').style.color = "#fff";
      document.getElementById('U').style.color = "";
    }
    if(title === 'Users'){
      //Style Background: Blue
      document.getElementById('U').style.background = "#3B89F4";
      document.getElementById('D').style.background = "";

      //Style Text color: White
      document.getElementById('U_icon').style.color = "#fff";
      document.getElementById('D_icon').style.color = "";

      //Style icon color: White
      document.getElementById('U').style.color = "#fff";
      document.getElementById('D').style.color = "";
    }
  }

}
