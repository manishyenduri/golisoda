import { RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [
  {
    path: '/maker/dashboard',
    title: 'Maker Dashboard',
    icon: 'icon-Car-Wheel',
    id: 'MD',
    icon_id: 'MD_icon',
    class: '',
    ddclass: '',
    extralink: false,
    submenu: [
    ]
  },
  {
    path: '/maker/ai-reports-list',
    title: 'SIMBA Reports',
    icon: 'icon-Owl',
    id: 'SR',
    icon_id: 'SR_icon',
    class: '',
    ddclass: '',
    extralink: false,
    submenu: [
    ]
  },
  {
    path: '/maker/manual-reports-list',
    title: 'Maker Reports',
    icon: 'icon-Talk-Man',
    id:'MR',
    icon_id: 'MR_icon',
    class: '',
    ddclass: '',
    extralink: false,
    submenu: [
    ]
  },
  {
    path: '/maker/noun-list',
    title: 'Nouns',
    icon: 'icon-File-HorizontalText',
    id:'NN',
    icon_id: 'NN_icon',
    class: '',
    ddclass: '',
    extralink: false,
    submenu: [
    ]
  },
  // {
  //   path: '/maker/genericOcr',
  //   title: 'Generic OCR',
  //   icon: 'icon-File-HorizontalText',
  //   id:'NN',
  //   icon_id: 'NN_icon',
  //   class: '',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  {
      path: '/maker/genericOcr',
      title: 'Generic OCR',
      icon: 'icon-Folder-WithDocument',
      id: 'rbi_R',
      icon_id: 'rbi_R_icon',
      class: '',
      ddclass: '',
      extralink: false,
      submenu: [
      ]
    },
    
    {
      path: '/maker/outward-remittance-list',
      title: 'Outward Remittance',
      icon: 'icon-Mail-Money',
      id: 'TR',
      icon_id: 'TR_icon',
      class: '',
      ddclass: '',
      extralink: false,
      submenu: [
      ]
    },
  // {
  //   path: '/maker/TransactionReport',
  //   title: 'Transaction Reports',
  //   icon: 'icon-Mail-Money',
  //   id: 'TR',
  //   icon_id: 'TR_icon',
  //   class: '',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  {
    path: '/maker/swift-messages',
    title: 'SWIFT Messages',
    icon: 'icon-Email',
    id:'SM',
    icon_id: 'SM_icon',
    class: '',
    ddclass: '',
    extralink: false,
    submenu: [
    ]
  },
  // {
  //   path: '/maker/rbi-reportings',
  //   title: 'RBI Reportings',
  //   icon: 'icon-Folder-WithDocument',
  //   id: 'rbi_R',
  //   icon_id: 'rbi_R_icon',
  //   class: '',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // }
  
];
