import { Component, AfterViewInit, OnInit } from '@angular/core';
import { ROUTES } from './menu-items';
import { RouteInfo } from './sidebar.metadata';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
declare var $: any;

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']

})
export class SidebarComponent implements OnInit {
  showMenu = '';
  showSubMenu = '';
  public sidebarnavItems: any[];
  // this is for the open close
  addExpandClass(element: any) {
    if (element === this.showMenu) {
      this.showMenu = '0';
    } else {
      this.showMenu = element;
    }
  }
  addActiveClass(element: any) {
    if (element === this.showSubMenu) {
      this.showSubMenu = '0';
    } else {
      this.showSubMenu = element;
    }
  }

  constructor(
    private modalService: NgbModal,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  // End open close
  ngOnInit() {
    this.sidebarnavItems = ROUTES.filter(sidebarnavItem => sidebarnavItem);
  }

 
  tabCssFuntion(evt, titleName) {
  
    if(titleName=="Maker Dashboard"){
      document.getElementById("NN").style.background="";
      document.getElementById("NN").style.color="";
      document.getElementById("NN_icon").style.color="";
      
      document.getElementById("MD").style.background = "#9A0000";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("rbi_R").style.background = "";
      
      document.getElementById("MD").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("rbi_R").style.color  = "";

      document.getElementById("MD_icon").style.color  = "#fff";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("rbi_R_icon").style.color  = "";
    }

    
    if(titleName=="SIMBA Reports"){
      document.getElementById("NN").style.background="";
      document.getElementById("NN").style.color="";
      document.getElementById("NN_icon").style.color="";

      document.getElementById("SR").style.background = "#9A0000";
      document.getElementById("MD").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("rbi_R").style.background = "";
      
      document.getElementById("SR").style.color  = "#fff";
      document.getElementById("MD").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("rbi_R").style.color  = "";

      document.getElementById("MD_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "#fff";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("rbi_R_icon").style.color  = "";
    }
    
    if(titleName=="Maker Reports"){
      document.getElementById("NN").style.background="";
      document.getElementById("NN").style.color="";
      document.getElementById("NN_icon").style.color="";

      document.getElementById("MR").style.background = "#9A0000";
      document.getElementById("SR").style.background = "";
      document.getElementById("MD").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("rbi_R").style.background = "";
      
      document.getElementById("MR").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MD").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("rbi_R").style.color  = "";
      
      document.getElementById("MD_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "#fff";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("rbi_R_icon").style.color  = "";
    }
    
    
    // if(titleName=="Transaction Reports"){
      if(titleName=="Outward Remittance"){
      document.getElementById("NN").style.background="";
      document.getElementById("NN").style.color="";
      document.getElementById("NN_icon").style.color="";

      document.getElementById("TR").style.background = "#9A0000";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("MD").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("rbi_R").style.background = "";
      
      document.getElementById("TR").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("MD").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("rbi_R").style.color  = "";
      
      document.getElementById("MD_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "#fff";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("rbi_R_icon").style.color  = "";
    }
    if(titleName=="Nouns"){
      document.getElementById("NN").style.background="#9A0000";
      document.getElementById("NN").style.color="#fff";
      document.getElementById("NN_icon").style.color="#fff";

      document.getElementById("TR").style.background = "";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("MD").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("rbi_R").style.background = "";
      
      document.getElementById("TR").style.color  = "";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("MD").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("rbi_R").style.color  = "";
      
      document.getElementById("MD_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("rbi_R_icon").style.color  = "";
    }

    
    if(titleName=="SWIFT Messages"){
      document.getElementById("NN").style.background="";
      document.getElementById("NN").style.color="";
      document.getElementById("NN_icon").style.color="";

      document.getElementById("SM").style.background = "#9A0000";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("MD").style.background = "";
      document.getElementById("rbi_R").style.background = "";
      
      document.getElementById("SM").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("MD").style.color  = "";
      document.getElementById("rbi_R").style.color  = "";
      
      document.getElementById("MD_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "#fff";
      document.getElementById("rbi_R_icon").style.color  = "";
    }

    // if(titleName=="RBI Reportings")
    if(titleName=="Generic OCR")
    {
      document.getElementById("NN").style.background="";
      document.getElementById("NN").style.color="";
      document.getElementById("NN_icon").style.color="";

      document.getElementById("rbi_R").style.background = "#9A0000";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("MD").style.background = "";
      
      document.getElementById("rbi_R").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("MD").style.color  = "";
      
      document.getElementById("MD_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("rbi_R_icon").style.color  = "#fff";
    }


    // console.log(cityName);
//     if(titleName=="Maker Dashboard"){
//       document.getElementById("MD").style.background  = "#3B89F4";

//       document.getElementById("SR").style.background  = "";
//       document.getElementById("MR").style.background  = "";
//       document.getElementById("TR").style.background  = "";
//       document.getElementById("SM").style.background  = "";
//       document.getElementById("rbi_R").style.background = "";

//       //Style color:white
//       document.getElementById("MD").style.color  = "#fff";

//       document.getElementById("SR").style.color  = "";
//       document.getElementById("MR").style.color  = "";
//       document.getElementById("TR").style.color  = "";
//       document.getElementById("SM").style.color  = "";
//       document.getElementById("rbi_R").style.color  = "";

//       //Style icon:white
//       document.getElementById("MD_icon").style.color="#fff"
      
//       document.getElementById("SR_icon").style.color  = "";
//       document.getElementById("MR_icon").style.color  = "";
//       document.getElementById("TR_icon").style.color  = "";
//       document.getElementById("SM_icon").style.color  = "";
//       document.getElementById("rbi_R_icon").style.color  = "";

//     }
//     if(titleName=="SIMBA Reports"){
//       document.getElementById("SR").style.background  = "#3B89F4";
//      // document.getElementById("SR").style.color  = "fff";

//       document.getElementById("MD").style.background  = "";
//       document.getElementById("MR").style.background  = "";
//       document.getElementById("TR").style.background  = "";
//       document.getElementById("SM").style.background  = "";
//       document.getElementById("rbi_R").style.background = "";
// //Style Color:white
//       document.getElementById("SR").style.color  = "#fff";

//       document.getElementById("MD").style.color  = "";
//       document.getElementById("MR").style.color  = "";
//       document.getElementById("TR").style.color  = "";
//       document.getElementById("SM").style.color  = "";
//       document.getElementById("rbi_R").style.color = "";
      
//       //Style icon Color:white
//       document.getElementById("SR_icon").style.color  = "#fff";

//       document.getElementById("MD_icon").style.color  = "";
//       document.getElementById("MR_icon").style.color  = "";
//       document.getElementById("TR_icon").style.color  = "";
//       document.getElementById("SM_icon").style.color  = "";
//       document.getElementById("rbi_R_icon").style.color = "";

//     }
    
//     if(titleName==="Manual Reports"){
//       document.getElementById("MR").style.background  = "#3B89F4";
//      // document.getElementById("SR").style.color  = "fff";

//       document.getElementById("MD").style.background  = "";
//       document.getElementById("SR").style.background  = "";
//       document.getElementById("TR").style.background  = "";
//       document.getElementById("SM").style.background  = "";
//       document.getElementById("rbi_R").style.background = "";

//       //Style Color:white
//       document.getElementById("MR").style.color  = "#fff";
 
//        document.getElementById("MD").style.color  = "";
//        document.getElementById("SR").style.color  = "";
//        document.getElementById("TR").style.color  = "";
//        document.getElementById("SM").style.color  = "";
//        document.getElementById("rbi_R").style.color = "";
//        //Style icon color:white
//        document.getElementById("MR_icon").style.color  = "#fff";
 
//        document.getElementById("MD_icon").style.color  = "";
//        document.getElementById("SR_icon").style.color  = "";
//        document.getElementById("TR_icon").style.color  = "";
//        document.getElementById("SM_icon").style.color  = "";
//        document.getElementById("rbi_R_icon").style.color = "";
//     }
    
//     if(titleName==="Transaction Reports"){
//       document.getElementById("TR").style.background  = "#3B89F4";
//      // document.getElementById("SR").style.color  = "fff";

//       document.getElementById("MD").style.background  = "";
//       document.getElementById("MR").style.background  = "";
//       document.getElementById("SR").style.background  = "";
//       document.getElementById("SM").style.background  = "";
//       document.getElementById("rbi_R").style.background = "";
//       //Text Color:White
//       document.getElementById("TR").style.color  = "#fff";
//       // document.getElementById("SR").style.color  = "fff";
 
//        document.getElementById("MD").style.color  = "";
//        document.getElementById("MR").style.color  = "";
//        document.getElementById("SR").style.color  = "";
//        document.getElementById("SM").style.color  = "";
//        document.getElementById("rbi_R").style.color = "";
//        //Style icon color:white
//        document.getElementById("TR_icon").style.color  = "#fff";
//       // document.getElementById("SR").style.color  = "fff";
 
//        document.getElementById("MD_icon").style.color  = "";
//        document.getElementById("MR_icon").style.color  = "";
//        document.getElementById("SR_icon").style.color  = "";
//        document.getElementById("SM_icon").style.color  = "";
//        document.getElementById("rbi_R_icon").style.color = "";
//     }
    
//     if(titleName=="SWIFT Messages"){
//       document.getElementById("SM").style.background  = "#3B89F4";
//      // document.getElementById("SR").style.color  = "fff";

//       document.getElementById("MD").style.background  = "";
//       document.getElementById("MR").style.background  = "";
//       document.getElementById("TR").style.background  = "";
//       document.getElementById("SR").style.background  = "";
//       document.getElementById("rbi_R").style.background = "";
//       //Text Color:white
//       document.getElementById("SM").style.color  = "#fff";
//      // document.getElementById("SR").style.color  = "fff";

//       document.getElementById("MD").style.color  = "";
//       document.getElementById("MR").style.color  = "";
//       document.getElementById("TR").style.color  = "";
//       document.getElementById("SR").style.color  = "";
//       document.getElementById("rbi_R").style.color = "";
//       //Style icon Color:white
//       document.getElementById("SM_icon").style.color  = "#fff";
//       // document.getElementById("SR").style.color  = "fff";
 
//        document.getElementById("MD_icon").style.color  = "";
//        document.getElementById("MR_icon").style.color  = "";
//        document.getElementById("TR_icon").style.color  = "";
//        document.getElementById("SR_icon").style.color  = "";
//        document.getElementById("rbi_R_icon").style.color = "";
//     }
    
      
//     if(titleName=="RBI Reportings"){
//       document.getElementById("rbi_R").style.background  = "#3B89F4";
//      // document.getElementById("SR").style.color  = "fff";

//       document.getElementById("MD").style.background  = "";
//       document.getElementById("MR").style.background  = "";
//       document.getElementById("TR").style.background  = "";
//       document.getElementById("SR").style.background  = "";
//       document.getElementById("SM").style.background = "";

//       //Text Color:white
//       document.getElementById("rbi_R").style.color  = "#fff";
//      // document.getElementById("SR").style.color  = "fff";

//       document.getElementById("MD").style.color  = "";
//       document.getElementById("MR").style.color  = "";
//       document.getElementById("TR").style.color  = "";
//       document.getElementById("SR").style.color  = "";
//       document.getElementById("SM").style.color = "";

//       //Style icon Color:white
//       document.getElementById("rbi_R_icon").style.color  = "#fff";
//       // document.getElementById("SR").style.color  = "fff";
 
//        document.getElementById("MD_icon").style.color  = "";
//        document.getElementById("MR_icon").style.color  = "";
//        document.getElementById("TR_icon").style.color  = "";
//        document.getElementById("SR_icon").style.color  = "";
//        document.getElementById("SM_icon").style.color = "";
    // }
    
 
}
}
