// Sidebar route metadata
export interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  id: string;
  icon_id:string;
  class: string;
  ddclass: string;
  extralink: boolean;
  submenu: RouteInfo[];
}
