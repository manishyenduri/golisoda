import { RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [
  {
    path: '/branch/dashboard',
    title: 'Branch Dashboard',
    icon: 'icon-Car-Wheel',
    id:'CD',
    icon_id:'CD_icon',
    class: '',
     ddclass: '',
    extralink: false,
    submenu: [
    ]
  },
  {
    path: '/banker/transaction',
    title: 'Transations',
    icon: 'icon-Owl',
    id:'SR',
    icon_id:'TR_icon',
    class: '',
     ddclass: '',
    extralink: false,
    submenu: [
    ]
  },
  // {
  //   path: '/checker/manual-reports-list',
  //   title: 'Checker Reports',
  //   icon: 'icon-Talk-Man',
  //   id:'MR',
  //   icon_id:'MR_icon',
  //   class: '',
  //    ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  // {
  //   path: '/checker/transaction-reports',
  //   title: 'Transaction Reports',
  //   icon: 'icon-Mail-Money',
  //   id:'TR',
  //   icon_id:'TR_icon',
  //   class: '',
  //    ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  // {
  //   path: '/checker/approval-board',
  //   title: 'Approval Board',
  //   icon: 'icon-File-HorizontalText',
  //   id:'AB',
  //   icon_id:'AB_icon',
  //   class: '',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  // {
  //   path: '/checker/swift-messages',
  //   title: 'SWIFT Messages',
  //   icon: 'icon-Email',
  //   id:'SM',
  //   icon_id:'SM_icon',
  //   class: '',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // },
  // {
  //   path: '/checker/rbi-reportings',
  //   title: 'RBI Reportings',
  //   icon: 'icon-Folder-WithDocument',
  //   id:'RB',
  //   icon_id:'RB_icon',
  //   class: '',
  //   ddclass: '',
  //   extralink: false,
  //   submenu: [
  //   ]
  // }
  
];
