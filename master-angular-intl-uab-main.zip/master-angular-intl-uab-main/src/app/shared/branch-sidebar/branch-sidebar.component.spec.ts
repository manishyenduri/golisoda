import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchSidebarComponent } from './branch-sidebar.component';

describe('BranchSidebarComponent', () => {
  let component: BranchSidebarComponent;
  let fixture: ComponentFixture<BranchSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BranchSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BranchSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
