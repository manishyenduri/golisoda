
import { Component, AfterViewInit, OnInit } from '@angular/core';
import { ROUTES } from './menu-items';
import { RouteInfo } from './sidebar.metadata';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
declare var $: any;

@Component({
  selector: 'app-branch-sidebar',
  templateUrl: './branch-sidebar.component.html',
  styleUrls: ['./branch-sidebar.component.css']
})
export class BranchSidebarComponent implements OnInit {
  showMenu = '';
  showSubMenu = '';
  public sidebarnavItems: any[];
  // this is for the open close
  addExpandClass(element: any) {
    if (element === this.showMenu) {
      this.showMenu = '0';
    } else {
      this.showMenu = element;
    }
  }
  addActiveClass(element: any) {
    if (element === this.showSubMenu) {
      this.showSubMenu = '0';
    } else {
      this.showSubMenu = element;
    }
  }

  constructor(
    private modalService: NgbModal,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  // End open close
  ngOnInit() {
    this.sidebarnavItems = ROUTES.filter(sidebarnavItem => sidebarnavItem);
  }
   tabCssFunction(event,title){
    //  style background
    
    if(title=="Checker Dashboard"){
      document.getElementById("CD").style.background = "#3B89F4";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("RB").style.background = "";
      document.getElementById("AB").style.background = "";
      
      document.getElementById("CD").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("RB").style.color  = "";
      document.getElementById("AB").style.color  = "";
      
      document.getElementById("RB_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("CD_icon").style.color  = "#fff";
      document.getElementById("AB_icon").style.color  = "";
    }

    
    if(title=="SIMBA Reports"){
      document.getElementById("SR").style.background = "#3B89F4";
      document.getElementById("CD").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("RB").style.background = "";
      document.getElementById("AB").style.background = "";
      
      document.getElementById("SR").style.color  = "#fff";
      document.getElementById("CD").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("RB").style.color  = "";
      document.getElementById("AB").style.color  = "";
      
      document.getElementById("RB_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "#fff";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("CD_icon").style.color  = "";
      document.getElementById("AB_icon").style.color  = "";
    }
    
    if(title=="Checker Reports"){
      document.getElementById("MR").style.background = "#3B89F4";
      document.getElementById("SR").style.background = "";
      document.getElementById("CD").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("RB").style.background = "";
      document.getElementById("AB").style.background = "";
      
      document.getElementById("MR").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("CD").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("RB").style.color  = "";
      document.getElementById("AB").style.color  = "";
      
      document.getElementById("RB_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "#fff";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("CD_icon").style.color  = "";
      document.getElementById("AB_icon").style.color  = "";
    }
    
    
    if(title=="Transaction Reports"){
      document.getElementById("TR").style.background = "#3B89F4";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("CD").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("RB").style.background = "";
      document.getElementById("AB").style.background = "";
      
      document.getElementById("TR").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("CD").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("RB").style.color  = "";
      document.getElementById("AB").style.color  = "";
      
      document.getElementById("RB_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "#fff";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("CD_icon").style.color  = "";
      document.getElementById("AB_icon").style.color  = "";
    }

    if(title=="Approval Board"){
      document.getElementById("AB").style.background = "#3B89F4";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("CD").style.background = "";
      document.getElementById("RB").style.background = "";
      document.getElementById("SM").style.background = "";
      
      document.getElementById("AB").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("CD").style.color  = "";
      document.getElementById("RB").style.color  = "";
      document.getElementById("SM").style.color  = "";
      
      document.getElementById("RB_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("CD_icon").style.color  = "";
      document.getElementById("AB_icon").style.color  = "#fff";
    }
    
    if(title=="SWIFT Messages"){
      document.getElementById("SM").style.background = "#3B89F4";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("CD").style.background = "";
      document.getElementById("RB").style.background = "";
      document.getElementById("AB").style.background = "";
      
      document.getElementById("SM").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("CD").style.color  = "";
      document.getElementById("RB").style.color  = "";
      document.getElementById("AB").style.color  = "";
      
      document.getElementById("RB_icon").style.color  = "";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "#fff";
      document.getElementById("CD_icon").style.color  = "";
      document.getElementById("AB_icon").style.color  = "";
    }

    if(title=="RBI Reportings"){
      document.getElementById("RB").style.background = "#3B89F4";
      document.getElementById("SR").style.background = "";
      document.getElementById("MR").style.background = "";
      document.getElementById("TR").style.background = "";
      document.getElementById("SM").style.background = "";
      document.getElementById("CD").style.background = "";
      document.getElementById("AB").style.background = "";
      
      document.getElementById("RB").style.color  = "#fff";
      document.getElementById("SR").style.color  = "";
      document.getElementById("MR").style.color  = "";
      document.getElementById("TR").style.color  = "";
      document.getElementById("SM").style.color  = "";
      document.getElementById("CD").style.color  = "";
      document.getElementById("AB").style.color  = "";
      
      document.getElementById("RB_icon").style.color  = "#fff";
      document.getElementById("SR_icon").style.color  = "";
      document.getElementById("MR_icon").style.color  = "";
      document.getElementById("TR_icon").style.color  = "";
      document.getElementById("SM_icon").style.color  = "";
      document.getElementById("CD_icon").style.color  = "";
      document.getElementById("AB_icon").style.color  = "";
    }

    // if(title==="Checker Dashboard"){
    //   document.getElementById("CD").style.background="#3B89F4";
    //   document.getElementById("SR").style.background="";
    //   document.getElementById("MR").style.background="";
    //   document.getElementById("TR").style.background="";
    //   document.getElementById("AB").style.background="";
    //   document.getElementById("SM").style.background="";
    //   document.getElementById("RB").style.background="";
    //   // style text
    //   document.getElementById("CD").style.color="#fff";
    //   document.getElementById("SR").style.color="";
    //   document.getElementById("MR").style.color="";
    //   document.getElementById("TR").style.color="";
    //   document.getElementById('AB').style.color="";
    //   document.getElementById("SM").style.color="";
    //   document.getElementById('RB').style.color="";
    
    //   // style icon
    //   document.getElementById("CD_icon").style.color="#fff";
    //   document.getElementById("SR_icon").style.color="";
    //   document.getElementById("'MR_icon").style.color="";
    //   document.getElementById("TR_icon").style.color="";
    //   document.getElementById("AB_icon").style.color="";
    //   document.getElementById("SM_icon").style.color="";
    //   document.getElementById("RB_icon").style.color="";
    // }
    // if(title==="SIMBA Reports"){
    //   document.getElementById("CD").style.background="";
    //   document.getElementById("SR").style.background="#3B89F4";
    //   document.getElementById("MR").style.background="";
    //   document.getElementById("TR").style.background="";
    //   document.getElementById("AB").style.background="";
    //   document.getElementById("SM").style.background="";
    //   document.getElementById("RB").style.background="";
    //   // style text
    //   document.getElementById("CD").style.color="";
    //   document.getElementById("SR").style.color="#fff";
    //   document.getElementById("MR").style.color="";
    //   document.getElementById("TR").style.color="";
    //   document.getElementById("AB").style.color="";
    //   document.getElementById("SM").style.color="";
    //   document.getElementById("RB").style.color="";
    
    //   // style icon
    //   document.getElementById("CD_icon").style.color="";
    //   document.getElementById("SR_icon").style.color="#fff";
    //   document.getElementById("MR_icon").style.color="";
    //   document.getElementById("TR_icon").style.color="";
    //   document.getElementById("AB_icon").style.color="";
    //   document.getElementById("SM_icon").style.color="";
    //   document.getElementById("RB_icon").style.color="";
    // }
    // if(title==="Manual Reports"){
    //   document.getElementById("CD").style.background="";
    //   document.getElementById("SR").style.background="";
    //   document.getElementById("MR").style.background="#3B89F4";
    //   document.getElementById("TR").style.background="";
    //   document.getElementById("AB").style.background="";
    //   document.getElementById("SM").style.background="";
    //   document.getElementById("RB").style.background="";
    //   // style text
    //   document.getElementById("CD").style.color="";
    //   document.getElementById("SR").style.color="";
    //   document.getElementById("MR").style.color="#fff";
    //   document.getElementById("TR").style.color="";
    //   document.getElementById("AB").style.color="";
    //   document.getElementById("SM").style.color="";
    //   document.getElementById("RB").style.color="";
    
    //   // style icon
    //   document.getElementById("CD_icon").style.color="";
    //   document.getElementById("SR_icon").style.color="";
    //   document.getElementById("MR_icon").style.color="#fff";
    //   document.getElementById("TR_icon").style.color="";
    //   document.getElementById("AB_icon").style.color="";
    //   document.getElementById("SM_icon").style.color="";
    //   document.getElementById("RB_icon").style.color="";
    // }
    // if(title==="Transaction Reports"){
    //   document.getElementById("CD").style.background="";
    //   document.getElementById("SR").style.background="";
    //   document.getElementById("MR").style.background="";
    //   document.getElementById("TR").style.background="#3B89F4";
    //   document.getElementById("AB").style.background="";
    //   document.getElementById("SM").style.background="";
    //   document.getElementById("RB").style.background="";
    //   // style text
    //   document.getElementById("CD").style.color="";
    //   document.getElementById("SR").style.color="";
    //   document.getElementById("MR").style.color="";
    //   document.getElementById("TR").style.color="#fff";
    //   document.getElementById("AB").style.color="";
    //   document.getElementById("SM").style.color="";
    //   document.getElementById("RB").style.color="";
    
    //   // style icon
    //   document.getElementById("CD_icon").style.color="";
    //   document.getElementById("SR_icon").style.color="";
    //   document.getElementById("MR_icon").style.color="";
    //   document.getElementById("TR_icon").style.color="#fff";
    //   document.getElementById("AB_icon").style.color="";
    //   document.getElementById("SM_icon").style.color="";
    //   document.getElementById("RB_icon").style.color="";
    // }
    // if(title==="Approval Board"){
    //   document.getElementById("CD").style.background="";
    //   document.getElementById("SR").style.background="";
    //   document.getElementById("MR").style.background="";
    //   document.getElementById("TR").style.background="";
    //   document.getElementById("AB").style.background="#3B89F4";
    //   document.getElementById("SM").style.background="";
    //   document.getElementById("RB").style.background="";
    //   // style text
    //   document.getElementById("CD").style.color="";
    //   document.getElementById("SR").style.color="";
    //   document.getElementById("MR").style.color="";
    //   document.getElementById("TR").style.color="";
    //   document.getElementById("AB").style.color="#fff";
    //   document.getElementById("SM").style.color="";
    //   document.getElementById("RB").style.color="";
    
    //   // style icon
    //   document.getElementById("CD_icon").style.color="";
    //   document.getElementById("SR_icon").style.color="";
    //   document.getElementById("MR_icon").style.color="";
    //   document.getElementById("TR_icon").style.color="";
    //   document.getElementById("AB_icon").style.color="#fff";
    //   document.getElementById("SM_icon").style.color="";
    //   document.getElementById("RB_icon").style.color="";
    // }
    // if(title==="SWIFT Messages"){
    //   document.getElementById("CD").style.background="";
    //   document.getElementById("SR").style.background="";
    //   document.getElementById("MR").style.background="";
    //   document.getElementById("TR").style.background="";
    //   document.getElementById("AB").style.background="";
    //   document.getElementById("SM").style.background="#3B89F4";
    //   document.getElementById("RB").style.background="";
    //   // style text
    //   document.getElementById("CD").style.color="";
    //   document.getElementById("SR").style.color="";
    //   document.getElementById("MR").style.color="";
    //   document.getElementById("TR").style.color="";
    //   document.getElementById("AB").style.color="";
    //   document.getElementById("SM").style.color="#fff";
    //   document.getElementById("RB").style.color="";
    
    //   // style icon
    //   document.getElementById("CD_icon").style.color="";
    //   document.getElementById("SR_icon").style.color="";
    //   document.getElementById("MR_icon").style.color="";
    //   document.getElementById("TR_icon").style.color="";
    //   document.getElementById("AB_icon").style.color="";
    //   document.getElementById("SM_icon").style.color="#fff";
    //   document.getElementById("RB_icon").style.color="";
    // }
    // if(title==="RBI Reportings"){
    //   document.getElementById("CD").style.background="";
    //   document.getElementById("SR").style.background="";
    //   document.getElementById("MR").style.background="";
    //   document.getElementById("TR").style.background="";
    //   document.getElementById("AB").style.background="";
    //   document.getElementById("SM").style.background="";
    //   document.getElementById("RB").style.background="#3B89F4";
    //   // style text
    //   document.getElementById("CD").style.color="";
    //   document.getElementById("SR").style.color="";
    //   document.getElementById("MR").style.color="";
    //   document.getElementById("TR").style.color="";
    //   document.getElementById("AB").style.color="";
    //   document.getElementById("SM").style.color="";
    //   document.getElementById("RB").style.color="#fff";
    
    //   // style icon
    //   document.getElementById("CD_icon").style.color="";
    //   document.getElementById("SR_icon").style.color="";
    //   document.getElementById("MR_icon").style.color="";
    //   document.getElementById("TR_icon").style.color="";
    //   document.getElementById("AB_icon").style.color="";
    //   document.getElementById("SM_icon").style.color="";
    //   document.getElementById("RB_icon").style.color="#fff";
    // }
  }
}
