import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, FormGroup, FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  userData: any;
  submitted = false;
  erroMsg: string;
  loading: boolean;
  resetloading: boolean;
  recoverform = false;
  forgotPswd: any;
  role: any;
  checkUAT:any;
  
  
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.loginForm = fb.group({
      'userId': [null, Validators.required],
      'password': [null, Validators.required],
     });

   }
   get f() { return this.loginForm.controls; }
  ngOnInit() {
    this.checkUAT=false;
  }
  loginUser(formdata: any) {  
    if(this.checkUAT===false){
    alert("Please accept the UAT agreement!");
    return;}
    this.submitted = true;
    if ((formdata.userId !== null) && (formdata.password !== null)) {
      this.loading = true;
    }
    // if(formdata.userId === 'B0001' && formdata.password === 'test123'){
    //   this.router.navigate(['/branch/dashboard'])
    // }

    this.authService.login(formdata).subscribe (
        data => {
         this.userData = (data);
         const dataVal = this.userData.items;
         for (const item of dataVal) {
          for (const role of item.roles) {
            this.role = item.roles;
          }
          if ((this.userData.responseStatus === 200) &&
          (this.role === 'admin')) {
            localStorage.setItem('access_token', data.items[0].access_token);
            localStorage.setItem('refresh_token', data.items[0].refresh_token);
            this.router.navigate(['/admin/dashboard']);
          }  
          if ((this.userData.responseStatus === 200) &&
          (this.role === 'maker')) {
            localStorage.setItem('access_token', data.items[0].access_token);
            localStorage.setItem('refresh_token', data.items[0].refresh_token);
            this.router.navigate(['/maker/dashboard']);
          }
          if ((this.userData.responseStatus === 200) &&
          (this.role === 'checker')) {
            localStorage.setItem('access_token', data.items[0].access_token);
            localStorage.setItem('refresh_token', data.items[0].refresh_token);
            this.router.navigate(['/checker/checker-dashboard']);
          }
          
          if ((this.userData.responseStatus === 200) &&
          (this.role === 'banker')) {
            localStorage.setItem('access_token', data.items[0].access_token);
            localStorage.setItem('refresh_token', data.items[0].refresh_token);
            this.router.navigate(['/branch/dashboard']);
          }
         }
        } ,
         error => {
          if (error.responseStatus === 400) {
            this.loading = false;
            this.erroMsg = error.error;
          } else if (error.responseStatus === 500) {
            this.loading = false;
            this.erroMsg = error.error;
          }
         },
         () => console.log('user logged in')
    );

        }

  openSignUp(){
    this.router.navigate(['signup']);
  }
  
checkUATFunc(){
  this.checkUAT=!this.checkUAT;
  }
}

 
