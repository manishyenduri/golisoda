import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-checker',
  templateUrl: './add-checker.component.html',
  styleUrls: ['./add-checker.component.css']
})
export class AddCheckerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
