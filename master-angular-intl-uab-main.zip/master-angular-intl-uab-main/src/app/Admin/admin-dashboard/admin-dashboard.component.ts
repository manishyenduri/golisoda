import { Component, OnInit } from '@angular/core';
import {Chart} from 'chart.js';
import {con} from './country2';
import {emplist} from './emplylist';
//import * as d33 from 'd3';
import * as d3 from "d3";
//import * as d3 from 'd3-selection';
import * as d3Scale from 'd3-scale';
import * as d3Shape from 'd3-shape';
import * as d3Array from 'd3-array';
import * as d3Axis from 'd3-axis';
import { m } from './ddd';

//For temporary reason
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { chartData } from './chartData';
import { MakerService } from 'src/app/services/maker/docs.service';
//import { from } from 'rxjs';

//End
@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  visible=false;
  country:any=con;
  emplylist:any=emplist;
  chartData:any=chartData;
  PieChart=[];
  BarChart=[];
  RegionChart=[];
  countMK_s:number=0;
  countMK_w:number=0;
  countMK_e:number=0;
  countMK_n:number=0;
  countCK_s:number=0;
  countCK_w:number=0;
  countCK_e:number=0;
  countCK_n:number=0;


  //d3 variables
 
  private margin = {top: 20, right: 20, bottom: 30, left: 50};
    private width: number;
    private height: number;
    private x: any;
    private y: any;
    private svg: any;
    private line: d3Shape.Line<[number, number]>;

  constructor(private _http: HttpClient) { }

  ngOnInit() {
  this.getCount(chartData);
   this.regionDoughnutChart();
   this.displayBarChart();
   this.myfun();
  }
//Gets the total count of the North, South, East, West Data
getCount(chartData){
  for(let i=0;i<chartData.length;i++)
    if(chartData[i].id=="mk")
    {
      if(chartData[i].region==="north")
        this.countMK_n = this.countMK_n + chartData[i].data;
      else
      if(chartData[i].region==="south")
        this.countMK_s = this.countMK_s + chartData[i].data; 
      else
        if(chartData[i].region==="west")
        this.countMK_w = this.countMK_w + chartData[i].data; 
      else
        if(chartData[i].region==="east")
        this.countMK_e = this.countMK_e + chartData[i].data; 
    }
    else
    if(chartData[i].id=="ck")
    {
      if(chartData[i].region==="north")
        this.countCK_n = this.countCK_n + chartData[i].data;
      else
      if(chartData[i].region==="south")
        this.countCK_s = this.countCK_s + chartData[i].data; 
      else
        if(chartData[i].region==="west")
        this.countCK_w = this.countCK_w + chartData[i].data; 
      else
        if(chartData[i].region==="east")
        this.countCK_e = this.countCK_e + chartData[i].data; 
    }


}
//Region Wise Maker & Checker Analysis
region()
{
  console.log("test");
}
regionDoughnutChart(){
  this.RegionChart = new Chart('regionChart',{
    type:'bar',
    data:{
      click:(e)=>{console.log("sdsd")},
      labels: ["North","East","South","West"],
      datasets:[{
        
        label:'Maker',
        data: [this.countMK_n,this.countMK_e,this.countMK_s,this.countMK_w],
        backgroundColor: [ 
          'rgb(19, 122, 228)',
          'rgb(19, 122, 228)',
          'rgb(19, 122, 228)',
          'rgb(19, 122, 228)'],
        borderColor: [ 
            'rgba(19, 122, 228,1)',
            'rgba(19, 122, 228, 1)',
            'rgba(19, 122, 228, 1)',
            'rgba(19, 122, 228, 1)'],
        borderWidth:1
      },
      {
        label:'Checker',
        data: [this.countCK_n,this.countCK_e,this.countCK_s,this.countCK_w],
        backgroundColor: [ 
        'rgb(129, 180, 232)',
				'rgb(129, 180, 232)',
				'rgb(129, 180, 232)',
				'rgb(129, 180, 232)'],
        borderColor: [ 
          'rgba(129, 180, 232,1)',
          'rgba(129, 180, 232, 1)',
          'rgba(129, 180, 232, 1)',
          'rgba(129, 180, 232, 1)'],
        borderWidth:1
      }],
      options: {
        responsive: true, // Instruct chart js to respond nicely.
        maintainAspectRatio: false, // Add to prevent default behaviour of full-width/height 
        click:(e)=>{console.log(e);}
      
      }
    }
  })
  /*
  this.RegionChart = new Chart('regionChart',{
    type:'doughnut',
    data:
    {
      labels:["North","East","South","West"],
      datasets:[{
        
        //label: ["Maker","Maker","Maker","Maker"],
        data:[this.countMK_n,this.countMK_e,this.countMK_s,this.countMK_w],
        backgroundColor:[
          "#C70039","#FFC300","#1A43B7","#10C064"
        ],
        hoverBackgroundColor: ["gray","gray","gray","gray"],
        hoverBorderColor: ["#C70039","#FFC300","#1A43B7","#10C064"],
        hoverBorderWidth: 10
      },
      {
        label: ['Checker','Checker','Checker','Checker'],
        //mouseover:function(e){console.log("Executing")},
        data:[this.countCK_n,this.countCK_e,this.countCK_s,this.countCK_w],
        backgroundColor:[
          "#FF5733","#F7F613","#15A1DC","#22DC15"
        ],
        hoverBackgroundColor: ["gray","gray","gray","gray"],
        hoverBorderColor: ["#FF5733","#F7F613","#15A1DC","#22DC15"],
        hoverBorderWidth: 10
      }]
    },
    options:{
      responsive:true,
      title:{
        display: true,
        text: 'Region Wise Analysis'
      },
     // events: ['click'],
      legend:{
        position:'left'
        //hide:true
      },
      animation:{
        animateScale:true,
        animateRotate:true
      },
      onClick:(e)=>{
        console.log(this.RegionChart.chart.getElementAtEvent(event));
      }
    }
  });*/
  //this.displayBarChart();
}


displayBarChart(){
  
  this.BarChart = new Chart('barChart',{
    //label:[""],
    type:'bar',
    data:{
      labels:["A & D Isands","Andra Pradesh","Karnataka","Kerala","Lakshadweep","Puducherry","Tamil Nadu","Telangana"],
      datasets:[{
        data:[23,33,12,45,66,88,44,55],
        backgroundColor:"#78C9E9"
      }]
    }
  });
}

  Search(){}

  ShowTable(){
    
    this.visible=true;

  }


//D3 function fetching data and loading

myfun(){
  this.svg = d3.select('svg');
  const rect = this.svg.selectAll('rect');

  const y = d3.scaleLinear()
              .domain([0, 70])
              .range([0, 250]);

  const x = d3.scaleBand()
              .domain(m.map((item) => {
                  return item.region
                  return item.role
              }))
              .range([0, 250])
              .paddingInner(0.2)
              .paddingOuter(0.3);

          console.log(m.map(item => item.region && item.role ))

  rect.data(m)
        .enter().append('rect')
        .attr('width',x.bandwidth())
        .attr('height',(d,i)=>y(d.data))
        .attr('x',(d)=>x(d.region));
}




/*
  myfun(){
    //const f =[this.countCK_e,this.countCK_n,this.countCK_s,this.countCK_w];
  const regionFields = [this.countCK_e,this.countCK_n,this.countCK_s,this.countCK_w];
  
  this.svg = d3.select('svg').attr('width',100).attr('height',100);
  
  const rect=this.svg.selectAll('rect');

  const y = d3.scaleLinear()
                .domain([0, d3.max(m, d => d.data)])
                .range([0, 250]);

  const x = d3.scaleBand()
                .domain(m.map(item => item.region))
                .range([0,500]);

  console.log(m.map(item => item.region))

                rect.data(regionFields)
                .enter().append('rect')
                .attr('width',20)
                .attr('height', (d, i)=>y(d.data) )
                .attr('x',function(d,i){return i*24;})
                .attr('fill','red');
                //.attr('y',function(d,i){return 100-(d*2)});
  }*/

}
