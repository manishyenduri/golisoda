//let regionData, stateData;
export let chartData = [
    {"region":"north", "state":"delhi", "role":"maker","data":12, "id":"mk"},
    {"region":"north", "state":"delhi", "role":"checker","data":12, "id":"ck"},
    {"region":"north", "state":"bihar", "role":"maker","data":9, "id":"mk"},
    {"region":"north", "state":"bihar", "role":"checker","data":7, "id":"ck"},
    {"region":"north", "state":"bhopal", "role":"maker","data":6, "id":"mk"},
    {"region":"north", "state":"bhopal", "role":"checker","data":7, "id":"ck"},

    {"region":"east","state":"rajisthan", "role":"maker", "data":13, "id":"mk"},
    {"region":"east","state":"rajisthan", "role":"checker", "data":10, "id":"ck"},
    {"region":"east", "state":"gujarat", "role":"maker","data":10, "id":"mk"},
    {"region":"east", "state":"gujarat", "role":"checker","data":9, "id":"ck", "code":"G"},

    {"region":"west","state":"sikkim","role":"maker","data":3, "id":"mk", "code":"sk"},
    {"region":"west","state":"sikkim","role":"checker","data":2, "id":"ck", "code":"sk"},
    {"region":"west","state":"west_bengal","role":"maker","data":10,"id":"mk", "code":"wb"},
    {"region":"west","state":"west_bengal","role":"checker","data":10,"id":"ck", "code":"wb"},

    {"region":"south", "state":"a_n_islands","role":"maker","data":5, "id":"mk"},
    {"region":"south", "state":"andra_pradesh","role":"maker","data":12, "id":"mk"},
    {"region":"south", "state":"a_n_islands", "role":"checker", "data":4, "id":"ck"},
    {"region":"south", "state":"andra_pradesh", "role":"checker","data":8, "id":"ck"},
    {"region":"south", "state":"karnataka","role":"maker","data":12, "id":"mk"},
    {"region":"south", "state":"karnataka", "role":"checker", "data":4, "id":"ck"},
    {"region":"south", "state":"kerala","role":"maker","data":40, "id":"mk"},
    {"region":"south", "state":"kerala","role":"checker", "data":20, "id":"ck"},
    {"region":"south", "state":"lakshadweep","role":"maker","data":15, "id":"mk"},
    {"region":"south", "state":"lakshadweep", "role":"checker", "data":10, "id":"ck"},
    {"region":"south", "state":"puducherry","role":"maker","data":20, "id":"mk"},
    {"region":"south", "state":"puducherry", "role":"checker", "data":17, "id":"ck"},
    {"region":"south", "state":"tamil_nadu","role":"maker","data":15, "id":"mk"},
    {"region":"south", "state":"tamil_nadu", "role":"checker", "data":13, "id":"ck"},
    {"region":"south", "state":"telangana","role":"maker","data":7, "id":"mk"},
    {"region":"south", "state":"telangana", "role":"checker", "data":3, "id":"ck"}
    
]