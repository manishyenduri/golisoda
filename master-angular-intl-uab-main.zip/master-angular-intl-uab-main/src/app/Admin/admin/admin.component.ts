import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin/docs.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  email_Id: any;
  admin:String = "Admin";
  constructor(private _httpService: AdminService) { }

  ngOnInit() {
  }

  register(){
   /* const body ={
      "branch_Name": "itpl",
      "city": "Bangalore",
      "country": "India",
      "designation": "manager",
      "emailId": "tilifi3792@mail3tech.comq",
      "employeeId": "i0004",
      "employeeName": "John",
      "reporting_Authority": "general",
      "roles": "maker"
    
};
  this._httpService.userRegisteration(body).subscribe(data =>{
    console.log(data)
  });*/
  
   this._httpService.registerAdmin(this.email_Id).subscribe(data=>{
     console.log(data)
     if(data.code === 200)
     {
      Swal.fire({
        title: "Successful Registration",
        html: data.message + '<br/>'+ 'Request-Id : ' + data.request_id,
        confirmButtonText:'OK',
      }).then(()=>{
        
      })
      
    }
    else
    if(data.code === 400){
      Swal.fire({
        title: 'Oops...',
        text: data.error,
        footer: '<a href>Click here to login</a>'
      })
    }
   })


 
  }

}
