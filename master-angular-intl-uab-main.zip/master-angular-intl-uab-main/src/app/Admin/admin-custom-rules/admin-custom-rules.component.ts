import { Component, OnInit } from '@angular/core';
import { MakerService } from 'src/app/services/maker/docs.service';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-admin-custom-rules',
  templateUrl: './admin-custom-rules.component.html',
  styleUrls: ['./admin-custom-rules.component.css']
})
export class AdminCustomRulesComponent implements OnInit {

  document_set:any=[
    {id:0, name:"Invoice", type:"inv", ruleList:[{id:0, name:"applicant_name"},{id:1, name:"applicant_address"},{id:2, name:"beneficiary_name"},
      {id:3, name:"benificiary_address"}] },
    {id:1, name:"Bill of Lading", type:"bol",  ruleList:[{id:0, name:"applicant_name"},{id:1, name:"applicant_address"},{id:2, name:"beneficiary_name"},
      {id:3, name:"benificiary_address"}] },
    {id:2, name:"Bill of Exchange", type:"boe" },
    {id:3, name:"Certificate of Origin", type:"inv" },
    {id:4, name:"Insurance", type:"ins" },
    {id:5, name:"Airway Bill", type:"awb" }
  ]

  ref_set:any=[
    {id:0, name:"Invoice", type:"inv", ruleList:[{id:0, name:"applicant_name"},{id:1, name:"applicant_address"},{id:2, name:"beneficiary_name"},
      {id:3, name:"benificiary_address"}] },
    {id:1, name:"Bill of Lading", type:"bol",  ruleList:[{id:0, name:"applicant_name"},{id:1, name:"applicant_address"},{id:2, name:"beneficiary_name"},
      {id:3, name:"benificiary_address"}] },
    {id:2, name:"Bill of Exchange", type:"boe" },
    {id:3, name:"Certificate of Origin", type:"inv" },
    {id:4, name:"Insurance", type:"ins" },
    {id:5, name:"Airway Bill", type:"awb" }
  ]
  filter_rules:any=[{id:0,name:"Applicant Name", type:'applicant_name'},{id:1,name:"Applicant Address", type:'applicant_address'},
  {id:2,name:"Beneficiary Name", type:'beneficiary_name'}]

  listOfSegregatedRules:any=[{id:0, name:"Applicant Name", accuracy:"100%"},{id:1,name:"Applicant Address",accuracy:"99%"},{id:2, name:"Beneficiary Name", accuracy:"100%"},{id:3, name:"Beneficiary Address", accuracy:"100%"},
  {id:4, name:"Currency Code", accuracy:"100%"},{id:5, name:"Amount", accuracy:"100%"},{id:6, name:"Product Code", accuracy:"100%"}]

  boe: any;
  bol: any;
  dataValue: any = [];
  insurance: any;
  coo: any;
  awb: any;
  ruleItems:any;
  rulesData: any;
  listOfRules: any;
  
  firstRuleId: any;
  FirstruleExists: boolean = false;

  leftTitle:any="Invoice";
  rightTitle:any="Bill of Exchange";

  leftRuleImg:SafeResourceUrl;
  rightRuleImg:SafeResourceUrl;

  constructor(private _httpService:MakerService, public sanitizer: DomSanitizer) { }



  ngOnInit() {

    this.leftRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl('https://lc-ocr.s3.ap-south-1.amazonaws.com/XH8S1ENRK0/invoice.pdf');
    this.rightRuleImg=this.sanitizer.bypassSecurityTrustResourceUrl('https://lc-ocr.s3.ap-south-1.amazonaws.com/XH8S1ENRK0/bill_of_lading.pdf');

      this._httpService.getRequestById().subscribe(
          data => {
            console.log("Check Data",data);
              this.rulesData = (data);
              const dataVal = this.rulesData.data;
              this.dataValue = data
              this.ruleItems = this.rulesData.data;
              console.log(dataVal.length);
              console.log('dataVal', dataVal);
              this.listOfRules = dataVal.inv.length;
              this.boe = dataVal.boe.length
              this.bol =dataVal.bol.length
              this.awb = dataVal.awb.length;
              this.coo = dataVal.coo.length
              this.insurance =dataVal.ins.length
              console.log( this.listOfRules);
            });
  
  }

  docsClick(evt, docType){
    console.log("docType",evt.target.id)
  }
  refClick(event, refType){
console.log("refType",refType)
  }
  filterRulesSet(){
  
  }

  zoomin() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth + 100) + "px"; 
    GFG.style.height = (currHeight + 100) + "px"; 
  } 
  
   zoomout() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth - 100) + "px"; 
    GFG.style.height = (currHeight + 100) + "px"; 
  }

  
zoomin_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

comply(evt){

}

}
