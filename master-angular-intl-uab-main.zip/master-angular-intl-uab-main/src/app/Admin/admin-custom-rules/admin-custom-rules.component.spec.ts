import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCustomRulesComponent } from './admin-custom-rules.component';

describe('AdminCustomRulesComponent', () => {
  let component: AdminCustomRulesComponent;
  let fixture: ComponentFixture<AdminCustomRulesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCustomRulesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCustomRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
