import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { MustMatch } from '../../../_helpers/must-match.validator';
import { AuthService } from '../../../services/auth.service';
import swal from 'sweetalert2';
@Component({
  selector: 'app-admin-change-password',
  templateUrl: './admin-change-password.component.html',
  styleUrls: ['./admin-change-password.component.css']
})
export class AdminChangePasswordComponent implements OnInit {
  adminpassword:any;
  adminForm:any;
  adminValidate: FormGroup;
  emailId: any = "";
  oldPassword: any = "";
  secret:any;
  token: any;
  forgotForm: FormGroup;
  userData: any;
  submitted = false;
  erroMsg: string;
  loading: boolean;
  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute,private authService: AuthService, private router: Router) { 
    this.forgotForm = this.formBuilder.group({
      emailId: [''],
      // oldPassword:[''],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required]
  }, {
      validator: MustMatch('password', 'confirmPassword')
  });
  }
  get f() { return this.forgotForm.controls; }
  ngOnInit() {
    
    const emailId = this.route.snapshot.paramMap.get('emailId'); 
    const oldPassword = this.route.snapshot.paramMap.get('oldPassword');
    this.forgotForm.value.emailId = emailId
    // this.forgotForm.value.oldPassword = oldPassword
    this.emailId = emailId
    this.oldPassword = oldPassword
    console.log(emailId,oldPassword)

  }

  createPassword(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.forgotForm.invalid) {
        return;
        
    }
    const emailId = this.emailId
    const oldPassword = this.oldPassword
    const newPassword = this.forgotForm.value.password
    this.authService.resetPassword(emailId,oldPassword,newPassword).subscribe(data=>{
    
        this.userData = (data);
      
        if ((this.userData.responseStatus === 200)) {
          console.log('200-Success');
          this.loading = false;
          this.erroMsg = '';
         
          this.submitted = false;
          swal.fire({
            title: 'Success',
            text: data.message,
            type: 'success',
            showCancelButton: false,
            confirmButtonColor: '#535BE2',
            cancelButtonColor: '#FF7E39',
            confirmButtonText: 'OK',
          }).then((confirm) => {
                if (confirm) {
                  this.router.navigate(['/login']);
                }
              });
        
        }

      },
      error => {
         console.log('error', error,);

        if (error.responseStatus === 401) {
          // console.log('inside if');
          this.loading = false;
          this.erroMsg = error.error;
          swal.fire({
            title: 'Unsuccessful',
            text: error.message,
            type: 'error',
            showCancelButton: false,
            confirmButtonColor: '#535BE2',
            cancelButtonColor: '#FF7E39',
            confirmButtonText: 'OK',
          }).then((confirm) => {
                if (confirm) {
                  this.router.navigate(['/login']);
                }
              });
        } else if (error.responseStatus === 500) {
          // console.log('inside if');
          this.loading = false;
          this.erroMsg = error.error;
          swal.fire({
            title: 'Unsuccessful',
            text: error.error,
            type: 'error',
            showCancelButton: false,
            confirmButtonColor: '#535BE2',
            cancelButtonColor: '#FF7E39',
            confirmButtonText: 'OK',
          }).then((confirm) => {
                if (confirm) {
                  this.router.navigate(['/login']);
                }
              });
        } else if (error.responseStatus === 400) {
          // console.log('inside if'); 
          this.loading = false;
          this.erroMsg = error.error; 
          swal.fire({
            title: 'Unsuccessful',
            text: error.error,
            type: 'error',
            showCancelButton: false,
            confirmButtonColor: '#535BE2',
            cancelButtonColor: '#FF7E39',
            confirmButtonText: 'OK',
          }).then((confirm) => {
                if (confirm) {
                  this.router.navigate(['/login']);
                }
              });
        }
      },
      () => console.log()
    );

  }
  
  

}
