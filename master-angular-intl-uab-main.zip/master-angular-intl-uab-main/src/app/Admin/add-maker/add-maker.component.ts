import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin/docs.service'
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddMakerModalComponent } from './add-maker-modal/add-maker-modal.component';
import { Router } from '@angular/router';
import swal from 'sweetalert2';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-add-maker',
  templateUrl: './add-maker.component.html',
  styleUrls: ['./add-maker.component.css']
})
export class AddMakerComponent implements OnInit {
  searchName:any="";
  // employeeName:any="";
  addMakerForm: boolean;
  // addCheckerForm:boolean;
  tableCSs = false;
  name: string;
  email: any;
  password: any;
  employeeid: string;
  branch: string;
  formDataValues: any;
  formDataValuesJson: any;
  modalRef: any;
  createUserData: any;
  dataVal: any = [];
  enableEdit = false;
  enableEditIndex = null;
  userData: any;
  constructor(private router: Router, private modalService: NgbModal, private activeModalService: NgbActiveModal, private service: AdminService ) { }

  ngOnInit() {
    this.service.listUsers().subscribe(data => {
      console.log(data)
      this.dataVal = data.items
      console.log(this.dataVal)


    },
      error => {
        console.log(error);
      }
    )
  }

  public addMaker($event) {
    this.modalRef = this.modalService.open(AddMakerModalComponent);
    this.tableCSs = true;


  }
  dismissModal() {
    this.activeModalService.close();
  }


  enableEditMethod(e, i) {
    this.enableEdit = true;
    this.enableEditIndex = i;
    console.log(i, e);
  }

  cancel() {
    console.log('cancel');
    this.enableEditIndex = null;
  }

//  get table data
  saveSegment(selectedItem: any) {
    this.enableEditIndex = null;
    console.log('selectedItem:',selectedItem)
    this.service.userUpdate(selectedItem).subscribe(data => {
      this.userData = (data);
      console.log(data)

      if ((this.userData.code === 200)) {
        console.log('200-Success');
        swal.fire({
          title: 'Success',
          text: this.userData.success,//'Data.success',//data.success,
          type: 'success',
          showCancelButton: false,
          confirmButtonColor: '#535BE2',
          cancelButtonColor: '#FF7E39',
          confirmButtonText: 'OK',
        }).then((confirm) => {
          if (confirm) {
            this.router.navigate(['/admin/addMaker']);
            window.location.reload();
          }
        });

      }

    },
      error => {
        // console.log('error', error.message);

        if (error.responseStatus === 401) {
          // console.log('inside if');
          swal.fire({
            title: 'Unsuccessful',
            text: error.message,
            type: 'error',
            showCancelButton: false,
            confirmButtonColor: '#535BE2',
            cancelButtonColor: '#FF7E39',
            confirmButtonText: 'OK',
          }).then((confirm) => {
            if (confirm) {
              this.router.navigate(['/admin/addMaker']);
              window.location.reload();
            }
          });
        } else if (error.responseStatus === 500) {
          swal.fire({
            title: 'Unsuccessful',
            text: error.message,
            type: 'error',
            showCancelButton: false,
            confirmButtonColor: '#535BE2',
            cancelButtonColor: '#FF7E39',
            confirmButtonText: 'OK',
          }).then((confirm) => {
            if (confirm) {
              this.router.navigate(['/admin/addMaker']);
              window.location.reload();
            }
          });
        } else if (error.responseStatus === 400) {
          swal.fire({
            title: 'Unsuccessful',
            text: error.message,
            type: 'error',
            showCancelButton: false,
            confirmButtonColor: '#535BE2',
            cancelButtonColor: '#FF7E39',
            confirmButtonText: 'OK',
          }).then((confirm) => {
            if (confirm) {
              this.router.navigate(['/admin/addMaker']);
              window.location.reload();
            }
          });
        }
      },
      () => console.log()
    );

  }
 
  // delete user
  delete(emailId) {
    console.log(emailId)
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: true
    })

    swalWithBootstrapButtons.fire({
      title: 'Are you sure to delete this user?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        this.service.deleteUser(emailId).subscribe(data => {
          this.userData = (data);
          console.log("Delete Data ::: ",data);
          console.log("User Data ::: ", this.userData)

          if ((this.userData.code === 200)) {
            console.log('200-Success');
            swal.fire({
              title: 'Success',
              text: this.userData.success,
              type: 'success',
              showCancelButton: false,
              confirmButtonColor: '#535BE2',
              cancelButtonColor: '#FF7E39',
              confirmButtonText: 'OK',
            }).then((confirm) => {
              if (confirm) {
                this.router.navigate(['/admin/addMaker']);
                window.location.reload();
              }
            });

          }

        },
          error => {
            // console.log('error', error.message);

            if (error.responseStatus === 401) {
              // console.log('inside if');
              swal.fire({
                title: 'Unsuccessful',
                text: error.message,
                type: 'error',
                showCancelButton: false,
                confirmButtonColor: '#535BE2',
                cancelButtonColor: '#FF7E39',
                confirmButtonText: 'OK',
              }).then((confirm) => {
                if (confirm) {
                  this.router.navigate(['/admin/addMaker']);
                  window.location.reload();
                }
              });
            } else if (error.responseStatus === 500) {
              swal.fire({
                title: 'Unsuccessful',
                text: error.message,
                type: 'error',
                showCancelButton: false,
                confirmButtonColor: '#535BE2',
                cancelButtonColor: '#FF7E39',
                confirmButtonText: 'OK',
              }).then((confirm) => {
                if (confirm) {
                  this.router.navigate(['/admin/addMaker']);
                  window.location.reload();
                }
              });
            } else if (error.responseStatus === 400) {
              swal.fire({
                title: 'Unsuccessful',
                text: error.message,
                type: 'error',
                showCancelButton: false,
                confirmButtonColor: '#535BE2',
                cancelButtonColor: '#FF7E39',
                confirmButtonText: 'OK',
              }).then((confirm) => {
                if (confirm) {
                  this.router.navigate(['/admin/addMaker']);
                  window.location.reload();
                }
              });
            }
          },
          () => console.log()
        );

      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swal.fire("Your user data safe!");
      }
    })



  }

}

