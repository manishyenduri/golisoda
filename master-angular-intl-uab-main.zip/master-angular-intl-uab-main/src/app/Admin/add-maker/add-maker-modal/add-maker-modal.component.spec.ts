import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMakerModalComponent } from './add-maker-modal.component';

describe('AddMakerModalComponent', () => {
  let component: AddMakerModalComponent;
  let fixture: ComponentFixture<AddMakerModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddMakerModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMakerModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
