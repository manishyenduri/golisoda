import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { con } from '../../admin-dashboard/country2';
import { AdminService } from '../../../services/admin/docs.service'
import { Router } from '@angular/router';
import { NgForm, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import swal from 'sweetalert2';
@Component({
  selector: 'app-add-maker-modal',
  templateUrl: './add-maker-modal.component.html',
  styleUrls: ['./add-maker-modal.component.css']
})
export class AddMakerModalComponent implements OnInit {
  tableCSs = false;
  @Output() createUserData = new EventEmitter();
  countrys: any = con;
  formDataValues: any;
  formDataValuesJson: any;
  modalRef: any;
  userRegisteration: any;
  rigisterForm: FormGroup;
  submitted = false;
  erroMsg: string;
  loading: boolean;
  disable: boolean = false;
  userData: any;
  dataVal: any;
  constructor(private modalService: NgbModal, private fb: FormBuilder, private service: AdminService,
    private activeModalService: NgbActiveModal,private router: Router) {
    this.rigisterForm = fb.group({
      'employeeName': [null, Validators.required],
      'employeeId': [null, Validators.required],
      'reporting_Authority': [null, Validators.required],
      'emailId': [null, Validators.required],
      'designation': [null, Validators.required],
      'roles': [null, Validators.required],
      'city': [null, Validators.required],
      'branch_Name': [null, Validators.required],
      'country': [null, Validators.required],
    });
  }
  get f() { return this.rigisterForm.controls; }
  ngOnInit() {
  }
  dismissModal() {
    this.activeModalService.close();
  }

  rigister(formdata:any) {
    this.submitted = true; 
   if (this.rigisterForm.invalid)
    {
      return
    }
    this.loading = true;
    console.log(formdata)
    this.service.userRegisteration(formdata).subscribe(data =>{
      console.log("Data Check: ",data)
    this.userData = (data);
    console.log("++++++++++++++++++++",this.userData.code)
          if ((this.userData.code === 200)) {
            this.loading = false;
            this.erroMsg = '';
            this.submitted = false;
            swal.fire({
              title: 'Success',
              text: this.userData.message,
              type: 'success',
              showCancelButton: false,
              confirmButtonColor: '#535BE2',
              cancelButtonColor: '#FF7E39',
              confirmButtonText: 'OK'
            }).then((confirm) => {
                  if (confirm) {
                    this.activeModalService.close();
                    window.location.reload();
                    this.router.navigate(['/admin/addMaker']);
                    window.location.reload();
                  }
                });
          }
        },
        error => {
          if (error.responseStatus === 401) {
            this.loading = false;
            this.erroMsg = error.message;
          } else if (error.responseStatus === 500) {
            this.loading = false;
            this.erroMsg = error.message;
          } else if (error.responseStatus === 400) { 
            this.loading = false;
            this.erroMsg = error.message; 
          }
        },
        () => console.log()
      );
    }
  }
