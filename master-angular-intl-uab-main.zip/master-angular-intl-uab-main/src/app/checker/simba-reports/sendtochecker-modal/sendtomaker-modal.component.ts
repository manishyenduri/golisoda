import { Component, OnInit } from '@angular/core';
import { NgbModal, NgbDropdown, NgbDropdownItem } from '@ng-bootstrap/ng-bootstrap';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
//import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';
import { CheckerService } from 'src/app/services/checker/docs.service';

@Component({
  selector: 'app-sendtomaker-modal',
  templateUrl: './sendtomaker-modal.component.html',
  styleUrls: ['./sendtomaker-modal.component.css']
})
export class SendtomakerModalComponent implements OnInit {
checkerList:any= [ 
{ id:'1',number:'C0001' },
{ id:'2',number:'C0002' },
{ id:'3',number:'C0003' },
{ id:'4',number:'C0004'}
];
  makerId:any="";
  comments: any;
  requestId:any;
  response:any;
  trans_status:any="";
  temp:any;
  makerLists:any;
  constructor(private _httpService: CheckerService,private modalService: NgbModal,private activeModalService: NgbActiveModal) { }

  ngOnInit() {
      this._httpService.makerList().subscribe(res=>{
       this.temp=(res);// console.log("resresresresresresresresresresresres",res)
      this.makerLists=this.temp.data;
      console.log("resresresresresres",res)
      })
  }
  dismissModal() {
    this.activeModalService.close();
  }
  sendChecker(){
  
   console.log(this.makerId);
   this.requestId = localStorage.getItem('id');
   console.log(this.requestId);
   console.log(this.comments)
   console.log(this.trans_status)

    this._httpService.sendToMaker(this.makerId, this.comments, this.requestId,this.trans_status)
    .subscribe(r=>
      {
       // var res = (r)
       this.response = (r);
        console.log("PassedToMaker : ",this.response.code)
        if(this.response.code === 200)
        {
          this.dismissModal();
          Swal.fire(
            'Successful',
            'Sent to Maker',
            'success'
          )
        }
        else
        if(this.response.code === 500)
        {
          Swal.fire(
            'Sorry!',
            'Sending Failed',
            'error'
          )
        }
       // if(r)
      });
    
  }
   
   
}
