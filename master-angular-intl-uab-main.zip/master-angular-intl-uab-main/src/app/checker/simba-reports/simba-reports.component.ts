import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CheckerService } from 'src/app/services/checker/docs.service';
import { MakerService } from 'src/app/services/maker/docs.service';
import Swal from 'sweetalert2';
import { SendtomakerModalComponent } from './sendtochecker-modal/sendtomaker-modal.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { InitiateApprovalModalComponent } from '../initiate_approval/sendtochecker-modal/sendtomaker-modal.component';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-simba-reports',
  templateUrl: './simba-reports.component.html',
  styleUrls: ['./simba-reports.component.css']
})
export class SimbaReportsComponent implements OnInit {

  exchangeResponse:any;
  docsResponse:any;
  articleResponse:any;
  article_Msg:any;
  id:any;
  dataValue:any;
  exchangeResponse_2:any;
  modalRef:any;
  tempArry:any;
  searchData:any;
  CompResponse:any;
  docDate: any;
  docAnalysis: any;
  pdfOBj:any;
  articleStack=[];
  bag=[];
  logoPic:SafeResourceUrl;


  constructor(private _httpService:CheckerService, private service:MakerService,private sanitizer:DomSanitizer, private modalService: NgbModal,
    private router: Router) { 
   }

  ngOnInit() {
    this.id=localStorage.getItem('id');
    this.transactionStatus();
    this.DocsData();
  
    this.getBase64();
    this._httpService.docsData(this.id).subscribe(
      data => {
        this.CompResponse = (data)
        this.docDate = this.CompResponse.data[0].date;
        this.docAnalysis = this.CompResponse.data[1];
        console.log('table view', this.CompResponse)
          var j=0;
         for(var i=0;i<this.CompResponse.data[1].length;i++)
         {
            // if()  
              this.articleStack[j] = this.CompResponse.data[1];
         }

         j=0;
         for(var i=0;i<this.articleStack.length;i++){
              this.bag[j] = this.articleStack[i].article;
         }
         console.log("articleStackarticleStackarticleStack",this.bag);
      },
      error => {
        console.log(error)
      });

    function openCity(evt, cityName) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }
    
    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
  }
  backTo() {
    this.router.navigate(['checker/simba-reports-list'])
 }

 DocsData(){
   
   this._httpService.docsData(this.id)
   .subscribe(res=>{
    this.exchangeResponse = (res);
    this.docsResponse = this.exchangeResponse.data[1];
   });
 }

 ClickMe(a_name) {
  console.log(a_name)
  const article_Id = a_name
  this.service.getArticleId(article_Id).subscribe(
    res => {
      this.articleResponse = (res)
      this.article_Msg = this.articleResponse.data;
      console.log('Msg view', this.article_Msg);
      Swal.fire({
        title: article_Id,
        text: this.articleResponse.data,
        // imageUrl: 'https://unsplash.it/400/200',
        imageWidth: 400,
        imageHeight: 200,
        imageAlt: 'Custom image',
      })
    },
    error => {
      console.log(error)
    },
    () => console.log('created Article'));

  //Alert(this.article_Msg);
  }

  transactionStatus(){
    this._httpService.transcationStatus(this.id)
    .subscribe(res=>{ 
      this.exchangeResponse_2 =(res);
      this.dataValue = this.exchangeResponse_2.data;
      this.tempArry=[];
      var j=0;
      for(var i=1;i<this.dataValue.length;i++){
        if(this.dataValue[i].compliance!=0 && this.dataValue[i].discrepant!=0 )
        {
          this.tempArry[j]=this.dataValue[i];
          j++;
        }
      }
      this.dataValue=this.tempArry;
    })
  }

  sendtomaker($event){
    this.modalRef = this.modalService.open(SendtomakerModalComponent);
  }
  initiateApproval($event){
    this.modalRef = this.modalService.open(InitiateApprovalModalComponent);
  }
  
  getBase64(){
    const reader = new FileReader();
    this.logoPic=this.sanitizer.bypassSecurityTrustResourceUrl('assets/images/simplyfi-logo.png');
    // reader.readAsDataURL(this.logoPic);
    // this.logoPic = reader.result as string;
  }

  async downloadPDFMake(){
    // this.router.navigate(['maker/ai-reports']);
    // var data = document.getElementById("content");
    // html2canvas(data).then(canvas=>{
  
    //   var imgWidth = 200;
    //   var pageHeight = 295;
    //   var imgHeight =canvas.height * imgWidth / canvas.width;
    //   var heightleft = imgHeight;
  
    //   const contentDataURL = canvas.toDataURL('image/png')
    //   let pdf = new jspdf('p','mm','a4');
    //   var position=0;
    //   pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);
    //   pdf.save('Report.pdf');
  
    // }) 
    const documentDefinition = { 
      watermark:{text:'CONFIDENTIAL', fontSize:30, angle:330, opacity: 0.1, bold: true, italics: false},
      footer:{text:'All Rights Reserved by SimplyFI Softech India Private Limited © 2020 .',alignment:'center'},
      content: [
        {
          image:await this.getBase64ImageFromURL('assets/images/simplyfi-logo.png'),
          width:100,
          alignment:'right'
        },
        {
          image:await this.getBase64ImageFromURL('assets/images/simba_pngblack.png'),
          width:120,
          alignment:'center'
        },
        // {
        //   columns:[
        //     [{
        //       image:this.ImgUrl,
        //       width:50,
        //       alignment:'right'
        //     }]
        //   ]
         
        // },
        
        {
          text: 'AI - COMPLIANCE REPORT',
          bold:true,
          fontSize:20,
          alignment: 'center',
          margin: [0,0,0,20],
          fonts:'Times'
          // style: 'header'
        },
        {
          columns: [
            [{
              text: 'Report Ref. ID :'+localStorage.getItem('id'),
            },
            {
              text: 'Report Generated By : SIMBA'
            }
            ],
            [
              {
                text: 'Report Date : '+(new Date(this.CompResponse.data[0].date)).getDate()+"-"+(new Date(this.CompResponse.data[0].date)).getMonth()+"-"+(new Date(this.CompResponse.data[0].date)).getFullYear(),
                alignment:'right'
              },
              {
                text: 'Report Time : '+(new Date(this.CompResponse.data[0].date)).getHours()+":"+(new Date(this.CompResponse.data[0].date)).getMinutes(),
                alignment:'right'
              }
            ]
          ]
        },
        
        {
          text: 'ADDRESS NAME AND ADDRESS',
          fontSize:14,
          margin:[0,25,0,0],
          alignment: 'left',
          bold:true,
          style: 'header'
        },
        {
          columns: [
            [{
              margin:[0,15,0,0],
              text: 'Applicant Name'
            },
            {
              text: 'Applicant Address'
            }
            ]
          ]
        },
        {
          text: 'BENEFICIARY NAME AND ADDRESSA',
          fontSize:14,
          margin:[0,15,0,0],
          alignment: 'left',
          bold:true,
          style: 'header'
        },
        {
          margin:[0,15,0,0],
          text:"MCT Tile PVT. LTD."
        },
        {
          margin:[0,0,0,15],
          text:"Bangalore, Karnataka"
        },
        {
          text: 'LETTER OF CREDIT DETAILS',
          fontSize:14,
          margin:[0,0,0,0],
          alignment: 'left',
          bold:true,
          style: 'header'
        },
        {
          columns: [
            [{
              margin:[0,15,0,0],
              text: 'Applicant Name'
            },
            {
              text: 'Applicant Address'
            }
            ]
          ]
        },
        {
          text: 'DOCUMENTS CHECKED BY SIMBA',
          fontSize:14,
          margin:[0,25,0,0],
          alignment: 'left',
          bold:true,
          style: 'header'
        },
        {
          columns: [
            [{
              margin:[0,15,0,0],
              text: 'Applicant Name'
            },
            {
              text: 'Applicant Address'
            }
            ]
          ]
        },
        {
          text: 'TRADE DOCUMENTS COMPLIANCE OVERVIEW',
          fontSize:14,
          margin:[0,25,0,15],
          alignment: 'left',
          bold:true,
          style: 'header'
        },
        {
          table: {
            widths: [100,100,120,90,60],
            margin:[0,0,0,20],
            alignment: 'center',
            body: [
              [{
                text: 'Article',
                style: 'tableHeader',
                bold:true,
                fillColor:'#88A9AA'
              },
              {
                text: 'Rule',
                style: 'tableHeader',
                bold:true,
                fillColor:'#88A9AA'
              },
              {
                text: 'Description',
                style: 'tableHeader',
                bold:true,
                fillColor:'#88A9AA'
              },
              {
                text: 'Status',
                style: 'tableHeader',
                bold:true,
                fillColor:'#88A9AA'
              },
              {
                text: 'Accuracy',
                style: 'tableHeader',
                bold:true,
                alignment: 'center',
                fillColor:'#88A9AA'
              }
              ],
              ...this.CompResponse.data[1].map(ed=>{
                return [
                  {text:this.articleText(ed.article),fillColor:'#D9F2F2'},
                  {text:this.ruleText(ed.rule),fillColor:'#D9F2F2'},
                  {text:this.accText(ed.description),fillColor:'#D9F2F2'},
                  {text:this.compareStatus(ed.status),fillColor:this.fillBackGround(ed.status),color:'#fff'},
                  {text:ed.accuracy, alignment: 'center',fillColor:'#D9F2F2'}]
              })
            ]
          }
        },
        {
          text: 'RECOMMENDATIONS FROM SIMBA',
          fontSize:14,
          margin:[0,20,0,15],
          alignment: 'left',
          style: 'header'
        },
        {
          text:"Repeated discrepancies observed in the invoice. Regular mismatch of applicant's name is noticed. In the last couple of months, 5 transactions of same amount pertaining to MCI Tiles Pvt. Ltd. were handled."
        },
        {
          text: 'DISCLAMER',
          fontSize:14,
          margin:[0,5,0,15],
          alignment: 'left',
          style: 'header'
        },
        {
          text:'This report is confidential and is intended for viewing by the authorized trade finance officers of the bank only. It should not be disclosed  to the  third parties. All the  ratings, recommendations provided in  this report are  given by SIMBA an  AI  engine, and so the information should not be used as  the  sole  basis  for  any  decision.  Further  it  is  the responsibility  of the trade finance officer to ensure double check before taking a final decision based on the AI report.',
        }
      ],
      styles: {
        tableHeader:{
          fontSize:13
        },
        header:{
          decoration: 'underline'
        },
        name: {
          fontSize: 12,
          bold: true
        }
      }
    };
    this.pdfOBj = pdfMake.createPdf(documentDefinition);
    this.pdfOBj.download();
  }
  
  
getBase64ImageFromURL(url) {
  return new Promise((resolve, reject) => {
    var img = new Image();
    img.setAttribute("crossOrigin", "anonymous");

    img.onload = () => {
      var canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;

      var ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0);

      var dataURL = canvas.toDataURL("image/png");

      resolve(dataURL);
    };

    img.onerror = error => {
      reject(error);
    };

    img.src = url;
  });
}

fillBackGround(status){
  if(status==='compliant'){
    return '#28B463';
  }else{
    return '#F0412F';
  }
}
compareStatus(filterData){
  if(filterData==='compliant'){
    return 'Compliant';
  }else{
    return 'Discrepant';
  }
}

ruleText(filterData){
  if(filterData.slice(0,3)==='inv'){
    return 'Invoice';
  }else
  if(filterData.slice(0,3)==='boe')
  {
    return 'Bill of Exchange';
  }
  if(filterData.slice(0,3)==='com')
  {
    return 'Commercial Invoice';
  }
  if(filterData.slice(0,3)==='awb')
  {
    return 'Air Way Bill';
  }
  if(filterData.slice(0,3)==='bol'){
    return 'Bill of Lading';
  }
  if(filterData.slice(0,3)==='coo'){
    return 'Certificate of Origin';
  }
  if(filterData.slice(0,3)==='ins'){
    return 'Insurance';
  }
  if(filterData.slice(0,3)==='soo'){
    return 'Statement of Origin';
  }
  if(filterData.slice(0,3)==='ben'){
    return 'Beneficiary';
  }
  if(filterData.slice(0,3)==='swb'){
    return 'Sea Way Bill';
  }else{
    return filterData;
  }
  
}

articleText(filterData){
  return filterData.replace(/_/g,'-');
}

accText(filterData){
  const filter = filterData.replace(/_/g,' ');
  return filter.replace(/\w\S*/g, function(txt){
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
});
}
}
