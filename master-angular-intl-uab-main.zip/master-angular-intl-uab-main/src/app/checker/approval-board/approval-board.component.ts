import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-approval-board',
  templateUrl: './approval-board.component.html',
  styleUrls: ['./approval-board.component.css']
})
export class ApprovalBoardComponent implements OnInit {
 // approvalList: Array<any> = [
   searchData:any;
   dummyData:any =[ { TransactionId:'KBSMTHOQ0X', indate:'09/11/2019', apdate:'10/11/2019', status:'Rejected' },
    { TransactionId:'KBSMTHOQ0X', indate:'19/11/2019', apdate:'19/11/2019', status:'Approved' },
    { TransactionId:'KBSMTHOQ0X', indate:'23/11/2019', apdate:'24/11/2019', status:'Approved' },
    { TransactionId:'KBSMTHOQ0X', indate:'29/11/2019', apdate:'30/11/2019', status:'Approved' },
    { TransactionId:'KBSMTHOQ0X', indate:'01/12/2019', apdate:'2/12/2019', status:'Pending' },
    { TransactionId:'KBSMTHOQ0X', indate:'19/12/2019', apdate:'19/12/2019', status:'Rejected' },
    { TransactionId:'KBSMTHOQ0X', indate:'29/12/2019', apdate:'29/12/2019', status:'Rejected' }
  ];
  constructor() { } 

  ngOnInit() {
    
    
  }
  

}
