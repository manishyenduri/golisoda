import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { C4DashboardCheckerComponent } from './c4-dashboard-checker.component';

describe('C4DashboardCheckerComponent', () => {
  let component: C4DashboardCheckerComponent;
  let fixture: ComponentFixture<C4DashboardCheckerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ C4DashboardCheckerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(C4DashboardCheckerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
