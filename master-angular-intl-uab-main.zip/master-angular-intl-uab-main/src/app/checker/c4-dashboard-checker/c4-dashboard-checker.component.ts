import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MakerService } from 'src/app/services/maker/docs.service';
import * as c3 from 'c3';
import { CheckerService } from 'src/app/services/checker/docs.service';


@Component({
  selector: 'app-c4-dashboard-checker',
  templateUrl: './c4-dashboard-checker.component.html',
  styleUrls: ['./c4-dashboard-checker.component.css']
})
export class C4DashboardCheckerComponent implements OnInit {

 
  
  complianceCheckPercent:any;
  exchangeCompliance:any;
  comp:any;
  descp:any;
  typesOfDoc:any;
  DocumentCompliance:any;
  docBar:boolean;
  rulesData:any;
  chartDataOfDocs:any;
  dataValue:any;
  listOfRules:any;
  com:any;
  dispID:any;
  exchangeDashboard:any;

  
  applicantName:any;
  tradeAmount:any;

  countClassified:any;
  countUnclassified:any;
  countScreended:any;
  totalNouns:any;
  matchedNouns:any;
  unmatchedNouns:any;
totalRules:any;
complaintRules:any;
discrepantRule:any;
nounsPer:any;
  constructor(private router:Router, private _httpService:CheckerService) { }

  ngOnInit() {
    this.nounsPer=0;
    this.unmatchedNouns=0;
    this.chartDataOfDocs=[];
    this.complianceCheckPercent=0;
    this.docBar=true;
    this.typesOfDoc=0;
    this.DocumentCompliance=0;
    this.dispID=localStorage.getItem('id');
    //4c Dashboard API
    this._httpService.c4_DashboardAPI(localStorage.getItem('id')).subscribe(r=>
     { console.log("R==> ",r)
     this.exchangeDashboard=(r);
     console.log("hhh --> ",this.exchangeDashboard)
     this.applicantName=this.exchangeDashboard.data.applicantName;
     this.tradeAmount=this.exchangeDashboard.data.amount;
     this.countClassified=this.exchangeDashboard.data.classification_data.classifed_docs;
     this.countUnclassified=this.exchangeDashboard.data.classification_data.un_classified_docs;
     this.countScreended=this.exchangeDashboard.data.classification_data.screned_documents_count;
     this.totalNouns=this.exchangeDashboard.data.consistancy_data.total_nouns;
     this.matchedNouns=this.exchangeDashboard.data.consistancy_data.actual_nouns_matched;
     this.unmatchedNouns=this.totalNouns-this.matchedNouns;
    this.totalRules=this.exchangeDashboard.data.rules_data.total_no_rules;
    this.complaintRules=this.exchangeDashboard.data.rules_data.matched_rules;
    this.discrepantRule=this.totalRules-this.complaintRules;
    this.nounsPer=Math.round((this.matchedNouns/this.totalNouns)*100);
      document.getElementById("nounsID").style.width=this.nounsPer+'%';
    console.log("countClassified -- ",this.countClassified);
    });

    //Graph Analysis
    this._httpService.docsData(localStorage.getItem('id')).subscribe(r=>{
      console.log("feteched",r)
      this.exchangeCompliance=(r);
      var total = this.exchangeCompliance.data[1].length;
      var data=this.exchangeCompliance.data[1];
      console.log("data-> ",data)
      this.descp=0;
      this.comp=0;
      var tempRule='';
      var accuracyValue=0;
      var totalAccuracy = total*100;
      for(var i=0;i<total;i++){
        if(data[i].status==='compliant'){
          this.comp++;
        }else{
          this.descp++;
        }
        var Rule=this.ruleText(data[i].rule);
        console.log("----> ",Rule)
        if( Rule!=tempRule){
          tempRule=Rule;
          this.typesOfDoc++;
          
          var val=0;
          var perc=0;
          for(var j=0;j<total;j++){
            var k=this.ruleText(data[j].rule)
            if(k===Rule){
              val=val+data[j].accuracy;
              perc=perc+1;
            }
          }
          this.chartDataOfDocs.push([Rule, Math.round((val/(perc*100))*100)])
        }

        accuracyValue=accuracyValue+data[i].accuracy;
      }
      this.ad()

      
      this.complianceCheckPercent=Math.round((this.comp/total)*100);
      this.doughnut(this.complianceCheckPercent);
      this.rule();
      if(this.complianceCheckPercent<50)
      {
        document.getElementById('compLin').style.display="block"; 
        document.getElementById('compLin').style.width=this.complianceCheckPercent+'%';
      }
      else{
        document.getElementById('compLin2').style.background="block";
        document.getElementById('compLin2').style.width=this.complianceCheckPercent+'%';
      }
     
      
      this.DocumentCompliance=Math.round((accuracyValue/totalAccuracy)*100);
      if(this.DocumentCompliance<50){
        document.getElementById('acc').style.display="block";
        document.getElementById('acc').style.width=this.DocumentCompliance+'%';
      }
      else{
        console.log("kjhvgh")
        document.getElementById('acc2').style.background="block";
        document.getElementById('acc2').style.width=this.DocumentCompliance+'%';
      }
      
    
    })
  }
  rule(){
    this._httpService.getRequestById().subscribe(
      data => {
        console.log("Check Data",data);
          this.rulesData = (data);
          const dataVal = this.rulesData.data;
          this.dataValue = data
          console.log('dataVal', dataVal);
          this.listOfRules = dataVal.inv.length;
          this.com=dataVal.com.length;
          for(var i=0;i<this.listOfRules;i++){
            if(dataVal.inv[i].description==="amount")
            {
              console.log("Working")
              // this._httpService.getRuleById(id,dataVal.inv[i].rule_id).
              // subscribe((r)=>{})
 
              // dataVal.inv[i].rule_id
            }
          }
        } ,
        error => {
            console.log(error);
          },
        () => console.log('created employee', this.rulesData));
  }
  dataArray(){
    // this.chartDataOfDocs
    // var arr=[];
    // for(var i=0;i<this.chartDataOfDocs.length;i++){
    //   arr.push([this.chartDataOfDocs[i].title,this.chartDataOfDocs[i].accuracy])
    // }
    // console.log("y-> ",arr)
    // return arr;
  }

  ad(){
    console.log(" this.chartDataOfDocs - ", this.chartDataOfDocs)
    const chart = c3.generate({
      bindto: '#visitor',
      data: {
        columns: this.chartDataOfDocs,
  
        type: 'bar'
      },
      // donut: {
      //   label: {
      //     show: false
      //   },
      //   title: 'Trade Documents',
      //   width: 25
      // },
  
      // legend: {
        // hide: true
        // or hide: 'data1'
        // or hide: ['data1', 'data2']
      // },
      color: {
        pattern: ['#b391fa','#9de6fa','#ffffb2', '#B5F6D9', '#ffaa8b', '#ffd0e4']
      }
    });
  }

  doughnut(data){
    console.log('datadatadata -',data)
    const chart = c3.generate({
      bindto: '#visitor4',
      data: {
        columns:[["Discripant",100-data],["Compliant",data]] ,

        type: 'donut'
      },
      donut: {
        label: {
          show: false
        },
        title: 'Overall Compliance',
        width: 25
      },
  
      // legend: {
        // hide: true
        // or hide: 'data1'
        // or hide: ['data1', 'data2']
      // },
      color: {
        pattern: ['#f08787','#5cd8b9']
      }
    });
  }
  
  
ruleText(filterData){
  if(filterData.slice(0,3)==='inv'){
    console.log('dd')
    return 'Invoice';
  }else
  if(filterData.slice(0,3)==='boe')
  {
    return 'Bill of Exchange';
  }
  if(filterData.slice(0,3)==='com')
  {
    return 'Commercial Invoice';
  }
  if(filterData.slice(0,3)==='awb')
  {
    return 'Air Way Bill';
  }
  if(filterData.slice(0,3)==='bol'){
    return 'Bill of Lading';
  }
  if(filterData.slice(0,3)==='coo'){
    return 'Certificate of Origin';
  }
  if(filterData.slice(0,3)==='ins'){
    return 'Insurance';
  }
  if(filterData.slice(0,3)==='soo'){
    return 'Statement of Origin';
  }
  if(filterData.slice(0,3)==='ben'){
    return 'Beneficiary';
  }
  if(filterData.slice(0,3)==='swb'){
    return 'Sea Way Bill';
  }else 
  if(filterData.slice(0,2)==='pl'){
    return 'Packing List';
  }else{
    return filterData;
  }
  
}

  navigator(data){
    if(data==='')
    return
    else
    this.router.navigate([data])
  }

}
