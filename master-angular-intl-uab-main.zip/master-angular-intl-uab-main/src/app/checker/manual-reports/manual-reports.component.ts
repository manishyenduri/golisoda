import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SendtomakerModalComponent } from '../simba-reports/sendtochecker-modal/sendtomaker-modal.component';
import { CheckerService } from 'src/app/services/checker/docs.service';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';
import { AuthService } from 'src/app/services/auth.service';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2';
import { InitiateApprovalModalComponent } from '../initiate_approval/sendtochecker-modal/sendtomaker-modal.component';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-manual-reports',
  templateUrl: './manual-reports.component.html',
  styleUrls: ['./manual-reports.component.css']
})
export class ManualReportsComponent implements OnInit {


  modalRef:any;
  id:any;
  exchangeResponse:any;
  dataResponse:any;
  exchangeHSN:any;
  exchangeOfac:any;

  statusSent:any="";
  CompNoteResponse:any;
  CompliantRemarks:any="";
  rulesData: any;
  ruleItems: any;
  listOfRules: any;
  tokenInfo: any;
  request_id: any;
  listOfSegregatedRules: any;
  requestResponse: any;
  accuracy: any;
  leftRuleImg: SafeResourceUrl;
  rightRuleImg: SafeResourceUrl;
  leftImage: any;
  rightImage: any;
  rule_id: any;
  ruleExists: boolean = false;
  leftTitle: any;
  rightTitle: any;
  rule: any;
  firstRuleId: any;
  FirstruleExists: boolean = false;
  nextRule: boolean = false;
  dropdown: boolean = false;
  cardRules: boolean = false;
  public counter: number = 1;
  public currentItem: any;
  rule_name: any;
  selectedRow: any;
  closeResult: string;
  boe: any;
  bol: any;
  dataValue: any = [];
  insurance: any;
  coo: any;
  awb: any;
  swb:any;
  ofacVariable:any;
  ofacMessage:any;
  ofacStatus:any;

  
  com:any;
  soo:any;
  ben:any;

  
  img_arry_inv:any;
  img_arry_boe:any;
  img_arry_awb:any;
  img_arry_coo:any;
  lc_arry_coo:any;
  lc_arry_boe:any;
  lc_arry_awb:any;
  img_arry_ins:any;
  lc_arry_ins:any;

  right_hand_img_set:any;
  left_hand_img_set:any;
  lc_img_inv:any;
  HSNBoolean:boolean;

  constructor( private modalService:NgbModal, private _httpService:CheckerService,
    private spinner: NgxSpinnerService,  private router: Router, public sanitizer: DomSanitizer, private authservice: AuthService) { 
   }

  ngOnInit() {

    this.img_arry_inv=['../../../assets/img-doc/invoice/invoice_1_annotated_full.png','../../../assets/img-doc/invoice/invoice_2_annotated_full.png', '../../../assets/img-doc/invoice/invoice_3_annotated_full.png', '../../../assets/img-doc/invoice/invoice_4_annotated_full.png'];
    this.lc_img_inv=['../../../assets/img-doc/Letter_Of_Credit/invoice_1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/invoice_2_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/invoice_3_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/invoice_4_annotated_full.png'];
    
    this.img_arry_boe=['../../../assets/img-doc/bill_of_exchange/boe_1_annotated_full.png','../../../assets/img-doc/bill_of_exchange/1.png'];
    this.lc_arry_boe=['../../../assets/img-doc/Letter_Of_Credit/boe_1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/boe_1_annotated_full.png'];
  
    this.img_arry_awb=['../../../assets/img-doc/airway_bill/awb_1_annotated_full.png','../../../assets/img-doc/airway_bill/awb_3_annotated_full.png'];
    this.lc_arry_awb=['../../../assets/img-doc/Letter_Of_Credit/awb_1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/awb_3_annotated_full.png'];
  
    this.img_arry_ins=['../../../assets/img-doc/insurance/ins1_annotated_full.png','../../../assets/img-doc/insurance/ins2_annotated_full.png','../../../assets/img-doc/insurance/1.png','../../../assets/img-doc/insurance/1.png'];
    this.lc_arry_ins=['../../../assets/img-doc/Letter_Of_Credit/ins1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/ins2_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/ins3_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/ins4_annotated_full.png'];
  
    this.img_arry_coo=['../../../assets/img-doc/certificate_of_origin/coo1_annotated_full.png','../../../assets/img-doc/certificate_of_origin/coo2_annotated_full.png','../../../assets/img-doc/certificate_of_origin/coo3_annotated_full.png','../../../assets/img-doc/certificate_of_origin/coo4_annotated_full.png'];
    this.lc_arry_coo=['../../../assets/img-doc/Letter_Of_Credit/coo1_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/coo2_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/coo3_annotated_full.png','../../../assets/img-doc/Letter_Of_Credit/coo4_annotated_full.png'];
    this.right_hand_img_set=[];

    this.id=localStorage.getItem('id');
    this.rules();
    this.HSNBoolean=false;
    this.ofacVariable="";
    this.ofacMessage="Pending";
    this.ofacStatus="Pending";
    this.request_id=this.id;
    this._httpService.getHSN_data().subscribe(r=>{
  
      this.exchangeHSN=(r);
      console.log("Data - ",this.exchangeHSN.data[0].hsn_code)
    })
    // this._httpService.manualCardsDocs(this.id).subscribe(res=>{
    //   this.exchangeResponse= (res);
    //   this.dataResponse = this.exchangeResponse.data;
    //   console.log(this.dataResponse);
    // });
  }

  rules() {
    this._httpService.manualCardsDocs(this.id).subscribe(
        data => {
          console.log("Check DataCheckCheckCheckCheckCheckCheckCheck",data);
            this.rulesData = (data);
            const dataVal = this.rulesData.data;
            this.dataValue = data
            this.ruleItems = this.rulesData.data;
            console.log(dataVal.length);
            console.log('dataValdataValdataValdataValdataVal', dataVal);
            this.listOfRules = dataVal.inv.length;
            this.boe = dataVal.boe.length
            this.bol =dataVal.bol.length
            this.awb = dataVal.awb.length;
            this.coo = dataVal.coo.length
            this.swb=dataVal.swb.length;
            this.insurance =dataVal.ins.length
            this.soo=dataVal.soo.length;
            this.ben=dataVal.ben.length;
            this.com=dataVal.com.length;
            console.log( this.listOfRules);
          } ,
          error => {
              console.log(error);
              this.handleError(error);
            },
          () => console.log('created employee', this.rulesData));
  }

  onCard(selectedItem: any,i: any) {
    console.log('onCard',selectedItem);
    this.selectedRow = i;
    this.spinner.show();
     console.log(selectedItem.rule_id);
     const request_id = this.request_id;
     this.rule_id = selectedItem.rule_id;
     // var index = this.allRules.indexOf(this.rule_id);
     // console.log('index', index);
     // this.counter = index + 1;
     this._httpService.getRuleById(request_id,this.rule_id).subscribe(
         data => {
          
             this.requestResponse = (data);
            //  if(this.requestResponse.responseStatus === 200)
              {
                 this.spinner.hide();
                 this.ruleExists = true;
             const dataVal = this.requestResponse.data;
             for (const item of dataVal) {
                   this.accuracy = item.accuracy;
                   console.log('accuracy', this.accuracy);
                   const image = item.sentence;
                   console.log('left', image[0].annotated_image_full);
                   console.log('right', image[1].annotated_image_full);
                   this.leftTitle = image[0].word_set;
                   this.rightTitle = image[1].word_set;
                   var mapWithLeft = item.sentence[0].missing_words_1;
                   var mapWithRight = item.sentence[1].missing_words_2;
                   var leftCoordinates =  item.sentence[0].missing_indices1;
                   var rightCoordinates = item.sentence[1].missing_indices2;
                   this.Highlight(this.leftTitle,this.rightTitle,mapWithLeft,mapWithRight,leftCoordinates,rightCoordinates);
                   this.leftImage = /*'http://139.59.3.158:8990'*/ environment.imageEndPointApi + image[0].annotated_image_full;
                   this.rightImage = /*'http://139.59.3.158:8990'*/ environment.imageEndPointApi+ image[1].annotated_image_full;
                   this.leftRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.leftImage);
                   this.rightRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.rightImage);
                 }
                 console.log("this.rightRuleImg", "||" ,this.rightRuleImg) ,"this.leftRuleImg", "||" ,this.leftRuleImg
             }
             } ,
         error => {
             console.log(error);
             // this.handleError(error);
           },
         () => console.log('created employee', this.requestResponse)
       );
   }
  handleError(error) {
    console.log('error', error.responseStatus);
    console.log('status code', error.msg);
    if (error.responseStatus === 401) {
        this.authservice.refresh().subscribe(
            data => {
                this.tokenInfo = (data);
                const dataVal = this.tokenInfo;
                if(this.tokenInfo.responseStatus === 200) {
                    localStorage.setItem('access_token', this.tokenInfo.access_token);
                    this.rules();
                }
                } ,
            error => {
                console.log(error);
                this.handleError(error);
              },
            () => console.log('created employee', this.tokenInfo));
    }   
  }

  openOfacFunc(content, data){
    console.log("Data -- ",data)
    this.modalService.open(content, { size: 'lg', backdrop: 'static' }).result.then(
      result => {
        this.closeResult = `Closed with: ${result}`;
      },
      reason => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  
    this.ofacVariable=data;
  }

  proceedOfac(){
    this._httpService.ofacVerification(localStorage.getItem('id'),this.ofacVariable).subscribe(r=>{
      console.log('xsdsdssxx ',r)
      this.exchangeOfac=(r);
      this.ofacMessage=this.exchangeOfac.data.message;
      this.ofacStatus=this.exchangeOfac.data.status;
      console.log('OFAC 1 -- ',this.ofacMessage, this.ofacStatus)
    })
  }
  
clearOfac(){
  this.ofacMessage="Pending";
  this.ofacStatus="Pending";
}
  noteToChecker()
  {
    
    //console.log(this.CompliantRemarks)
    //console.log("localStorage.getItem('id')",localStorage.getItem('id'),this.CompliantRemarks,localStorage.getItem('id'),this.rule_id, this.statusSent)
    this._httpService.manualNoteToMaker(this.CompliantRemarks,localStorage.getItem('id'),this.rule_id, this.statusSent)
    .subscribe(res=>{
      this.CompNoteResponse = (res);
      console.log("CompNoteResponseCompNoteResponseCompNoteResponseCompNoteResponse",this.CompNoteResponse)
      if(this.CompNoteResponse.code === 200)
      {
        
        Swal.fire(
          'Successful',
          'Updated',
          'success'
        )
      }
        else
        if(this.CompNoteResponse.code === 500)
          Swal.fire(
            'Oops!',
            'Internal Server Error',
            'error'
          )
      }
    )
    this.clearVariables();
 // console.log("33333333333333333333333333333",this.rule_id)
  }
  
  backTo() {
    this.router.navigate(['checker/manual-reports-list'])
 }
 checkerSummery(){
  this.router.navigate(['checker/checker-summary'])
}
sendtomaker($event){
  this.modalRef = this.modalService.open(SendtomakerModalComponent);
}

initiateApproval($event){
  this.modalRef = this.modalService.open(InitiateApprovalModalComponent);
}
makerHSN(){
  this.cardRules = false;
   this.HSNBoolean = true;
 }
getInvoice() {
  console.log('on invoice', this.dataValue.data.inv);
  this.listOfSegregatedRules = this.dataValue.data.inv;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean=false;
  this.left_hand_img_set=this.lc_img_inv;
  this.right_hand_img_set=this.img_arry_inv;
 }
 
 getBOE() {
   console.log('on BOE', this.dataValue.data.boe);
   this.listOfSegregatedRules = this.dataValue.data.boe;
   this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
   this.firstRuleDetails(this.firstRuleId);
   this.dropdown = true;
   this.counter = 1;
   this.cardRules = true;
   this.HSNBoolean=false;
   this.left_hand_img_set=this.lc_arry_boe;
   this.right_hand_img_set=this.img_arry_boe;
 }
 
 getTRD() {
   console.log('on bol', this.dataValue.data.bol);
   this.listOfSegregatedRules = this.dataValue.data.bol;
   this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
   this.dropdown = true;
   this.counter = 1;
   this.cardRules = true;
   this.HSNBoolean=false;
 }
 getAwl() {
   console.log('on air way bill', this.dataValue.data.awb);
   this.listOfSegregatedRules = this.dataValue.data.awb;
   this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
   this.firstRuleDetails(this.firstRuleId);
   this.dropdown = true;
   this.counter = 1;
   this.cardRules = true;
   this.HSNBoolean=false;
   this.left_hand_img_set=this.lc_arry_awb;
   this.right_hand_img_set=this.img_arry_awb;
  }
  getCo() {
   console.log('on invoice', this.dataValue.data.coo);
   this.listOfSegregatedRules = this.dataValue.data.coo;
   this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
   this.firstRuleDetails(this.firstRuleId);
   this.dropdown = true;
   this.counter = 1;
   this.cardRules = true;
   this.HSNBoolean=false;
   this.left_hand_img_set=this.lc_arry_coo;
   this.right_hand_img_set=this.img_arry_coo;
  }
  getInsurance() {
   console.log('on invoice', this.dataValue.data.ins);
   this.listOfSegregatedRules = this.dataValue.data.ins;
   this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
   this.firstRuleDetails(this.firstRuleId);
   this.dropdown = true;
   this.counter = 1;
   this.cardRules = true;
   this.HSNBoolean=false;
   
  this.left_hand_img_set=this.lc_arry_ins;
  this.right_hand_img_set=this.img_arry_ins;
  }

  getswb() {
    console.log('on invoice', this.dataValue.data.swb);
    this.listOfSegregatedRules = this.dataValue.data.swb;
    this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
    this.firstRuleDetails(this.firstRuleId);
    this.dropdown = true;
    this.counter = 1;
    this.cardRules = true;
    this.HSNBoolean=false;
   }
   getCom() {
    console.log('on invoice', this.dataValue.data.com);
    this.listOfSegregatedRules = this.dataValue.data.com;
    this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
    this.firstRuleDetails(this.firstRuleId);
    this.dropdown = true;
    this.counter = 1;
    this.cardRules = true;
    this.HSNBoolean=false;
   }
  
   getsoo(){
    console.log('on invoice', this.dataValue.data.soo);
  this.listOfSegregatedRules = this.dataValue.data.soo;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean=false;
 }
 getben(){
  console.log('on invoice', this.dataValue.data.ben);
  this.listOfSegregatedRules = this.dataValue.data.ben;
  this.firstRuleId = this.listOfSegregatedRules[0].rule_id;
  this.firstRuleDetails(this.firstRuleId);
  this.dropdown = true;
  this.counter = 1;
  this.cardRules = true;
  this.HSNBoolean=false;
 }
firstRuleDetails(firstRuleId: any) {
  this.FirstruleExists = true;
  this.nextRule = false;
  console.log('first rule', firstRuleId);
  const request_id = this.request_id;
  this.rule_id = firstRuleId;
  this._httpService.getRuleById(request_id,this.rule_id).subscribe(
      data => {
          this.requestResponse = (data);
        //  if(this.requestResponse.responseStatus === 200) {
              this.ruleExists = false;
              this.nextRule = false;
              // this.remarksBtn = true;
              // this.statusBtn = false;
              // this.noremarksBtn = true;
          const dataVal = this.requestResponse.data;
          for (const item of dataVal) {
                this.accuracy = item.accuracy;
                console.log('accuracy', this.accuracy);
                const image = item.sentence;
                console.log('left', image[0].annotated_image_full);
                console.log('right', image[1].annotated_image_full);
                this.leftTitle = image[0].word_set;
                this.rightTitle = image[1].word_set;
                var mapWithLeft = item.sentence[0].missing_words_1;
                var mapWithRight = item.sentence[1].missing_words_2;
                var leftCoordinates =  item.sentence[0].missing_indices1;
                var rightCoordinates = item.sentence[1].missing_indices2;
                this.Highlight(this.leftTitle,this.rightTitle,mapWithLeft,mapWithRight,leftCoordinates,rightCoordinates);
                this.leftImage = /*'http://139.59.3.158:8990'*/ environment.imageEndPointApi+ image[0].annotated_image_full;
                this.rightImage = /*'http://139.59.3.158:8990'*/environment.imageEndPointApi + image[1].annotated_image_full;
                this.leftRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.leftImage);//this.left_hand_img_set[0]);
                this.rightRuleImg = this.sanitizer.bypassSecurityTrustResourceUrl(this.rightImage);//(this.right_hand_img_set[0]);
              }
         // }
          } ,
      error => {
          console.log(error);
          // this.handleError(error);
        },
      () => console.log('created employee', this.requestResponse)
    );
}
comply(remarks: any)  {
  this.modalService.open(remarks, { size: 'lg', backdrop: 'static' }).result.then(
    result => {
      this.closeResult = `Closed with: ${result}`;
    },
    reason => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    }
  );
}
reject(descrepantremarks: any)  {
  this.modalService.open(descrepantremarks, { size: 'lg', backdrop: 'static' }).result.then(
    result => {
      this.closeResult = `Closed with: ${result}`;
    },
    reason => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    }
  );
}
private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return `with: ${reason}`;
  }
}

clearVariables(){
  this.CompliantRemarks="";
  this.statusSent="";
}

// 
zoomin() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout() { 
  var GFG = document.getElementById("preview"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
}
// 
zoomin_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth + 100) + "px"; 
  GFG.style.height = (currHeight + 100) + "px"; 
} 

 zoomout_() { 
  var GFG = document.getElementById("preview_"); 
  var currWidth = GFG.clientWidth; 
  var currHeight = GFG.clientHeight;
  GFG.style.width = (currWidth - 100) + "px"; 
  GFG.style.height = (currHeight - 100) + "px"; 
} 

Highlight(left,right,leftLimit,rightLimit,leftCoordinates, rightCoordinates){

  //Manipulation Variables
  var trimmedLeftString =[];
  var trimmedRightString=[];
  //Spliting string into characters
  var leftString = left.split('');
  var rightString = right.split('');
  console.log("leftLimit",leftLimit)
  console.log("leftLimit",rightLimit)
  //Trimming Empty cell from the last of the array
 if(leftString[leftString.length-1] === '' || leftString[leftString.length - 1] === ' ' || leftString[leftString.length - 1] === undefined)
 {
  for(var i=0;i<leftString.length - 1;i++){
    trimmedLeftString[i] = leftString[i];
  }
 }else{
  trimmedLeftString=leftString;
 }
 if(rightString[rightString.length-1] === '' || rightString[rightString.length - 1] === ' ' || rightString[rightString.length - 1] === undefined)
 {
  for(var i=0;i<rightString.length - 1;i++){
    trimmedRightString[i] = rightString[i];
  }
 }else{
  trimmedRightString=rightString;
 }

 console.log("trimmedLeftString ::::", trimmedLeftString);
 console.log("trimmedRightString :::",trimmedRightString);
 console.log("DATATDAADARAD",leftCoordinates, rightCoordinates)
 
 var text='';
 if(leftCoordinates.length>0){
  for(var i=0;i<trimmedLeftString.length;i++){
    var j=0;
    var found=0;
    while(j<leftCoordinates.length){
      if(leftCoordinates[j]===i){
        text += "<span style='background-color:#F2C2B9'>"+trimmedLeftString[i]+"</span>";
        found=1;
        break;
      }
      j++;
    }
    if(found != 1){
      text += trimmedLeftString[i];
    }
  }
 }else{
   for(var i=0;i<trimmedLeftString.length;i++){
     text += trimmedLeftString[i];
   }
 }
  
 $('#new').html(text);


 var text='';
 if(rightCoordinates.length>0){
  for(var i=0;i<trimmedRightString.length;i++){
    var j=0;
    var found=0;
    while(j<rightCoordinates.length){
      if(rightCoordinates[j]===i){
        text += "<span style='background-color:#F2C2B9'>"+trimmedRightString[i]+"</span>";
        found=1;
        break;
      }
      j++;
    }
    if(found != 1){
      text += trimmedRightString[i];
    }
  }
 }else{
   for(var i=0;i<trimmedRightString.length;i++){
     text += trimmedRightString[i];
   }
 }
  
 $('#old').html(text);
 
 

  }

}
