import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CheckerService } from 'src/app/services/checker/docs.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-checker-classification',
  templateUrl: './checker-classification.component.html',
  styleUrls: ['./checker-classification.component.css']
})
export class CheckerClassificationComponent implements OnInit {


  classified_count:any;
  unclassified_count:any;
  screned_count:any;
  exchangeData:any;
  id:any;
  classificationData:any;
  arrayOfData:any;
  
  judgementImg:any;
  judgementClass:any;

  trackCount:any
  judgementID:any;
  decisionBtn:any;

  constructor(private _httpService:CheckerService, private modalService: NgbModal,private sanitizer:DomSanitizer, private router:Router) { }

  ngOnInit() {
    
    this.classified_count=0;
    this.unclassified_count=0;
    this.screned_count=0;
    this.arrayOfData=[];
    this.judgementImg=undefined;
    this.judgementClass=undefined;
    this.trackCount=0;
    this.judgementID='None';
    this.decisionBtn='';

    this.id=localStorage.getItem('id');
    this._httpService.classificationChecker(this.id).subscribe(r=>{
      this.exchangeData=(r);
      this.classified_count=this.exchangeData.data.classification_data.classifed_docs;
      this.unclassified_count=this.exchangeData.data.classification_data.un_classified_docs;
      this.screned_count=this.exchangeData.data.classification_data.screned_documents_count;
      this.classificationData=this.exchangeData.data.classification_data.data;
      for(var i=0;i<this.classificationData.length;i++){
        
        var hold;
        if(this.classificationData[i].type==='')
          hold=this.DocType(this.classificationData[i].name_of_document)
        else
          hold=this.classificationData[i].type;

        var a={
          id:this.classificationData[i].name_of_document,
          name:hold,
          // this.DocType(this.classificationData[i].name_of_document),
          classified:this.classificationData[i].classified,
          url:this.sanitizer.bypassSecurityTrustResourceUrl(environment.imageEndPointApi + this.classificationData[i].url),
          decision_response:'',
          decision_class:'',
        }
        this.arrayOfData.push(a);
      }
      console.log("99- ",this.arrayOfData)
      this.moveJudegement(this.arrayOfData[0]);

    });
  }

  DocType(filterData){
    if(filterData.slice(0,2).toLowerCase()==='lc'){
      return 'Letter of Credit';
    }else
    if(filterData.slice(0,3).toLowerCase()==='inv'){
      return 'Invoice';
    }else
    if(filterData.slice(0,11).toLowerCase()==='bill_of_exc')
    {
      return 'Bill of Exchange';
    }
    if(filterData.slice(0,3).toLowerCase()==='com')
    {
      return 'Commercial Invoice';
    }
    if(filterData.slice(0,3).toLowerCase()==='air')
    {
      return 'Air Way Bill';
    }
    if(filterData.slice(0,11).toLowerCase()==='bill_of_lad'){
      return 'Bill of Lading';
    }
    if(filterData.slice(0,3).toLowerCase()==='cer'){
      return 'Certificate of Origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ins'){
      return 'Insurance';
    }
    if(filterData.slice(0,5).toLowerCase()==='state'){
      return 'Statement of Origin';
    }
    if(filterData.slice(0,3).toLowerCase()==='ben' ){
      return 'Beneficiary';
    }
    if(filterData.slice(0,3)==='swb'){
      return 'Sea Way Bill';
    }else
    if(filterData.slice(0,4)==='pack'){
      return 'Packing List';
    }else
    if(filterData.slice(0,6)==='others'){
      return 'Others';
    }
    else{
      return filterData;
    }
   
  }

  moveJudegement(data){
    console.log("data---> ",data)
    this.judgementImg=data.url;
    this.judgementClass=data.name;
    this.judgementID=data.id;
  }
  next(){
    if(this.trackCount!=this.arrayOfData.length)
    {
      this.trackCount=this.trackCount+1;
      this.judgementImg=this.arrayOfData[this.trackCount].url;
    this.judgementClass=this.arrayOfData[this.trackCount].name;
    this.judgementID=this.arrayOfData[this.trackCount].id;
    this.decisionBtn=this.arrayOfData[this.trackCount].decision_response;
    }
  }
  prev(){
    if(this.trackCount!=0)
    {
      this.trackCount=this.trackCount-1;
      this.judgementImg=this.arrayOfData[this.trackCount].url;
    this.judgementClass=this.arrayOfData[this.trackCount].name;
    this.judgementID=this.arrayOfData[this.trackCount].id;
    this.decisionBtn=this.arrayOfData[this.trackCount].decision_response;
  }
  }
  zoomin() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth + 100) + "px"; 
    GFG.style.height = (currHeight + 100) + "px"; 
  } 
  
   zoomout() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth - 100) + "px"; 
    GFG.style.height = (currHeight - 100) + "px"; 
  }
  
  selectClass(data){
    this.judgementClass=this.arrayOfData[this.trackCount].name=data;
  }
  saveDecision(data){
    this.decisionBtn=this.arrayOfData[this.trackCount].decision_response=data;
  }

openXl(content) {
  this.modalService.open(content, { size: 'lg' });
}

navigator(data){
  this.router.navigate([data]);
}
}
