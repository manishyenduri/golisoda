import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckerClassificationComponent } from './checker-classification.component';

describe('CheckerClassificationComponent', () => {
  let component: CheckerClassificationComponent;
  let fixture: ComponentFixture<CheckerClassificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckerClassificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckerClassificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
