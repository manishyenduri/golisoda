import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CheckerService } from 'src/app/services/checker/docs.service';

@Component({
  selector: 'app-manual-reportslist',
  templateUrl: './manual-reports-list.component.html',
  styleUrls: ['./manual-reports-list.component.css']
})
export class ManualReportsListComponent implements OnInit {

  exchangeResponse:any;
  simbaResponse:any;
  compliantResponse=[];
  discrepantResponse=[];
  pendingResponse=[];
  returnedToMaker=[];
  constructor(private _httpService:CheckerService,
   private router: Router) { 
  }

  ngOnInit() {
    this._httpService.simbaReport().subscribe(res=>{
      this.exchangeResponse = (res);
      this.exchangeResponse.data.reverse();//sort(this.custom_sort);
      this.simbaResponse = this.exchangeResponse.data;

      // For loop to separate data cards
      var j=0;
      var k=0;
      var m=0;
      var z=0;
      for(var i=0;i<this.exchangeResponse.data.length;i++){

        console.log(this.exchangeResponse.data[i])
        if(this.exchangeResponse.data[i].transactionStatus === 'compliant')
        {
          this.compliantResponse[j] = this.exchangeResponse.data[i];
          j++;
        console.log("compliantResponsecompliantResponsecompliantResponse",this.compliantResponse[j])
        }
        else
        if(this.exchangeResponse.data[i].transactionStatus === 'discrepent')
        {  
          this.discrepantResponse[k] = this.exchangeResponse.data[i];
          k++;
        }
        else
        if(this.exchangeResponse.data[i].transactionStatus === 'In Progress With Checker')
        {
          this.pendingResponse[m] = this.exchangeResponse.data[i];
          m++;
        }
        else
        if(this.exchangeResponse.data[i].transactionStatus === 'pending')
        {
          this.returnedToMaker[z] = this.exchangeResponse.data[i];
        }
        
      }
      this.pendingResponse.reverse();
      this.compliantResponse.reverse();
      console.log(this.compliantResponse,this.discrepantResponse,this.pendingResponse)
    });
  }
  routeToManualReport(id:any) {
    localStorage.setItem('id',id);
    this.router.navigate(['checker/4c-dashboard']);
 }
 custom_sort(a,b){
  return new Date(a.createdDate).getUTCDate() - new Date(b.createdDate).getUTCDate();
}
}
