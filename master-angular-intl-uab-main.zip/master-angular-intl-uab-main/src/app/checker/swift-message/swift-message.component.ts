import { Component, OnInit } from '@angular/core';
import { CheckerService } from 'src/app/services/checker/docs.service';

@Component({
  selector: 'app-swift-message',
  templateUrl: './swift-message.component.html',
  styleUrls: ['./swift-message.component.css']
})
export class SwiftMessageComponent implements OnInit {

  exchangeData:any;
  arrayData:any;
  constructor(private _httpService:CheckerService) { }

  ngOnInit() {
    this._httpService.swift_msg().subscribe(r=>{
      console.log("Swift_masg ", r)
      this.exchangeData=(r);
      this.arrayData=this.exchangeData.data;
    })
  } 
}
