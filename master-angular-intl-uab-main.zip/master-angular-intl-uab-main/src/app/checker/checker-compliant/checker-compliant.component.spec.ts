import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckerCompliantComponent } from './checker-compliant.component';

describe('CheckerCompliantComponent', () => {
  let component: CheckerCompliantComponent;
  let fixture: ComponentFixture<CheckerCompliantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckerCompliantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckerCompliantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
