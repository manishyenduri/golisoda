import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckerCorrectComponent } from './checker-correct.component';

describe('CheckerCorrectComponent', () => {
  let component: CheckerCorrectComponent;
  let fixture: ComponentFixture<CheckerCorrectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckerCorrectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckerCorrectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
