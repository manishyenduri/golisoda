import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckerProcessStartComponent } from './checker-process-start.component';

describe('CheckerProcessStartComponent', () => {
  let component: CheckerProcessStartComponent;
  let fixture: ComponentFixture<CheckerProcessStartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckerProcessStartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckerProcessStartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
