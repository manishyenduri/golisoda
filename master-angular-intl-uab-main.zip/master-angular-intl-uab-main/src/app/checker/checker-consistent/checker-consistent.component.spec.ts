import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckerConsistentComponent } from './checker-consistent.component';

describe('CheckerConsistentComponent', () => {
  let component: CheckerConsistentComponent;
  let fixture: ComponentFixture<CheckerConsistentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckerConsistentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckerConsistentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
