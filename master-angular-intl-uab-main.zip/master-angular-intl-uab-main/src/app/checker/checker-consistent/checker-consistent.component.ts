import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CheckerService } from 'src/app/services/checker/docs.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-checker-consistent',
  templateUrl: './checker-consistent.component.html',
  styleUrls: ['./checker-consistent.component.css']
})
export class CheckerConsistentComponent implements OnInit {

 
  // exchangeData:any;
  // showData:any;
  // slideIndex:any;
  // endPoint:any;
  // holdArray:any;
  // imgArry:any;
  // idData:any;
  // constructor(private _httpService:CheckerService, private router:Router, private santize:DomSanitizer, private modalService:NgbModal) { }

  // ngOnInit() {
  //   this.idData=0;
  //   this.endPoint=environment.imageEndPointApi;
  //   this.showData=[];
  //   this._httpService.consistencyChecker(localStorage.getItem('id')).subscribe(r=>{
  //     console.log("RTP-> ",r)
  //     this.exchangeData=(r);
  //     for(var i=0;i<this.exchangeData.data.length;i++){
  //       var a={
  //         data:this.exchangeData.data[i].data,
  //         matched_urls_count:this.exchangeData.data[i].matched_urls.length,
  //         notmatched_urls_count:this.exchangeData.data[i].notmatched_urls.length,
  //         matched_urls:this.exchangeData.data[i].matched_urls,
  //         notmatched_urls:this.exchangeData.data[i].notmatched_urls,
  //         title:this.exchangeData.data[i].title
  //       }
  //       this.showData.push(a);
  //     }
  //     console.log( 'jikhi ',this.showData)
  //   })
  // }

  // opexl(content,data){
  //   console.log('ssdsd --',data)
  //   this.idData=0;
  //   this.holdArray=data;
  //   this.imgArry=this.santize.bypassSecurityTrustResourceUrl(this.endPoint+data[0]);
  //   this.modalService.open(content, {size:'lg'});
  // }
  // prev(){
  //   this.idData++;
  //   this.imgArry=this.santize.bypassSecurityTrustResourceUrl(this.endPoint+this.holdArray[this.idData]);
 
  // }
  // next(){
  //   this.idData++;
  //   this.imgArry=this.santize.bypassSecurityTrustResourceUrl(this.endPoint+this.holdArray[this.idData]);
  // }


  // clickView(){
  //   this.slideIndex=1;
  // }
  
  // zoomin() { 
  //   var GFG = document.getElementById("preview"); 
  //   var currWidth = GFG.clientWidth; 
  //   var currHeight = GFG.clientHeight;
  //   GFG.style.width = (currWidth + 100) + "px"; 
  //   GFG.style.height = (currHeight + 100) + "px"; 
  // } 
  
  //  zoomout() { 
  //   var GFG = document.getElementById("preview"); 
  //   var currWidth = GFG.clientWidth; 
  //   var currHeight = GFG.clientHeight;
  //   GFG.style.width = (currWidth - 100) + "px"; 
  //   GFG.style.height = (currHeight - 100) + "px"; 
  // }

  // navigator(data){
  //   localStorage.setItem('Noun_id','C9MJWN4ET8');
  //   this.router.navigate([data]);
  // }



  exchangeData:any;
  showData:any;
  slideIndex:any;
  endPoint:any;
  holdArray:any;
  imgArry:any;
  idData:any;
  constructor(private _httpService:CheckerService, private router:Router, private santize:DomSanitizer, private modalService:NgbModal) { }

  ngOnInit() {
    this.idData=0;
    this.endPoint=environment.imageEndPointApi;
    this.showData=[];
    this._httpService.consistencyChecker(localStorage.getItem('id')).subscribe(r=>{
      console.log("RTP-> ",r)
      this.exchangeData=(r);
      for(var i=0;i<this.exchangeData.data.data.length;i++){
        var a={
          data:this.exchangeData.data.data[i].data,
          matched_urls_count:this.exchangeData.data.data[i].matched_urls.length,
          notmatched_urls_count:this.exchangeData.data.data[i].notmatched_urls.length,
          matched_urls:this.exchangeData.data.data[i].matched_urls,
          notmatched_urls:this.exchangeData.data.data[i].notmatched_urls,
          ofac_status:this.exchangeData.data.data[i].ofac_status,
          title:this.exchangeData.data.data[i].title
        }
        this.showData.push(a);
      }
      console.log( 'jikhi ',this.showData)
    })
  }

  opexl(content,data){
    console.log('ssdsd --',data)
    this.idData=0;
    this.holdArray=data;
    this.imgArry=this.santize.bypassSecurityTrustResourceUrl(this.endPoint+data[0]);
    this.modalService.open(content, {size:'lg'});
  }
  prev(){
    this.idData++;
    this.imgArry=this.santize.bypassSecurityTrustResourceUrl(this.endPoint+this.holdArray[this.idData]);
 
  }
  next(){
    this.idData++;
    this.imgArry=this.santize.bypassSecurityTrustResourceUrl(this.endPoint+this.holdArray[this.idData]);
  }


  clickView(){
    this.slideIndex=1;
  }
  
  zoomin() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth + 100) + "px"; 
    GFG.style.height = (currHeight + 100) + "px"; 
  } 
  
   zoomout() { 
    var GFG = document.getElementById("preview"); 
    var currWidth = GFG.clientWidth; 
    var currHeight = GFG.clientHeight;
    GFG.style.width = (currWidth - 100) + "px"; 
    GFG.style.height = (currHeight - 100) + "px"; 
  }

  navigator(data){
    localStorage.setItem('Noun_id','C9MJWN4ET8');
    this.router.navigate([data]);
  }


}
