import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rbi-reports',
  templateUrl: './rbi-reports.component.html',
  styleUrls: ['./rbi-reports.component.css']
})
export class rbireportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
