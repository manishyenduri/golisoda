import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendtomakerModalComponent } from './sendtomaker-modal.component';

describe('SendtocheckerModalComponent', () => {
  let component: SendtomakerModalComponent;
  let fixture: ComponentFixture<SendtomakerModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendtomakerModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendtomakerModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
