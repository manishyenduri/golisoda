import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';

@Injectable()
export class GlobalService {
 
  public static getHeaders() {
    const token = localStorage.getItem('access_token');
    // console.log('token', token);
    const headerToken = 'Bearer ' + token;
    // console.log('hk', headerToken);
    const headers = new Headers({ 'Authorization': headerToken , 'Content-Type': 'application/json'});
    return new RequestOptions({ headers: headers });
  }
}
