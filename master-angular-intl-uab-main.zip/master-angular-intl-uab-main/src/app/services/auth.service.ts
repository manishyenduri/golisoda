import { Http, Headers, Response } from "@angular/http";
import { Injectable, EventEmitter } from "@angular/core";
import { HttpHeaders } from "@angular/common/http";
import { PlatformLocation } from "@angular/common";
import { environment } from "../../environments/environment";
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { throwError, Observable, from } from 'rxjs';
import  {ICurrentUser} from './user'
import { HttpClient } from "@angular/common/http";
import { GlobalService } from "./global.service";
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  user: any;
  username: string;
  token: any;
  role: any;
  static USER_KEY: string;
  public redirectUrl: string;


  profileLoaded: EventEmitter<string>;
  profile: any;
  logoutResponse: any;
  constructor(private router: Router, private http: Http, private httpc:HttpClient, private platformLocation: PlatformLocation, private toastr: ToastrService) {
  }

  isAuthenticated() {
    return this.user.token != null && this.user.token.length > 0;
  }

  logout() {
    var url = environment.endPointApi + "logout";
    var access_token = localStorage.getItem('access_token');
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', 'Bearer ' + access_token);
    const options = { headers: headers };
    this.http.delete(url, options).subscribe(
      data => {
        this.logoutResponse = (data);
        const dataVal = this.logoutResponse.json();
        // this.toastr.success( dataVal.msg );
        if (dataVal.msg === 'Successfully logged out') {
          this.router.navigate(['/login']);
        }
      },
      (e) => {
        var data = e.json();
        this.toastr.error("", data.msg);
      }
    );
  }

  
  public refresh() {
    console.log('inside services');
    var url = environment.endPointApi + "refresh";
    var body = {};
    var refresh_token = localStorage.getItem('refresh_token');
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', 'Bearer ' + refresh_token);
    const options = { headers: headers };
    return this.http.post(url, body, options).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
    });
  }



  // login
  public login(formdata) {
    let data = {
      'userId': formdata.userId,
      'password': formdata.password
    };
    
    const body = JSON.stringify(data);
    // console.log(body);
    const head = new Headers({
        'Content-Type': 'application/json'
    });
    return this.http.post(environment.endPointApi + 'user/login', body, {headers: head}).map((response: Response) => {
      if (this.redirectUrl) {
        this.router.navigate([this.redirectUrl]);
        this.redirectUrl = null;
      } else {
        const user = response.json();
        user.responseStatus = response.status;
        return user;
        // return user;
        
        
      }
       
    }).catch((error) => {
      if (error.status === 500) {
        const err = error.json();
        err.responseStatus = error.status;
        return throwError(err);
      } else if (error.status === 400) {
        const err = error.json();
        err.responseStatus = error.status;
        return throwError(err);
      } else if (error.status === 401) {
        const err = error.json();
        err.responseStatus = error.status;
        return throwError(err);
      }
  });
  }

  // create new password
  public resetPassword(emailId, oldPassword, newPassword) {
    const body = {
      "emailId": emailId,
      "newPassword": newPassword,
      "oldPassword": oldPassword
    }
    console.log('++++++++++++++', body)
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.put(environment.endPointApi + 'user/reset_password', body, { headers: headers }).map((response: Response) => {
      if (this.redirectUrl) {
        this.router.navigate([this.redirectUrl]);
        this.redirectUrl = null;
      } else {
        const user = response.json();
        user.responseStatus = response.status;
        return user;
      }
    }).catch((error) => {
      if (error.status === 500) {
        const err = error.json();
        err.responseStatus = error.status;
        return throwError(err);
      } else if (error.status === 400) {
        const err = error.json();
        err.responseStatus = error.status;
        return throwError(err);
      } else if (error.status === 401) {
        const err = error.json();
        err.responseStatus = error.status;
        return throwError(err);
      }
    });
  }
// 
// // public refreshToken(): Observable<ICurrentUser>  {
// //   let 	currentUser_refresh_token = localStorage.getItem('currentUser');
// //   let token = currentUser_refresh_token;
// //   console.log('inside services');
// //   var url = environment.endPointApi + "user/refresh";
// //   var headers = new Headers();
// //   headers.append('Content-Type', 'application/json');
// //   headers.append('authorization', 'Bearer ' + token);
// //   console.log("Refreshhhh token: ", token)
// //   const options = { headers: headers };
// //   return this.http.post(url, options).map((response: Response) => {
// //     console.log(response.status);
// //     const user = response.json();
// //     user.responseStatus = response.status;
// //     console.log(user);
// //     localStorage.setItem('currentUser_access_token',  (user.items[0].access_token));
// //     localStorage.setItem('currentUser_refresh_token',  (user.items[0].refresh_token));
// //      return <ICurrentUser>user;
// //   }).catch((error) => {
// //     console.log('error', error);
// //     if (error.status === 500) {
// //       console.log('status', error.status);
// //       const err = error.json();
// //       err.responseStatus = error.status;
// //       console.log('status', err.responseStatus);
// //       return throwError(err);
// //     } else if (error.status === 400) {
// //       console.log('status', error.status);
// //       const err = error.json();
// //       err.responseStatus = error.status;
// //       console.log('status', err.responseStatus);
// //       return throwError(err);
// //     } else if (error.status === 401) {
// //       console.log('status', error.status);
// //       const err = error.json();
// //       console.log('err', err);
// //       err.responseStatus = error.status;
// //       console.log('status', err.responseStatus);
// //       return throwError(err);
// //     }
// //   });
// // }
// // getAuthToken
// getAuthToken() : string {
//  let access_token = localStorage.getItem('currentUser_access_token');
//  let refresh_token = localStorage.getItem('currentUser_refresh_token');
        
//  console.log(access_token ,refresh_token )
//   if(access_token != null && refresh_token != null) {
//     return access_token;
//   }
 
//   return '';
// }

//Consider this code for Refresh token
ReplaceToken(){
  var body;
  
  return this.http.post(environment.endPointApi+'user/refresh',body, GlobalService.getHeaders())
  .map((response:Response)=>{
    // console.log('Replace Token error : ',response)
    const user = response.json();
    return user;
  })
}


public createAccount(data) {
  console.log('inside services');
  var url = environment.endPointApi + "user/user_register_self";
  var body = {
    "OrganizationName": data.org_name,
    "city": data.city,
    "country": data.country,
    "emailId": data.email,
    "employeeFirstName": data.first_name,
    "employeeLastName": data.last_name,
    "password": data.password,
    "roles": data.role
  };
  var refresh_token = localStorage.getItem('refresh_token');
  var headers = new Headers();
  headers.append('Content-Type', 'application/json');
  headers.append('Authorization', 'Bearer ' + refresh_token);
  const options = { headers: headers };
  return this.http.post(url, body, options).map((response: Response) => {
    console.log(response.status);
    const user = response.json();
    user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
  });
}

}

