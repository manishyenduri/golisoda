import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { GlobalService } from '../global.service';
import { throwError } from 'rxjs';
import { HttpEventType, HttpClient } from '@angular/common/http';
@Injectable()

export class AdminService {
   // tslint:disable-next-line: deprecation
    constructor(private http: HttpClient, private router: Router) { }

   
  //   public delete(id) {
  //     const data= {
  //       id: this.employeeId,
  //     }
  //     for(let i = 0; i < this.data.length; ++i){
  //       if (this.data[i].id === id) {
  //           this.data.splice(i,1);
  //       }
  //   }
  //  }
    //  const index = this.data.indexOf(d);
      // this.data.splice(index, 1);
    // tslint:disable-next-line: comment-format
    //API call for user-admin registration
    public registerAdmin(email_Id: any) {
        const body = {
            'emailId': email_Id,
            'roles': 'admin'
        };
        // tslint:disable-next-line: deprecation
        return this.http.post(environment.endPointApi + 'user/admin_register', body).map((response: Response) => {
            console.log(response.status);
            const user = response.json();
            user.responseStatus = response.status;
            console.log(user);
            return user;
        }).catch((error) => {
          console.log('error', error);
          if (error.status === 500) {
            console.log('status', error.status);
            const err = error.json();
            err.responseStatus = error.status;
            console.log('status', err.responseStatus);
            return throwError(err);
          } else if (error.status === 400) {
            console.log('status', error.status);
            const err = error.json();
            err.responseStatus = error.status;
            console.log('status', err.responseStatus);
            return throwError(err);
          } else if (error.status === 401) {
            console.log('status', error.status);
            const err = error.json();
            console.log('err', err);
            err.responseStatus = error.status;
            console.log('status', err.responseStatus);
            return throwError(err);
          }
      });
    }

    public userRegisteration(formdata) {
   const body = {
    'branch_Name': formdata.branch_Name,
    'city': formdata.city,
    'country': formdata.country,
    'designation': formdata.designation,
    'emailId': formdata.emailId,
    'employeeId': formdata.employeeId,
    'employeeName': formdata.employeeName,
    'reporting_Authority': formdata.reporting_Authority,
    'roles': formdata.roles
  };

    console.log(body);
    // tslint:disable-next-line: deprecation
    return this.http.post(environment.endPointApi + 'user/user_register', body /*, GlobalService.getHeaders()*/).map((response: Response) => {
        console.log("User Registration(Response Status): ",response);
        const user = response;
        // const user = response.json();
       // user.responseStatus = response.status;
        console.log("User REgistration Data: ",user);
        return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
    }

    // list of user
    public listUsers(): Observable<any> {
      return this.http.get(environment.endPointApi + 'user/list_user'
      ).map((response: Response) => {
        console.log("sdsdsd",response);
        const user = response;
        //user.responseStatus = response.status;
        console.log("I M User: ",user);
        return user;
      }).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
    }
    // delete user
    public deleteUser(emailId) {
     
      const body = {
          'emailId': emailId
      }
      return this.http.put(environment.endPointApi + 'user/delete',
       body/*, GlobalService.getHeaders()*/).map((response: Response) => {
        console.log(response.status);
        const user = response;
        //user.responseStatus = response.status;
        console.log(user);
        return user;
      }).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }
  // update user
  public userUpdate(selectedItem) {
    const body ={
      "branch_Name": selectedItem.branch_Name,
      "city": selectedItem.city,
      "country": selectedItem.country,
      "designation": selectedItem.designation,
      "emailId": selectedItem.emailId,
      "employeeId": selectedItem.employeeId,
      "employeeName": selectedItem.employeeName,
      "reporting_Authority": selectedItem.reporting_Authority,
      "roles": selectedItem.roles
    }

    // console.log("Name ::::::: ",selectedItem.employeeName);
    // console.log("ID ::::::: ",selectedItem.employeeId);
    // console.log("Country ::::::: ",selectedItem.country)
    // console.log("City ::::::: ",selectedItem.city)
    // console.log("Branch Name ::::::: ",selectedItem.branch_Name)
    // console.log("Reporting Auth ::::::: ",selectedItem.reporting_Authority)
    // console.log("Email ::::::: ",selectedItem.emailId)
    // console.log("Roles ::::::: ",selectedItem.roles)
    // console.log("B-------Name : ",selectedItem.branch_Name, " ---------------Email Id ::: ", selectedItem.emailId)
    // const body ={
    //   "branch_Name": "itpl",
    //   "city": "Bangalore",
    //   "country": "IN",
    //   "designation": "HR",
    //   "emailId": "nima.subba@simplyfi.tech",
    //   "employeeId": "i04sdsd",
    //   "employeeName": "John",
    //   "reporting_Authority": "general",
    //   "roles": "maker"
    // }
    console.log('body:', body )
    return this.http.put(environment.endPointApi + 'user/update',
     body/*, GlobalService.getHeaders()*/).map((response: Response) => {
      console.log("Response Status of Update ::: ",response);
      const user = response;
    // user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
}
