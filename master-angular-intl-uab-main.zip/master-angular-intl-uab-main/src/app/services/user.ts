export interface ICurrentUser {
    currentUser_access_token: any;
    currentUser_refresh_token: any;
   
  }