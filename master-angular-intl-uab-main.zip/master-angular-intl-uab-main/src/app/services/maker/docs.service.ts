import { Injectable, Injector } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { GlobalService } from '../global.service';
import { throwError } from 'rxjs';
import { HttpEventType, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { catchError, tap } from 'rxjs/operators';
import { AuthService } from '../auth.service';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class MakerService {
  _httpService: any;
  id: any = '';

constructor(private http: HttpClient, private router: Router,private injector:Injector) { }
public  upload(fileToUpload: File/*,fileToUploadName*/,id) {

    let access_token = localStorage.getItem('access_token');

    const headers = new Headers();

    headers.append('Authorization', 'Bearer ' + access_token);
    const options = { headers: headers };
    const formData: FormData = new FormData();
    console.log('sd', fileToUpload, fileToUpload.name);
    formData.append('file', fileToUpload, fileToUpload.name);
    console.log('formdata', formData);

    // https://isimbaapi.invoizo.com/maker/docs/upload

    return this.http.post( environment.endPointApi + 'maker/docs/upload', formData /*, options*/).map((response: any) => {
    
      const user = response;
      console.log("DATA FROM BACK ::: ",user.request_id)
      console.log("Upload response status : ",user.status)
      return user;
      // console.log(response.type)

      // switch (response.type) {
      //   case HttpEventType.ResponseHeader:
      //     console.log(response.status);
      //     const user = response;
      //     user.responseStatus = response.status;
      //     console.log("I am User: ",user);
      //     return user;
      //   default:
      //     console.log(response.status);
      // }
    }).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }

  public uploadNoun(fileToUpload: File/*,fileToUploadName*/,id) {

    let access_token = localStorage.getItem('access_token');

    const headers = new Headers();

    headers.append('Authorization', 'Bearer ' + access_token);
    const options = { headers: headers };
    const formData: FormData = new FormData();
    console.log('sd', fileToUpload, fileToUpload.name);
    formData.append('file', fileToUpload, fileToUpload.name);
    formData.append('request_id',id);
    console.log('formdata', formData);

    return this.http.post( environment.nounEndPoitApi + 'idfc/extract', formData /*, options*/).map((response: any) => {
      
      const user = response;
      console.log("DATA FROM BACK ::: ",user.request_id)
      console.log("Upload response status : ",user.status)
      return user;
      // console.log(response.type)

      // switch (response.type) {
      //   case HttpEventType.ResponseHeader:
      //     console.log(response.status);
      //     const user = response;
      //     user.responseStatus = response.status;
      //     console.log("I am User: ",user);
      //     return user;
      //   default:
      //     console.log(response.status);
      // }
    }).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }
  public uploadGeneric(fileToUpload: File/*,fileToUploadName*/,id) {

    let access_token = localStorage.getItem('access_token');

    const headers = new Headers();

    headers.append('Authorization', 'Bearer ' + access_token);
    const options = { headers: headers };
    const formData: FormData = new FormData();
    console.log('sd', fileToUpload, fileToUpload.name);
    formData.append('file', fileToUpload, fileToUpload.name);
    formData.append('request_id',id);
    console.log('formdata', formData);

    return this.http.post( environment.genericEndPointApi + 'ocr/extract', formData /*, options*/).map((response: any) => {
      
      const user = response;
      console.log("DATA FROM BACK ::: ",user.request_id)
      console.log("Upload response status : ",user.status)
      return user;
      // console.log(response.type)

      // switch (response.type) {
      //   case HttpEventType.ResponseHeader:
      //     console.log(response.status);
      //     const user = response;
      //     user.responseStatus = response.status;
      //     console.log("I am User: ",user);
      //     return user;
      //   default:
      //     console.log(response.status);
      // }
    }).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }

  public generateNounID(){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation http://157.245.96.130:8050
    return this.http.get(environment.nounEndPoitApi +'idfc/get_id' /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }

  public getVesselTracking(){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation http://157.245.96.130:8050
    return this.http.get(`https://api.datalastic.com/api/v0/vessel?api-key=4d980dd2-8df8-40e1-a0e1-c9afba32aace&uuid=b8625b67-7142-cfd1-7b85-595cebfe4191` /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }


  public trackOutward(id){
    if(localStorage.getItem('encpUser')!='M0001' && localStorage.getItem('encpUser')!='M0004')
    return;

    return this.http.get('https://or-simba.invoizo.com/out_rem/get_process_status/'+id /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
  public getNounList(){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get(environment.nounEndPoitApi+'idfc/get_all_transactions' /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
  
  public getGenericList(){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get(environment.genericEndPointApi+'ocr/get_all_transactions' /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
    
  public getGenericData(id){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get(environment.genericEndPointApi+'ocr/get_data/'+id /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
  
    
  public getOutwardList(){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get('https://or-simba.invoizo.com/out_rem/get_all_transactions' /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
  
  public uploadOutward(fileToUpload: File/*,fileToUploadName*/,id) {

    let access_token = localStorage.getItem('access_token');

    const headers = new Headers();

    headers.append('Authorization', 'Bearer ' + access_token);
    const options = { headers: headers };
    const formData: FormData = new FormData();
    console.log('sd', fileToUpload, fileToUpload.name);
    formData.append('file', fileToUpload, fileToUpload.name);
    formData.append('request_id',id);
    console.log('formdata', formData);

    return this.http.post( 'https://or-simba.invoizo.com/out_rem/extract', formData /*, options*/).map((response: any) => {
      
      const user = response;
      console.log("DATA FROM BACK ::: ",user.request_id)
      console.log("Upload response status : ",user.status)
      return user;
      // console.log(response.type)

      // switch (response.type) {
      //   case HttpEventType.ResponseHeader:
      //     console.log(response.status);
      //     const user = response;
      //     user.responseStatus = response.status;
      //     console.log("I am User: ",user);
      //     return user;
      //   default:
      //     console.log(response.status);
      // }
    }).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }

  public getOutwardRemittancList(id){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get('https://or-simba.invoizo.com/out_rem/get_all_transactions'+id /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
 

  public generateOutwardID(){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get(' https://or-simba.invoizo.com/out_rem/get_id' /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
  public generateNounID2(){
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get(environment.nounEndPoitApi+'idfc/get_id' /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }



  public getNounReportByID(){
    // console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get(environment.nounEndPoitApi+'idfc/get_data/'+localStorage.getItem('Noun_id') /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
  

  public getOutwardReportByID(){
    // console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get('https://or-simba.invoizo.com/out_rem/get_data/'+localStorage.getItem('Outward_id') /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }

  // All the documents that have processed will be under queue to store to database
  public analyze(request_id) {
    
    console.log('inside services');
    const requestId = request_id;
    const body = {
        "request_id": requestId
    };
    return this.http.post(environment.endPointApi + 'maker/docs/process/', body/*,
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log("Process Response: ",response)//.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status sdsd', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

  // tslint:disable-next-line: comment-format
  //Receving Analyzed Documents
  public processedDocs(requestID) {
    const reqs_id = requestID;
    this.id = reqs_id
    localStorage.setItem('id',reqs_id)
    console.log('Executing processDocs API');
    // tslint:disable-next-line: deprecation
    return this.http.get(environment.endPointApi + 'maker/docs/details/'+reqs_id /*,
     GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }

  // TO get all the documents list
  // Customer name will generated only after storing all the trade docs successfully to the DB

  public listDocs() {
    console.log('inside services');
    return this.http.get(environment.endPointApi + 'maker/docs/skip:0/limit:20/key:lastModified/order:-1'//,
    // tslint:disable-next-line: deprecation
   /* GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

// To get the list of rules
public getRequestById() {
    console.log('inside services');
    const id = localStorage.getItem('id')
    const url = environment.endPointApi+'maker/docs/'
    
    return this.http.get(url+id,
    // tslint:disable-next-line: deprecation
   /* GlobalService.getHeaders()*/).map((response: Response) => {
     // console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public getHSN_data() {
  console.log('inside services');
  const id = localStorage.getItem('id')
  const url = environment.endPointApi+'maker/hsndata/'
  
  return this.http.get(url+id,
  // tslint:disable-next-line: deprecation
 /* GlobalService.getHeaders()*/).map((response: Response) => {
   // console.log(response.status);
    const user = response;//.json();
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
// /MT734
public swift_msg() {
  console.log('inside services');
  const id = localStorage.getItem('id')
  const url = environment.endPointApi+'MT734'
  
  return this.http.get(url,
  // tslint:disable-next-line: deprecation
 /* GlobalService.getHeaders()*/).map((response: Response) => {
   // console.log(response.status);
    const user = response;//.json();
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}



public ofac_status() {
  console.log('inside services');
  const id = localStorage.getItem('id')
  const url = environment.endPointApi+'maker/ofacStatus/'
  
  return this.http.get(url+id,
  // tslint:disable-next-line: deprecation
 /* GlobalService.getHeaders()*/).map((response: Response) => {
   // console.log(response.status);
    const user = response;//.json();
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

// To get the LC image and trade doc image inorder to validate manually
public getRuleById(request_id, rule_id) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    return this.http.get(environment.endPointApi + 'maker/docs/' + requestId + '/' + ruleId /*,
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response //.json();
      // user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
// To add remarks for each rule
public postRemarks(request_id, rule_id, rule) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    const body = {
        'remarks': rule.remarks
    };
    return this.http.put(environment.endPointApi + 'maker/docs/' + requestId + '/' + ruleId + '/remarks',
     // tslint:disable-next-line: deprecation
     body/*, GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

// If the rule is compliant
public postComply(request_id, rule_id) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    const body = {
        'status': 1
    };
    return this.http.put(environment.endPointApi + 'maker/docs/' + requestId + '/' + ruleId + '/status',
     // tslint:disable-next-line: deprecation
     body/*, GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
// If the rule is discrepant
public postDiscrepant(request_id, rule_id) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    const body = {
        'status': 0
    };
    return this.http.put(environment.endPointApi + 'maker/docs/' + requestId + '/' + ruleId + '/status',
     // tslint:disable-next-line: deprecation
     body/*, GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
// To get the summary of a document
public listReport() {
    console.log('inside services');
    const requestId = localStorage.getItem('id')
    return this.http.get(environment.endPointApi + 'maker/docs/summary/'+requestId /*,
    // tslint:disable-next-line: deprecation
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response //.json();
    //  user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
// for tooltip on hover of an document inside documents list
public requestLogs(request_id) {
    console.log('inside services');
    const requestId = request_id;
    return this.http.get(environment.endPointApi + 'maker/docs/' + requestId + '/logs'/*,
    // tslint:disable-next-line: deprecation
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
// 
public ofacVerification(request_id, data) {
  console.log('inside services');
  const requestId = request_id;
  return this.http.get(environment.endPointApi + 'maker/ofacStatus/' + requestId+'/' + data /*,
  // tslint:disable-next-line: deprecation
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
    // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
// To sent the document to checker
public requestStatus(request_id) {
    console.log('inside services');
    const requestId = request_id;
    const body = {
        'status': 1
    };
    return this.http.put(environment.endPointApi + 'maker/docs/' + requestId + '/status', body/*,
    // tslint:disable-next-line: deprecation
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
// To reject the document
public requestReject(request_id) {
    console.log('inside services');
    const requestId = request_id;
    const body = {
        'status': 0
    };
    return this.http.put(environment.endPointApi + 'maker/docs/' + requestId + '/status', body/*,
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
// To add remarks for the document before sending to checker
public requestRemarks(request_id, rule) {
    console.log('inside services');
    const requestId = request_id;
    const body = {
        'remarks': rule.remarks
    };
    return this.http.put(environment.endPointApi + 'maker/docs/' + requestId + '/remarks', body/*,
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
//table Calling compliance Report
public myComRep() {
  console.log('compliance services',this.id);
  const id = localStorage.getItem('id')
  const url = environment.endPointApi+'maker/docs/data/'
  return this.http.get(url+id/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
   // console.log(response.status);
    const user = response;//.json();
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


//Get Article(required_id)
public getArticleId(article_Id: any) {
  const articleID = article_Id;
  console.log('Get article services');
  // http://139.59.3.158:8501
  return this.http.get(environment.endPointApi+'article/' + articleID).map((response: Response) => {
   // console.log(response.status);
    const user = response;//.json();
   // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

public centralQueueData() {
  console.log('inside services');
  return this.http.get(environment.endPointApi + 'maker/docs/new_transaction/0/10'/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
   // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

public pickUpTransaction(id) {
  console.log('inside services');
  return this.http.get(environment.endPointApi + 'maker/docs/'+id/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
   // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


public classificationMaker(id) {
  console.log('inside services');
  return this.http.get(environment.endPointApi + 'maker/classification_data/'+id/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
   // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
// get   

public consistencyMaker(id) {
  console.log('inside services');
  return this.http.get(environment.endPointApi + 'maker/consistancy/'+id/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
   // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
// maker/docs/transaction_history
public transactionHhistory() {
  console.log('inside services');
  return this.http.get(environment.endPointApi + 'maker/docs/transaction_history/0/10'/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
   // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
// transction history status
public transactionStatus() {
  console.log('inside services');
  const request_id = localStorage.getItem('id')
  console.log(request_id)
  return this.http.get(environment.endPointApi + 'maker/docs/transaction_status/'+request_id/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    //console.log("Transaction status :::",response);
    const user = response;
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
// // 
// intercept(request:HttpRequest<any>, next:HttpHandler):Observable<HttpEvent<any>>{
//   let auth = this.injector.get(MakerService);
//   let authToken = this.injector.get(AuthService);
// debugger
//   if(authToken.isAuthenticated)
//   {
//     let cloned = request.clone({headers: request.headers.set('Authorization','Bearer '+ authToken.getAuthToken())});
//     return next.handle(cloned).pipe(
//       tap(r=>{
//         console.log("Response Data: ",r)
//       }),
//       catchError(err => {
//         if(err.status === 500){
//           console.log('status',err.status);
//           const error = err.json();
//           error.responseStatus = err.status;
//           console.log('status',err.responseStatus);
//           return throwError(error)
//         }
//         else if (err.status === 400) {
//           console.log('status', err.status);
//           const error = err.json();
//           error.responseStatus = err.status;
//           console.log('status', error.responseStatus);
//           return throwError(error);
//         } else if (err.status === 401) {
//           console.log('status', err.status);
//           const error = err.json();
//           console.log('err', error);
//           error.responseStatus = err.status;
//           console.log('status', error.responseStatus);
//           return throwError(error);
//         }
//       }));
//   }
//   else
//   {
//     return next.handle(request).pipe(
//       catchError(err => {
//         if(err.status === 500){
//           console.log('status',err.status);
//           const error = err.json();
//           error.responseStatus = err.status;
//           console.log('status',err.responseStatus);
//           return throwError(error)
//         }
//         else if (err.status === 400) {
//           console.log('status', err.status);
//           const error = err.json();
//           error.responseStatus = err.status;
//           console.log('status', error.responseStatus);
//           return throwError(error);
//         } else if (err.status === 401) {
//           console.log('status', err.status);
//           const error = err.json();
//           console.log('err', error);
//           error.responseStatus = err.status;
//           console.log('status', error.responseStatus);
//           return throwError(error);
//         }
//       })
//     );
//   }
  
// }

//API for send to checker

public sendToChecker(checkerId, remarks, requestId, reportStatus) {
  console.log('inside services(send to checker)');
  const Checkerid = checkerId;
  const Remarks = remarks;
  const RequestId = requestId;
  const body = {
      "checkerId": Checkerid,
      "remarks": Remarks,
      "requestId": RequestId,
      "status": reportStatus
  };
  return this.http.put(environment.endPointApi + 'send_to_checker', body)
  .map((response: Response) => {
  //  console.log(response.status);
 // console.log(response);
    const user = response;
   // user.responseStatus = response.status;
    console.log("send to checker data : ",user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

manualNoteToChecker(remarks,requestId,ruleId,statusSent){
  
  console.log("Actual :::: '5e40e0363f2ece7a37083ff7', 8VYVK0H635");
  console.log("Needed :::: ",remarks,statusSent);
  const body = 
  {
    "remarks": remarks,
    "requestId": requestId,
    "ruleId": ruleId,
    "status": statusSent
  }

  return this.http.put(environment.endPointApi + "individule_rule_remarks",body).map(response =>
    {const user = response;
    return user;
    }
    ).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
    
}

dashboardAPI(){
  return this.http.get(environment.endPointApi + "maker/dashboard_api").map(response =>
    {
      const user=response;
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

c4_Dashboard(){
  return this.http.get(environment.endPointApi + "maker/4C_dashboard/"+localStorage.getItem('id')).map(response =>
    {
      const user=response;
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}
cardSimbaReport(){
  return this.http.get(environment.endPointApi+"maker/simba_report").map(response=>{
    const user = response;
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

checkerList(){
  return this.http.get(environment.endPointApi+"user/checkerlist").map(response=>{
    const user = response;
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


makerSummarry(request_id){
return this.http.get(environment.endPointApi + 'maker/docs/summary/' + request_id)
  .map(response =>{
      const user = response;
      return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


generatePDF(id:any){
  return this.http.get(environment.endPointApi + 'maker/docs/report/'+id).map(response =>{
    const user = response;
    return user;
  }).catch((error) =>{
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
  })
}


overallMakerComment(id){
 
  return this.http.get(environment.endPointApi + 'maker/comments/' +id).map(response =>{
    const user = response;
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

//Rectified Document Upload
rectifiedDocUpload(fileToUpload: File, id) {

  let access_token = localStorage.getItem('access_token');

  const headers = new Headers();

  headers.append('Authorization', 'Bearer ' + access_token);
  const options = { headers: headers };
  const formData: FormData = new FormData();
  console.log('sd', fileToUpload);
  formData.append('doc', fileToUpload,fileToUpload.name);
  formData.append('requestId', id);
  //  const body ={
  //   //  "doc": formData,
  //   "requestId":id
  //  }
  console.log('formdata', formData,id);

  return this.http.post( environment.endPointApi + 'maker/docs/rectifydocupload', formData).map((response: any) => {
  
    const user = response;
    console.log("DATA FROM BACK ::: ",user.request_id)
    console.log("Upload response status : ",user.status)
    return user;
   
  }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}


processLCUpdate(req_id,data){
  console.log("hhh",data)
  const body = data;
 return this.http.post(environment.endPointApi + 'maker/update_lc_data/'+req_id,body).map(Response=>{
    const user=Response;
    return user;
  }
  ).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


processDocUpdate(req_id,data){
  console.log("hhh",data)
  const body = data;
 return this.http.post(environment.endPointApi + 'maker/update_doc_data/'+req_id,body).map(Response=>{
    const user=Response;
    return user;
  }
  ).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
//Process Document
processRectified(req_id){
  const body = {
    "request_id":req_id
  }
 return this.http.post(environment.endPointApi + 'maker/docs/rectifyprocess/',body).map(Response=>{
    const user=Response;
    return user;
  }
  ).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

}
