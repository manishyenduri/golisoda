import { Injectable, Injector } from '@angular/core';
import { HttpRequest, 
  HttpResponse, 
  HttpInterceptor, 
  HttpHandler, 
  HttpEvent} 
  from '@angular/common/http';
import {tap, catchError} from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { MakerService } from './maker/docs.service';
import { AuthService } from './auth.service';


@Injectable()
export class RefreshTokenInterceptor implements HttpInterceptor{
  
  constructor(private injector:Injector, private AuthService: AuthService){}

  intercept(request:HttpRequest<any>, next:HttpHandler):Observable<HttpEvent<any>>{
  

    let idToken = localStorage.getItem("access_token")
    let cloned = request.clone({headers: request.headers.set('Authorization','Bearer '+idToken)
              .set('x-api-key','4d980dd2-8df8-40e1-a0e1-c9afba32aace') 
              .set('Access-Control-Allow-Origin','*')})
            return next.handle(cloned).pipe(
              tap(
                r=>{
                  this.AuthService.ReplaceToken().subscribe(data=>{
                    localStorage.setItem("access_token", data.access_token)
                    console.log("Passing through Interceptor");
                  });
                 
                  //console.log("R : ",r)
                }
              )
            );
  }
}
 