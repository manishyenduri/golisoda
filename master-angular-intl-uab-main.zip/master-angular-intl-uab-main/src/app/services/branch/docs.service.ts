import { Injectable, Injector } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { GlobalService } from '../global.service';
import { throwError } from 'rxjs';
import { HttpEventType, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { catchError, tap } from 'rxjs/operators';
import { AuthService } from '../auth.service';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class BranchService {
  _httpService: any;
  id: any = '';

constructor(private http: HttpClient, private router: Router,private injector:Injector) { }

public  upload(fileToUpload: File/*,fileToUploadName*/) {

    let access_token = localStorage.getItem('access_token');

    const headers = new Headers();

    headers.append('Authorization', 'Bearer ' + access_token);
    const options = { headers: headers };
    const formData: FormData = new FormData();
    console.log('sd', fileToUpload, fileToUpload.name);
    formData.append('file', fileToUpload, fileToUpload.name);
    console.log('formdata', formData);

    return this.http.post( environment.endPointApi + 'banker/banker/docs/upload', formData /*, options*/).map((response: any) => {
      const user = response;
      console.log("DATA FROM BACK ::: ",user.request_id)
      console.log("Upload response status : ",user.status)
      return user;
    }).catch((error) => {
        console.log('error', error);
        return this.errorCheck(error);
    });
  }

  errorCheck(error){
    if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  }


  public getTransactionHistory(skip,total){
    return this.http.get(environment.endPointApi+'banker/docs/transaction_history/'+skip+'/'+total).map((response: Response) => {
      console.log(response.status);
      const user = response;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error ;//.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }

  public analyze(request_id) {
    
    console.log('inside services');
    const requestId = request_id;
    const body = {
        "request_id": requestId
    };
    return this.http.post(environment.endPointApi + 'banker/banker/docs/process/', body/*,
    GlobalService.getHeaders()*/).map((response: Response) => {
      console.log("Process Response: ",response)//.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status sdsd', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public  uploadRemittance(fileToUpload: File/*,fileToUploadName*/) {

  let access_token = localStorage.getItem('access_token');

  const headers = new Headers();

  headers.append('Authorization', 'Bearer ' + access_token);
  const options = { headers: headers };
  const formData: FormData = new FormData();
  formData.append('file', fileToUpload, fileToUpload.name);

  return this.http.post( environment.a1EndPointApi+'banker/docs/upload', formData /*, options*/).map((response: any) => {
    const user = response;
    console.log("DATA FROM BACK ::: ",user.request_id)
    console.log("Upload response status : ",user.status)
    return user;
  }).catch((error) => {
      console.log('error', error);
      return this.errorCheck(error);
  });
}


public  processRemittance(id) {

  let access_token = localStorage.getItem('access_token');

  const headers = new Headers();

  headers.append('Authorization', 'Bearer ' + access_token);
  const options = { headers: headers };
  
const body={"request_id":id};
  return this.http.post(  environment.a1EndPointApi+'banker/upload', body /*, options*/).map((response: any) => {
    const user = response;
    console.log("DATA FROM BACK ::: ",user.request_id)
    console.log("Upload response status : ",user.status)
    return user;
  }).catch((error) => {
      console.log('error', error);
      return this.errorCheck(error);
  });
}

public getRemittanceIDs(){
  return this.http.get( environment.a1EndPointApi+'banker/get_all_transactions').map((response: Response) => {
    console.log(response.status);
    const user = response;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error ;//.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


public getRemittanceByID(id){
  return this.http.get( environment.a1EndPointApi+'banker/get_data/'+id).map((response: Response) => {
    console.log(response.status);
    const user = response;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error ;//.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

public getClassificationImages(id){
  return this.http.get(environment.endPointApi+'banker/classification_image/'+id).map((response: Response) => {
    console.log(response.status);
    const user = response;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error ;//.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

// /banker/classified_image_data/
public classifiedAPI(data,id) {
    
  console.log('inside services');
  // const requestId = request_id;
  const body = data
  return this.http.post(environment.endPointApi + 'banker/classified_image_data/'+id, body/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log("Process Response: ",response)//.status);
    const user = response;//.json();
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status sdsd', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

}
