import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { GlobalService } from '../global.service';
import { throwError } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class CheckerService {

  constructor(private http: HttpClient, private router: Router) { }

  public dashboardAPI(){
    return this.http.get(environment.endPointApi + 'checker/dashboard_api').map(Response=>
      {
        const user = Response;
        console.log("Response : ",user)
        return user;
      })
      .catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }

  
  
// /MT734
public swift_msg() {
  console.log('inside services');
  const id = localStorage.getItem('id')
  const url = environment.endPointApi+'MT734'
  
  return this.http.get(url,
  // tslint:disable-next-line: deprecation
 /* GlobalService.getHeaders()*/).map((response: Response) => {
   // console.log(response.status);
    const user = response;//.json();
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
public getHSN_data() {
  console.log('inside services');
  const id = localStorage.getItem('id')
  const url = environment.endPointApi+'checker/hsndata/'
  
  return this.http.get(url+id,
  // tslint:disable-next-line: deprecation
 /* GlobalService.getHeaders()*/).map((response: Response) => {
   // console.log(response.status);
    const user = response;//.json();
    //user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


public ofacVerification(request_id, data) {
  console.log('inside services');
  const requestId = request_id;
  return this.http.get(environment.endPointApi + 'checker/ofacStatus/' + requestId+'/' + data /*,
  // tslint:disable-next-line: deprecation
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
    // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
  public transactionHist(){
    return this.http.get(environment.endPointApi + 'checker/docs/transaction_history').map(Response=>
      {
        const user = Response;
        console.log("Response : ",user)
        return user;
      })
      .catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }

  // classificationChecker
  public classificationChecker(id){
    return this.http.get(environment.endPointApi + 'checker/classification_data/'+id).map(Response=>
      {
        const user = Response;
        console.log("Response : ",user)
        return user;
      })
      .catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }
  
processLCUpdate(req_id,data){
  console.log("hhh",data)
  const body = data;
 return this.http.post(environment.endPointApi + 'checker/update_lc_data/'+req_id,body).map(Response=>{
    const user=Response;
    return user;
  }
  ).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


processDocUpdate(req_id,data){
  console.log("hhh",data)
  const body = data;
 return this.http.post(environment.endPointApi + 'checker/update_doc_data/'+req_id,body).map(Response=>{
    const user=Response;
    return user;
  }
  ).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
  
public consistencyChecker(id) {
  console.log('inside services');
  return this.http.get(environment.endPointApi + 'checker/consistancy/'+id/*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
   // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

  public simbaReport(){
      return this.http.get(environment.endPointApi+'checker/simba_report')
      .map(Response=>{
        const user= Response;
        return user;
      })
      .catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }
  
  public getRequestById() {
    console.log('inside services');
    const id = localStorage.getItem('id')
    const url = environment.endPointApi+'checker/docs/'
    
    return this.http.get(url+id,
    // tslint:disable-next-line: deprecation
   /* GlobalService.getHeaders()*/).map((response: Response) => {
     // console.log(response.status);
      const user = response;//.json();
      //user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}


  public docsData(id:any){
    return this.http.get(environment.endPointApi+'checker/docs/data/'+id)
    .map(Response=>
     {
        const user = Response;
        //console.log("useruseruseruseruseruseruser",user.data.data[1]);
        return user;
     }
      ).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }

  transcationStatus(id){
    return this.http.get(environment.endPointApi + 'checker/docs/transaction_status/'+id).map(Response=>{
      const user = Response;
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
  
  sendToMaker(makerId,comments,requestId,trans_status){
    let body={
      "makerId": makerId,
      "remarks": comments,
      "requestId": requestId,
      "status": trans_status
    }
    return this.http.put(environment.endPointApi+'checker/send_to_maker',body)
    .map(Response=>{
      const user = Response;
      return user;
    })
    .catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }

  makerList(){
    return this.http.get(environment.endPointApi+'user/makerlist')
    .map(Response=>{
      const user = Response;
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }

  manualCardsDocs(id){
    return this.http.get(environment.endPointApi+'checker/docs/'+id)
    .map(Response=>{
      const user =Response;
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
  }
// 
public c4_DashboardAPI(request_id) {
  console.log('inside services');
  const requestId = request_id;
  return this.http.get(environment.endPointApi + 'checker/4C_dashboard/' + requestId  /*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response //.json();
    // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


// To get the LC image and trade doc image inorder to validate manually
public getRuleById(request_id, rule_id) {
  console.log('inside services');
  const requestId = request_id;
  const ruleId = rule_id;
  return this.http.get(environment.endPointApi + 'checker/docs/' + requestId + '/' + ruleId /*,
  GlobalService.getHeaders()*/).map((response: Response) => {
    console.log(response.status);
    const user = response //.json();
    // user.responseStatus = response.status;
    console.log(user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}


manualNoteToMaker(remarks,id,ruleId,statusSent){
  const body=
    {
      "remarks": remarks,
      "requestId": id,
      "ruleId": ruleId,
      "status": statusSent
    }
  
  return this.http.put(environment.endPointApi+'checker/individule_rule_remarks',body).map((response: Response) => {
    console.log(response.status);
    const user = response;//.json();
  //  user.responseStatus = response.status;
    console.log("UserUSerUSEr",user);
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}

checkerSummary(){
  return this.http.get(environment.endPointApi + 'checker/docs/summary/'+ localStorage.getItem('id'))
          .map(Response =>{
            const user = Response;
            return user;
          }).catch((error) => {
            console.log('error', error);
            if (error.status === 500) {
              console.log('status', error.status);
              const err = error.json();
              err.responseStatus = error.status;
              console.log('status', err.responseStatus);
              return throwError(err);
            } else if (error.status === 400) {
              console.log('status', error.status);
              const err = error.json();
              err.responseStatus = error.status;
              console.log('status', err.responseStatus);
              return throwError(err);
            } else if (error.status === 401) {
              console.log('status', error.status);
              const err = error.json();
              console.log('err', err);
              err.responseStatus = error.status;
              console.log('status', err.responseStatus);
              return throwError(err);
            }
        });
}

overallMakerComment(id){
 
  return this.http.get(environment.endPointApi + 'checker/comments/' +id).map(response =>{
    const user = response;
    return user;
  }).catch((error) => {
    console.log('error', error);
    if (error.status === 500) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 400) {
      console.log('status', error.status);
      const err = error.json();
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    } else if (error.status === 401) {
      console.log('status', error.status);
      const err = error.json();
      console.log('err', err);
      err.responseStatus = error.status;
      console.log('status', err.responseStatus);
      return throwError(err);
    }
});
}
  /*
  public listDocs() {
    console.log('inside services');
    return this.http.get(environment.endPointApi + 'checker/docs/skip:0/limit:20/key:lastModified/order:-1',
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public  upload(docs) {
    console.log('image', docs);
    var access_token = localStorage.getItem('access_token');
    var headers = new Headers();
    // headers.append('Content-Type', 'application/x-www-form-urlencoded');
    headers.append('Authorization', 'Bearer ' + access_token);
    const options = { headers: headers };
    const formData: FormData = new FormData();
    formData.append('lc', docs.lcFile);
    formData.append('invoice', docs.invFile);
    formData.append('boe', docs.boeFile);
    formData.append('awb', docs.awbFile);
    formData.append('bol', docs.bolFile);
    console.log('formdata', formData);
    return this.http.post( environment.endPointApi + 'checker/docs/upload', formData, options).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
        console.log('error', error);
        if (error.status === 500) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 400) {
          console.log('status', error.status);
          const err = error.json();
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        } else if (error.status === 401) {
          console.log('status', error.status);
          const err = error.json();
          console.log('err', err);
          err.responseStatus = error.status;
          console.log('status', err.responseStatus);
          return throwError(err);
        }
    });
  }

  public analyze(request_id) {
    console.log('inside services');
    const requestId = request_id;
    const body = {
        'request_id': requestId
    }
    return this.http.post(environment.endPointApi + 'checker/docs/process/', body,
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}


public getRequestById(request_id) {
    console.log('inside services');
    const requestId = request_id;
    return this.http.get(environment.endPointApi + 'checker/docs/' + requestId,
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public getRuleById(request_id,rule_id) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    return this.http.get(environment.endPointApi + 'checker/docs/' + requestId + '/' + ruleId,
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public postRemarks(request_id,rule_id,rule) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    const body = {
        'remarks': rule.remarks
    }
    return this.http.put(environment.endPointApi + 'checker/docs/' + requestId + '/' + ruleId + '/remarks',
     body, GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public postComply(request_id,rule_id) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    const body = {
        'status': 1
    }
    return this.http.put(environment.endPointApi + 'checker/docs/' + requestId + '/' + ruleId + '/status',
     body, GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public postDiscrepant(request_id,rule_id) {
    console.log('inside services');
    const requestId = request_id;
    const ruleId = rule_id;
    const body = {
        'status': 0
    }
    return this.http.put(environment.endPointApi + 'checker/docs/' + requestId + '/' + ruleId + '/status',
     body, GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public listReport(request_id) {
    console.log('inside services');
    const requestId = request_id;
    return this.http.get(environment.endPointApi + 'checker/docs/' + requestId +  '/summary',
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public requestLogs(request_id) {
    console.log('inside services');
    const requestId = request_id;
    return this.http.get(environment.endPointApi + 'checker/docs/' + requestId + '/logs',
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public requestStatus(request_id) {
    console.log('inside services');
    const requestId = request_id;
    const body = {
        'status': 1
    }
    return this.http.put(environment.endPointApi + 'checker/docs/' + requestId + '/status', body,
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public requestReject(request_id) {
    console.log('inside services');
    const requestId = request_id;
    const body = {
        'status': 0
    }
    return this.http.put(environment.endPointApi + 'checker/docs/' + requestId + '/status', body,
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
}

public requestRemarks(request_id,rule) {
    console.log('inside services');
    const requestId = request_id;
    const body = {
        'remarks': rule.remarks
    }
    return this.http.put(environment.endPointApi + 'checker/docs/' + requestId + '/remarks', body,
    GlobalService.getHeaders()).map((response: Response) => {
      console.log(response.status);
      const user = response.json();
      user.responseStatus = response.status;
      console.log(user);
      return user;
    }).catch((error) => {
      console.log('error', error);
      if (error.status === 500) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 400) {
        console.log('status', error.status);
        const err = error.json();
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      } else if (error.status === 401) {
        console.log('status', error.status);
        const err = error.json();
        console.log('err', err);
        err.responseStatus = error.status;
        console.log('status', err.responseStatus);
        return throwError(err);
      }
  });
} */
}
