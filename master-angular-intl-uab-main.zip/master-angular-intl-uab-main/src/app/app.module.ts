import * as $ from 'jquery';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  CommonModule,
  LocationStrategy,
  HashLocationStrategy,
  DatePipe
} from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';

import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AgmCoreModule } from '@agm/core';
import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';

import { FullComponent } from './layouts/full/full.component';
import { BlankComponent } from './layouts/blank/blank.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

import { NavigationComponent } from './shared/header-navigation/navigation.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { BreadcrumbComponent } from './shared/breadcrumb/breadcrumb.component';
import {AdminSidebarComponent} from './shared/admin-sidebar/admin-sidebar.component'
import { Approutes } from './app-routing.module';
import { AppComponent } from './app.component';
import { SpinnerComponent } from './shared/spinner.component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { AppGuard } from './app.guard';
import { LoginComponent } from './login/login.component';
import { NgxPaginationModule } from 'ngx-pagination';


import { AuthService } from './services/auth.service';
import { GlobalService } from './services/global.service';
import { HttpModule } from '@angular/http';
import { ToastrModule } from 'ngx-toastr';
import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';
// import { RectifyDocComponent } from './maker/rectify-doc/rectify-doc.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { TransactionReportComponent } from './maker/transaction-report/transaction-report.component';
import { AdminComponent } from './Admin/admin/admin.component';
import { AdminDashboardComponent } from './Admin/admin-dashboard/admin-dashboard.component';
import { AdminChangePasswordComponent } from './Admin/admin-change-Password/admin-change-password/admin-change-password.component';
import { ConfirmEqualValidatorDirective} from './shared/confirm-equal-validator.Directive';
import { AdminLayout } from './layouts/adminLayout/adminlayout.component';
import { AddMakerComponent } from './Admin/add-maker/add-maker.component';
import { AddCheckerComponent } from './Admin/add-checker/add-checker.component';
import { Ng6O2ChartModule } from 'ng6-o2-chart';
import { AddMakerModalComponent } from './Admin/add-maker/add-maker-modal/add-maker-modal.component';
import { AdminService } from './services/admin/docs.service';
import { CheckerDashboardComponent } from './checker/checker-dashboard/checker-dashboard.component';
import { CheckerSidebarComponent } from './shared/checker-sidebar/checker-sidebar/checker-sidebar.component';
import { CheckerAdminLayoutComponent } from './layouts/checker-admin-layout/checker-admin-layout.component';
import { CheckerHeaderNavComponent } from './shared/checker-header-nav/checker-header-nav.component';
import { SimbaReportsListComponent } from './checker/simba-reportslist/simba-reports-list.component';
import { ManualReportsListComponent } from './checker/manual-reportslist/manual-reports-list.component';
import { TransactionReportsComponent } from './checker/transaction-reports/transaction-reports.component';
import { ApprovalBoardComponent } from './checker/approval-board/approval-board.component';
import { AiReportListComponent } from './maker/ai-report-list/ai-report-list.component';
import { from } from 'rxjs';
import { AdminNavComponent } from './shared/admin-nav/admin-nav.component';
import { RefreshTokenInterceptor } from './services/token-interceptor.service';
import { SwiftMessagesComponent } from './maker/swift-messages/swift-messages.component';
import { RbiReportingsComponent } from './maker/rbi-reportings/rbi-reportings.component';
import { rbireportsComponent } from './checker/rbi-reports/rbi-reports.component';
import { SwiftMessageComponent } from './checker/swift-message/swift-message.component';
import { ManualReportlistComponent } from './maker/manual-reportlist/manual-reportlist.component';
import { SimbaReportsComponent } from './checker/simba-reports/simba-reports.component';
import { ManualReportsComponent } from './checker/manual-reports/manual-reports.component';
import { MakerSummeryComponent } from './maker/maker-summery/maker-summery.component';
import { CheckerSummeryComponent } from './checker/checker-summery/checker-summery.component';
import { MakerService } from './services/maker/docs.service';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
 import { SendtocheckerModalComponent } from './maker/AIreport/sendtochecker-modal/sendtochecker-modal.component';
import { manualSendtocheckerModalComponent } from './maker/manualReport/sendtochecker-modal/sendtochecker-modal.component';
import { CheckerService } from './services/checker/docs.service';
import { SendtomakerModalComponent } from './checker/simba-reports/sendtochecker-modal/sendtomaker-modal.component';
import { Ng2PanZoomModule } from 'ng2-panzoom';
import { InitiateApprovalModalComponent } from './checker/initiate_approval/sendtochecker-modal/sendtomaker-modal.component';
import { AdminCustomRulesComponent } from './Admin/admin-custom-rules/admin-custom-rules.component';
import { HtmlToPdfComponent } from './maker/html-to-pdf/html-to-pdf.component';
import { SignupComponent } from './signup/signup.component';
import { NounListsComponent } from './maker/noun-lists/noun-lists.component';
import { NounReportComponent } from './maker/noun-report/noun-report.component';
import { GenericOcrComponent } from './maker/generic-ocr/generic-ocr.component';
import { GenericResultComponent } from './maker/generic-result/generic-result.component';
import { OutwardRemittanceComponent } from './maker/outward-remittance/outward-remittance.component';
import { OutwardRemittanceListComponent } from './maker/outward-remittance-list/outward-remittance-list.component';
import { BranchDashboardComponent } from './branch/branch-dashboard/branch-dashboard.component';
import { BranchService } from './services/branch/docs.service';
import { BranchLayoutComponent } from './layouts/branch-layout/branch-layout.component';
import { BranchSidebarComponent } from './shared/branch-sidebar/branch-sidebar.component';
import { BranchHeaderNavigationComponent } from './shared/branch-header-navigation/branch-header-navigation.component';
import { BankerTransactionsComponent } from './branch/banker-transactions/banker-transactions.component';
import { MakerDocumentChartsComponent } from './maker/maker-document-charts/maker-document-charts.component';
import { BranchClassificationComponent } from './branch/branch-classification/branch-classification.component';
import { BranchProcessClassificationComponent } from './branch/branch-process-classification/branch-process-classification.component';
import { MakerJourneyStartComponent } from './maker/maker-journey-start/maker-journey-start.component';
import { CheckerProcessStartComponent } from './checker/checker-process-start/checker-process-start.component';
import { MakerCorrectComponent } from './maker/maker-correct/maker-correct.component';
import { MakerConsistentComponent } from './maker/maker-consistent/maker-consistent.component';
import { MakerCompliantComponent } from './maker/maker-compliant/maker-compliant.component';
import { MakerClassificationComponent } from './maker/maker-classification/maker-classification.component';
// import { NgxDropzoneModule } from 'ngx-dropzone';
import {SlideshowModule} from 'ng-simple-slideshow';
import { CheckerClassificationComponent } from './checker/checker-classification/checker-classification.component';
import { CheckerCorrectComponent } from './checker/checker-correct/checker-correct.component';
import { CheckerConsistentComponent } from './checker/checker-consistent/checker-consistent.component';
import { CheckerCompliantComponent } from './checker/checker-compliant/checker-compliant.component';
import { C4DashboardComponent } from './maker/c4-dashboard/c4-dashboard.component';
import { C4DashboardCheckerComponent } from './checker/c4-dashboard-checker/c4-dashboard-checker.component';
import { BranchRemittanceComponent } from './branch/branch-remittance/branch-remittance.component';
import { VesselTrackingComponent } from './maker/vessel-tracking/vessel-tracking.component';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
  wheelSpeed: 1,
  wheelPropagation: true,
  minScrollbarLength: 20
};

@NgModule({
  declarations: [
    AppComponent,
   
    SpinnerComponent,
    FullComponent,
    BlankComponent,
    AdminLayout,
    NavigationComponent,
    BreadcrumbComponent,
    SidebarComponent,
    LoginComponent,
    TransactionReportComponent,
    AdminComponent,
    AdminDashboardComponent,
    AdminChangePasswordComponent,
    // RectifyDocComponent
    ConfirmEqualValidatorDirective,
    AddMakerComponent,
    AddCheckerComponent,
    AdminSidebarComponent,
    AddMakerModalComponent,
    SendtocheckerModalComponent,
    InitiateApprovalModalComponent,
    manualSendtocheckerModalComponent,
    CheckerDashboardComponent,
    CheckerSidebarComponent,
    CheckerAdminLayoutComponent,
    BranchHeaderNavigationComponent,
    CheckerHeaderNavComponent,
    SimbaReportsListComponent,
    ManualReportsListComponent,
    TransactionReportsComponent,
    ApprovalBoardComponent,
    AiReportListComponent,
    AdminNavComponent,
    SwiftMessagesComponent,
    RbiReportingsComponent,
    rbireportsComponent,
    SwiftMessageComponent,
    ManualReportlistComponent,
    SimbaReportsComponent,
    ManualReportsComponent,
    MakerSummeryComponent,
    CheckerSummeryComponent,
    SendtomakerModalComponent,
    AdminCustomRulesComponent,
    HtmlToPdfComponent,
    SignupComponent,
    NounListsComponent,
    NounReportComponent,
    GenericOcrComponent,
    GenericResultComponent,
    OutwardRemittanceComponent,
    OutwardRemittanceListComponent,
    BranchDashboardComponent,
    BranchLayoutComponent,
    BranchSidebarComponent,
    BranchHeaderNavigationComponent,
    BankerTransactionsComponent,
    MakerDocumentChartsComponent,
    BranchClassificationComponent,
    BranchProcessClassificationComponent,
    MakerJourneyStartComponent,
    CheckerProcessStartComponent,
    MakerCorrectComponent,
    MakerConsistentComponent,
    MakerCompliantComponent,
    MakerClassificationComponent,
    CheckerClassificationComponent,
    CheckerCorrectComponent,
    CheckerConsistentComponent,
    CheckerCompliantComponent,
    C4DashboardComponent,
    C4DashboardCheckerComponent,
    BranchRemittanceComponent,
    VesselTrackingComponent
 
  ],
  imports: [
    // NgxDropzoneModule,
    SlideshowModule,
    Ng2PanZoomModule,
    Ng2SearchPipeModule,
    Ng6O2ChartModule,
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule,
    NgxPaginationModule,
    HttpClientModule,
    HttpModule,
    ToastrModule.forRoot(),
    NgbModule.forRoot(),
    SlimLoadingBarModule.forRoot(),
    RouterModule.forRoot(Approutes, { useHash: false }),
    PerfectScrollbarModule,
    NgMultiSelectDropDownModule.forRoot(),
    AgmCoreModule.forRoot({ apiKey: 'AIzaSyBUb3jDWJQ28vDJhuQZxkC0NXr_zycm8D0' }),
    SweetAlert2Module.forRoot({
        buttonsStyling: false,
        customClass: 'modal-content',
        confirmButtonClass: 'btn btn-primary',
        cancelButtonClass: 'btn'
    })
  ],
  providers: [
    {
      provide:HTTP_INTERCEPTORS,
      useClass:RefreshTokenInterceptor,
      multi:true
    },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    BranchService,
    AdminService,
    AuthService,
    AppGuard,
    MakerService,
    CheckerService,
    GlobalService,
   

    NgbActiveModal,
    DatePipe
  ],
  entryComponents:[AddMakerModalComponent,
    SendtocheckerModalComponent, 
    manualSendtocheckerModalComponent,
    InitiateApprovalModalComponent,
    SendtomakerModalComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
