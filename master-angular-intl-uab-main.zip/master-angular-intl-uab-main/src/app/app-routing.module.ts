import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FullComponent } from './layouts/full/full.component';
import { BlankComponent } from './layouts/blank/blank.component';
import { LoginComponent } from './login/login.component';
import { RectifyDocComponent} from '../app/maker/rectify-doc/rectify-doc.component';
import { TransactionReportComponent  } from '../app/maker/transaction-report/transaction-report.component';
import { AdminComponent } from './Admin/admin/admin.component';
import { AdminChangePasswordComponent } from './Admin/admin-change-Password/admin-change-password/admin-change-password.component';
import { AdminDashboardComponent } from './Admin/admin-dashboard/admin-dashboard.component';
import { AdminLayout } from './layouts/adminLayout/adminlayout.component';
import { AddMakerComponent } from './Admin/add-maker/add-maker.component';
import { AddCheckerComponent } from './Admin/add-checker/add-checker.component';
import { CheckerDashboardComponent } from './checker/checker-dashboard/checker-dashboard.component';
import { CheckerAdminLayoutComponent } from './layouts/checker-admin-layout/checker-admin-layout.component';
import { SimbaReportsListComponent } from './checker/simba-reportslist/simba-reports-list.component';
import { ManualReportsListComponent } from './checker/manual-reportslist/manual-reports-list.component';
import { TransactionReportsComponent } from './checker/transaction-reports/transaction-reports.component';
import { ApprovalBoardComponent } from './checker/approval-board/approval-board.component';
import { AiReportListComponent } from './maker/ai-report-list/ai-report-list.component';
import { SwiftMessagesComponent } from './maker/swift-messages/swift-messages.component';
import { RbiReportingsComponent } from './maker/rbi-reportings/rbi-reportings.component';
import { rbireportsComponent } from './checker/rbi-reports/rbi-reports.component';
import { SwiftMessageComponent } from './checker/swift-message/swift-message.component';
import { ManualReportlistComponent } from './maker/manual-reportlist/manual-reportlist.component';
import { SimbaReportsComponent } from './checker/simba-reports/simba-reports.component';
import { ManualReportsComponent } from './checker/manual-reports/manual-reports.component';
import { MakerSummeryComponent } from './maker/maker-summery/maker-summery.component';
import { CheckerSummeryComponent } from './checker/checker-summery/checker-summery.component';
import { SendtocheckerModalComponent } from './maker/AIreport/sendtochecker-modal/sendtochecker-modal.component';
import { AdminCustomRulesComponent } from './Admin/admin-custom-rules/admin-custom-rules.component';
import { HtmlToPdfComponent } from './maker/html-to-pdf/html-to-pdf.component';
import { SignupComponent } from './signup/signup.component';
import { NounListsComponent } from './maker/noun-lists/noun-lists.component';
import { NounReportComponent } from './maker/noun-report/noun-report.component';
import { GenericOcrComponent } from './maker/generic-ocr/generic-ocr.component';
import { GenericResultComponent } from './maker/generic-result/generic-result.component';
import { OutwardRemittanceComponent } from './maker/outward-remittance/outward-remittance.component';
import { OutwardRemittanceListComponent } from './maker/outward-remittance-list/outward-remittance-list.component';
import { BranchDashboardComponent } from './branch/branch-dashboard/branch-dashboard.component';
import { BranchLayoutComponent } from './layouts/branch-layout/branch-layout.component';
import { BankerTransactionsComponent } from './branch/banker-transactions/banker-transactions.component';
import { MakerDocumentChartsComponent } from './maker/maker-document-charts/maker-document-charts.component';
import { BranchClassificationComponent } from './branch/branch-classification/branch-classification.component';
import { BranchProcessClassificationComponent } from './branch/branch-process-classification/branch-process-classification.component';
import { MakerJourneyStartComponent } from './maker/maker-journey-start/maker-journey-start.component';
import { CheckerProcessStartComponent } from './checker/checker-process-start/checker-process-start.component';
import { MakerCorrectComponent } from './maker/maker-correct/maker-correct.component';
import { MakerConsistentComponent } from './maker/maker-consistent/maker-consistent.component';
import { MakerCompliantComponent } from './maker/maker-compliant/maker-compliant.component';
import { MakerClassificationComponent } from './maker/maker-classification/maker-classification.component';
import { CheckerClassificationComponent } from './checker/checker-classification/checker-classification.component';
import { CheckerCompliantComponent } from './checker/checker-compliant/checker-compliant.component';
import { CheckerCorrectComponent } from './checker/checker-correct/checker-correct.component';
import { CheckerConsistentComponent } from './checker/checker-consistent/checker-consistent.component';
import { C4DashboardComponent } from './maker/c4-dashboard/c4-dashboard.component';
import { C4DashboardCheckerComponent } from './checker/c4-dashboard-checker/c4-dashboard-checker.component';
import { BranchRemittanceComponent } from './branch/branch-remittance/branch-remittance.component';
import { VesselTrackingComponent } from './maker/vessel-tracking/vessel-tracking.component';


export const Approutes: Routes = [
  {
    path: '',
    component: FullComponent,
    children: [
      { path: '', redirectTo: '/login', pathMatch: 'full' },
      {
        path: 'maker/dashboard',
        loadChildren: './maker/dashboard/dashboard.module#DashboardModule'
      },
      {
        path:'maker/process-initiate',
        component:MakerJourneyStartComponent
      },
      {
        path:'maker/maker-correct',
        component:MakerCorrectComponent
      },
      {
        path:'maker/maker-classification',
        component:MakerClassificationComponent
      },
      {
        path:'maker/4c-dashboard',
        component:C4DashboardComponent
      },
      {
        path:'maker/maker-consistent',
        component:MakerConsistentComponent
      },
      {
        path:'maker/maker-compliant',
        component:MakerCompliantComponent
      },
      {
        path: 'maker/upload',
        loadChildren: './maker/docUpload/upload.module#DocsUploadModule'
      },
      {
        path: 'maker/revenue',
        loadChildren: './maker/revenue/revenue.module#RevenueModule'
      },
      {
        path: 'maker/ai-reports',
        loadChildren: './maker/AIreport/aireport.module#AIreportModule'
      },
      {
        path: 'maker/manual-reports',
        loadChildren: './maker/manualReport/manualReport.module#ManualReportModule'
      }, 
      {
        path: 'maker/RectifyDoc',
        loadChildren: './maker/rectify-doc/rectify.module#RectifyModule'
        // component: RectifyDocComponent
      }, 
      {
        path: 'maker/TransactionReport',
        component: TransactionReportComponent
      },
      {
        path:'maker/document/report',
        component:MakerDocumentChartsComponent
      },
      {
        path:"maker/genericOcr",
        component:GenericOcrComponent
      },
      {
        path:"maker/genericResult",
        component:GenericResultComponent
      },
      {
        path:"maker/outward-remittance-report",
        component:OutwardRemittanceComponent
      },
      {
        path:"maker/outward-remittance-list",
        component:OutwardRemittanceListComponent
      },
      {
        path: 'maker/ai-reports-list',
        component: AiReportListComponent 
      },
      {
        path: 'maker/rbi-reportings',
        component: RbiReportingsComponent 
      },
      {
        path: 'maker/swift-messages',
        component: SwiftMessagesComponent 
      },
      {
        path: 'maker/manual-reports-list',
        component: ManualReportlistComponent 
      },
      {
        path: 'maker/maker-summery',
        component: MakerSummeryComponent
      },
      {
        path: 'maker/SIMBA-report',
        component: HtmlToPdfComponent
      },
      {
        path: 'maker/noun-list',
        component: NounListsComponent
      },
      {
        path: 'maker/noun-report',
        component: NounReportComponent
      },
      {
        path:'maker/vessel-tracking',
        component:VesselTrackingComponent
      }
      // {
      //   path:'',
      //   component: SendtocheckerModalComponent
      // },
    ]
  },
  {
    path: 'admin/register',
    component: AdminComponent
  },

  {
    path: 'user/passwordChange/:emailId/:oldPassword',
    component: AdminChangePasswordComponent
  },

  {
    path:'',
    component: CheckerAdminLayoutComponent,
    children: [
      {
        path: 'checker/checker-dashboard',
        component: CheckerDashboardComponent
      },
      {
        path:"checker/4c-dashboard",
        component:C4DashboardCheckerComponent
      },
      {
        path:'checker/checker-classification',
        component:CheckerClassificationComponent
      },
      {
        path:'checker/checker-compliant',
        component:CheckerCompliantComponent
      },
      {
        path:'checker/checker-consistent',
        component:CheckerConsistentComponent
      },
      {
        path:'checker/checker-correct',
        component:CheckerCorrectComponent
      },
      {
        path: 'checker/4c-complete',
        component:CheckerProcessStartComponent
      },
      {
        path: 'checker/simba-reports-list',
        component: SimbaReportsListComponent
      },
      {
        path: 'checker/manual-reports-list',
        component: ManualReportsListComponent
      },
      {
        path: 'checker/transaction-reports',
        component: TransactionReportsComponent
      },
      {
        path: 'checker/approval-board',
        component: ApprovalBoardComponent
      },
      {
        path: 'checker/rbi-reportings',
        component: rbireportsComponent
      },
      {
        path: 'checker/swift-messages',
        component: SwiftMessageComponent
      },
      {
        path: 'checker/simba-reports',
        component: SimbaReportsComponent
      },
      {
        path: 'checker/manual-reports',
        component: ManualReportsComponent
      },
      {
        path: 'checker/checker-summary',
        component: CheckerSummeryComponent
      },
  
    ]
  },
  {
    path:'',
    component:BranchLayoutComponent,
    children:[
      {
        path:'branch/dashboard',
        component:BranchDashboardComponent
      },
    {
      path:'banker/transaction',
      component:BankerTransactionsComponent
    },{
      path:'banker/classification',
      component:BranchClassificationComponent
    },{
      path:'banker/process/classification',
      component:BranchProcessClassificationComponent
    },
  {
    path:'banker/remittance',
    component:BranchRemittanceComponent
  }]
  },
  {
    path:'',
    component: AdminLayout,
    children: [
      {
        path: 'admin/dashboard',
        component: AdminDashboardComponent
      },
      {
        path: 'admin/addMaker',
        component:AddMakerComponent
      },
      {
        path: 'admin/addChecker',
        component:AddCheckerComponent
      },
      {
        path:'admin/customRules',
        component:AdminCustomRulesComponent
      }
    ]
  },
  {
    path: '',
    component: BlankComponent,
    children: [
      {
        path: 'authentication',
        loadChildren:
          './authentication/authentication.module#AuthenticationModule'
      }
    ]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'signup',
    component:SignupComponent
  },
  {
    path: '**',
    redirectTo: '/authentication/404'
  }
];
